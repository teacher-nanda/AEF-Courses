import sys
from bs4 import BeautifulSoup
for d in ['a1a','a1b']:
    soup=BeautifulSoup(open(d+'/index.html',encoding='utf-8').read(),'html.parser')
    for sl in soup.select('.slide'):
        badges=sl.select('.circ-num, .example-badge')
        single=[b for b in badges if not b.find_parent(class_=['fixed-two-col','fixed-three-col','fixed-four-col','two-col-ex','two-col','match-wrap','classify-cols','sound-grid','verb-grid','two-profiles','art-two','quiz-two'])]
        # group by parent container
        from collections import Counter
        c=Counter(id(b.find_parent(['div','ol','ul']).parent) for b in single)
        if single and max(c.values())>=4: print(d, sl['id'], len(single), max(c.values()))
