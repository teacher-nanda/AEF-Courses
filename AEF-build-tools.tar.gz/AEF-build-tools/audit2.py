from bs4 import BeautifulSoup
for d in ['a1a','a1b']:
    soup=BeautifulSoup(open('/tmp/aef/%s/index.html'%d,encoding='utf-8').read(),'html.parser')
    for sl in soup.select('.slide'):
        for g in sl.select('.fixed-two-col'):
            cols=[c for c in g.find_all(recursive=False) if c.name=='div']
            if len(cols)==2:
                l,r=[len(c.find_all(recursive=False)) for c in cols]
                if l-r not in (0,1): print(d,sl['id'],g.get('id'),l,r)
