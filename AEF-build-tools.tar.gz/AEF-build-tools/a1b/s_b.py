# -*- coding: utf-8 -*-
from s_a import S, slide, audio, green, ccq, reveal, ph, script_box, circ_opt_btn
import s_c  # noqa: F401  (registers grammar, pronunciation and communication slides in order)

def ex_block(inner):
    return '<div class="ex-row ex-given">%s</div>' % inner

def qrow(n, q, a):
    return ('<div class="ex-row"><span class="circ-num">%d</span><b>%s</b><br>'
            '<input class="ans-input" style="width:min(720px,100%%);margin-left:32px;" aria-label="answer %d">'
            '<br><span style="margin-left:32px;">%s</span></div>') % (n, q, n, reveal('💡 Possible answer', a))

# ================================================================== LISTENING 4
s119 = '''<p>My name's Elspbeth. I'm twenty-five, I'm a journalist, and I'm single. It's not easy to meet people. So who can help me? My mother… and a dating app. My favorite dating app, called Tinder, shows you photos of possible partners, with a little information about them. You look at the photos and swipe, swipe, swipe. Swipe right if you like them, and swipe left… well… swipe left if you don't. If a guy likes you and you like him, you have a match. Then you can start messaging the person, and from this, romance follows… or so they say. I've tried it, but with no success. So I decide to give my mother my phone. She can swipe all the men she likes, and then look at my matches and choose the people that she likes the best. I've promised to go on a date with the men she chooses.</p>'''
slide('s-l1', 'Listening – Elspbeth and the Dating App', '''<div class="slide" id="s-l1">
  <div class="banner banner-listening">🎧 Listening</div>
  <div class="slide-main"><div class="content">
    <h2>A dating experiment</h2>
    <p class="instruction">Listen to Elspbeth Gordon, a journalist, talking about a dating experiment. Answer the questions.</p>
    <!-- SB 1.19. TB answers: 1 A dating app, called Tinder. 2 You swipe right (if you like them). 3 Choose the men she likes for her daughter. 4 Go on a date with the men her mother chooses. -->
    <div class="art-two">
      <div>%s
        <div class="glossary-box" style="margin-top:12px;"><h4>Glossary</h4>
          <p style="margin:6px 0 0;font-size:1.12rem;color:var(--navy);"><b>swipe</b> — move your finger across a touchscreen on a phone or tablet to activate a function</p></div>
        <div class="ccq-box"><p class="ccq-label">💭 Check the word <b>swipe</b></p><ul class="ccq-list">%s%s</ul></div>
      </div>
      <div>%s</div>
    </div>
    %s
    %s%s%s%s
  </div></div>
</div>''' % (audio('1.19'),
             ccq('Do you swipe with your <b>hands</b> or with your <b>voice</b>?', 'With your finger / hand, on a touchscreen.'),
             ccq('On the dating app, what does <b>swipe right</b> mean? And <b>swipe left</b>?', 'Right = you like the person. Left = you don\'t like the person.'),
             ph('📸', 'Photo: Elspbeth Gordon, a smiling young woman with long brown hair, holding a cocktail in a bar'),
             script_box('l1-script', s119),
             qrow(1, 'What kind of app does Elspbeth use?', 'A dating app (called Tinder).'),
             qrow(2, 'What do you do if you like someone?', 'You swipe right.'),
             qrow(3, "What's Elspbeth's mother going to do?", "Choose the men she likes for her daughter."),
             qrow(4, "What's Elspbeth going to do?", 'Go on a date with the men her mother chooses.')))

# ------------------------------------------------------------------ 4b + 4c
s120 = '''<p><b>Date 1</b><br>My first date is with a nice guy named John. I sit at a table in a café and wait for him to arrive. An old man walks towards the table, and for two awful seconds I think it's all a terrible mistake, but he walks past, and then my date arrives. He's very tall, six feet, two inches. Good job, Mom! I'm tall myself, so I always look for tall men, as my mom knows well. We start chatting, and it's all very easy. Mom has good taste. He's a teacher. We get along well and it's a fun date, but sadly, there isn't a spark. So I try again.</p>
<p><b>Date 2</b><br>I arrive a little early again, and I sit there waiting for Sebastian to arrive. Suddenly, I realize that I can't remember anything at all about him, not even where he's from. Then he comes through the door: tall, dark, and handsome. <i>Mom, you're amazing</i>, I say to myself. He's from Argentina, but he lives in the US. He's a real gentleman. At the end of the evening, he asks for a second date. Mom is very happy. I agree to the date, but I don't really think it's going to work.</p>'''
def js_row(n, text, ans):
    g = 'ljs-%d' % n
    return '<div class="ex-row"><span class="circ-num">%d</span>%s&nbsp; %s%s</div>' % (n, text, circ_opt_btn(g, 'J', ans), circ_opt_btn(g, 'S', ans))
slide('s-l2', 'Listening – Two First Dates', '''<div class="slide" id="s-l2">
  <div class="banner banner-listening">🎧 Listening</div>
  <div class="slide-main"><div class="content">
    <h2>Two dates</h2>
    <p class="instruction"><b>1.</b> Now listen to Elspbeth describe her first two dates. What does she think of her mom's choices?</p>
    <!-- SB 1.20 (b): She likes her mom's choices and has fun, but she isn't sure the men are right for her. -->
    %s
    <div class="ex-row" style="margin-top:8px;"><input class="ans-input" style="width:min(720px,100%%)" aria-label="what does she think of her mom's choices"><br>%s</div>
    <p class="instruction" style="margin-top:20px;"><b>2.</b> Listen again and match the phrases to the two men. Write <b>J</b> for John or <b>S</b> for Sebastian. Which man do you think Elspbeth prefers? Why?</p>
    <!-- SB 4c. TB answers: 1 S, 2 J, 3 J, 4 S, 5 J, 6 S -->
    <div id="ljs">%s%s%s%s%s%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkCircSlide('ljs')">Check Answers</button>
      <button class="btn-reset" onclick="resetCircSlide('ljs')">Reset</button>
    </div>
    <div class="ccq-box"><ul class="ccq-list">%s</ul></div>
    %s
    <div class="discuss-box" style="margin-top:14px;"><p class="discuss-label">💬 Which man do you think Elspbeth prefers? Why?</p></div>
  </div></div>
</div>''' % (audio('1.20'), reveal('💡 Possible answer', "She likes her mom's choices and has fun, but she isn't sure the men are right for her."),
             js_row(1, "He's tall, dark, and handsome.", 'S'), js_row(2, "He's very tall.", 'J'), js_row(3, "He's a teacher.", 'J'),
             js_row(4, "He's from Argentina, but he lives in the US.", 'S'), js_row(5, "There isn't a spark.", 'J'), js_row(6, "He's a real gentleman.", 'S'),
             ccq('<b>a spark</b> — "there isn\'t a spark." What does it mean?', 'A feeling of excitement / romantic destiny between two people.') +
             ccq('J = John, S = Sebastian. Which man does she <b>not</b> want to see again?', 'John — there isn\'t a spark. Sebastian asked for a second date and she agreed.'),
             script_box('l2-script', s120)))

# ------------------------------------------------------------------ 4d, 4e, 4f
s121 = '''<p><b>Date 3</b><br>Date number three is George. He suggests a restaurant near the river. I arrive early – I'm definitely the most punctual person in the world. I stand outside, very confused: the restaurant is closed. For a moment, I think Mom finally got it wrong. But a few minutes later, he arrives – he just didn't know the restaurant was closed. We go somewhere else and start chatting. He tells me he works in IT and is from just outside the city. This guy is a lot of fun. He's very relaxed and interesting – he's traveled a lot. He tells a lot of funny stories. It's all going well, and I'm getting very enthusiastic, when my phone pings.</p>'''
s122 = '''<p>It's all going well, and I'm getting very enthusiastic, when my phone pings. It's on the table between us, and it's a text. From my mother. <i>Well, how's it going? Is he nice? Love, Mom.</i> George looks at my screen and reads the text. I want to die.</p>
<p style="margin-top:8px;">💡 <b>"I want to die"</b> is an exaggeration in English: it means <i>"I'm so embarrassed!"</i></p>'''
slide('s-l3', 'Listening – The Third Date', '''<div class="slide" id="s-l3">
  <div class="banner banner-listening">🎧 Listening</div>
  <div class="slide-main"><div class="content">
    <h2>Date number three</h2>
    <p class="instruction"><b>1.</b> Now listen to the third date. Is it a success? Who do you think the message is from?</p>
    <!-- SB 1.21 (d): Yes, it is. The date is going well. (pre-teach enthusiastic /ɪnˌθuziˈæstɪk/) -->
    <div class="ccq-box"><p class="ccq-label">💭 Before you listen: <b>enthusiastic</b> /ɪnˌθuziˈæstɪk/</p>
      <ul class="ccq-list">%s</ul></div>
    %s
    <div class="ex-row"><input class="ans-input" style="width:min(720px,100%%)" aria-label="is it a success"><br>%s</div>
    %s
    <p class="instruction" style="margin-top:20px;"><b>2.</b> Listen to the end of the date. Were you right? How does Elspbeth feel? Do you think they have a second date?</p>
    <!-- SB 1.22 (e): The message was from her mother. She feels very embarrassed. -->
    %s
    <div class="ex-row"><input class="ans-input" style="width:min(720px,100%%)" aria-label="how does Elspbeth feel"><br>%s</div>
    %s
    <div class="discuss-box" style="margin-top:14px;"><p class="discuss-label">💬 Talk about it (SB 4f)</p>
      <ul class="discuss-list"><li>Do you think a member of your family could choose a good date for you?</li><li>Do you think you could choose one for them?</li></ul></div>
  </div></div>
</div>''' % (ccq('You are very <b>enthusiastic</b> about a plan. Are you interested and excited?', 'Yes — you are very excited about it and want to do it.'),
             audio('1.21'), reveal('💡 Possible answer', 'Yes, it is. The date is going well.'), script_box('l3a-script', s121),
             audio('1.22'), reveal('💡 Possible answer', 'The message was from her mother. She feels very embarrassed.'), script_box('l3b-script', s122)))

# ================================================================== SPEAKING & WRITING 5
def pf_input(label, cls=''):
    return '<div class="%s"><label>%s</label><input type="text" aria-label="%s"></div>' % (cls, label, label)
slide('s-sp1', 'Speaking – Plan Your Description', '''<div class="slide" id="s-sp1">
  <div class="banner banner-speaking">🗣️ Speaking &amp; Writing</div>
  <div class="slide-main"><div class="content">
    <h2>Do you know somebody who is looking for a partner?</h2>
    <p class="instruction">Think of a single person you know well — a family member or a friend. Look at the form and prepare to give this information about him or her.</p>
    <!-- SB 5a (form). TB: give students five minutes to make notes. -->
    <div class="partner-form">
      <div class="fb-head">Help him / her find a partner!</div>
      <div class="fb-body">
        %s
        <div><label>Relationship</label><div class="chip-row"><button class="tchip" onclick="chipPick(this)">Single</button><button class="tchip" onclick="chipPick(this)">Divorced</button><button class="tchip" onclick="chipPick(this)">Separated</button></div></div>
        %s
        %s
        <div class="wide"><label>Appearance</label><input type="text" aria-label="appearance"></div>
        <div class="wide"><label>Personality ＋</label><input type="text" aria-label="positive personality"></div>
        <div class="wide"><label>Personality －</label><input type="text" aria-label="negative personality"></div>
        <div><label>Likes</label><input type="text" aria-label="likes"></div>
        <div><label>Doesn't like</label><input type="text" aria-label="doesn't like"></div>
      </div>
    </div>
    <div class="gram-note">✏️ Use <b>He / She + simple present</b>: <i>He's very shy. He loves traveling. He doesn't like loud music.</i></div>
  </div></div>
</div>''' % (pf_input('Name'), pf_input('Age'), pf_input('Job')))

slide('s-sp2', 'Speaking – Describe and Ask', '''<div class="slide" id="s-sp2">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Describe your person</h2>
    <p class="instruction"><b>You</b> describe your person to me. I listen and ask for more information. Do you know anybody who would be a good partner for this person? Then we change roles.</p>
    <!-- SB 5b -->
    <div class="chat" style="max-width:760px;">
      <div class="bub a"><span class="who">You</span>His name's Mario, and he's single. He's about 30 years old.</div>
      <div class="bub b"><span class="who">Teacher</span>What does he look like? What's he like?</div>
    </div>
    <div class="roul-layout">
      <div class="roul-ball empty" id="dg2-ball" style="font-size:2.6rem;">❓</div>
      <div class="roul-prompt card" style="margin:0;">
        <p class="roul-q" id="dg2-q">Need an idea for a question? Draw one!</p>
        <p class="roul-sub" id="dg2-sub"></p>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-roul" onclick="dg2Draw()">🎲 Draw a question</button>
      <button class="btn-reset" onclick="dg2Reset()">Reset</button>
    </div>
    <div class="gram-note">💬 When you finish: <i>I know someone who'd be a good partner for him! My friend… is single, and she's…</i></div>
  </div></div>
</div>''')

# ------------------------------------------------------------------ WRITING: Describing yourself
def HP(t):
    return '<span class="art-hl">%s</span>' % t
def err(n, t):
    return '<sup style="font-weight:800;color:#FF4F7B;">%d</sup><span style="text-decoration:underline wavy #FF4F7B;text-underline-offset:4px;">%s</span>' % (n, t)
CHARLIE = ('''<div class="article" style="max-width:100%%;">
  <p><b>1</b> Hi. %s Charlie. Well, it's really Carlos, but %s Charlie. %s. I'm Mexican, and I live in Guadalajara.</p>
  <p><b>2</b> %s myself. I'm in college. I'm %s physics. I'm in my last year, and I really like it. %s my parents in an apartment in the center of the city. I have a dog, a schnauzer – his name is Towser.</p>
  <p><b>3</b> %s %s, I have black hair and %s eyes. %s I have a big nose, but I don't think so. I think it's a nice nose!</p>
  <p><b>4</b> %s positive person. %s %s %s I'm funny and it's true. I like making people laugh. But I %s serious too when I need to be!</p>
  <p><b>5</b> I %s have %s free time %s %s I have to do projects or write reports. But %s watching TV series, especially science fiction series and comedies. I watch them in %s with subtitles. I also like playing computer games like <i>World of Warcraft</i> and <i>Starcraft</i>.</p>
</div>''' % (HP("My name's"), HP('everyone calls me'), err(1, 'I have 21 years old'),
             HP("I'm going to tell you about"), err(2, 'studing'), HP('I live with'),
             HP('As you can see from the'), err(3, 'foto'), err(4, 'browns'), HP('My father always says'),
             HP('I think I\'m a'), HP('My'), err(5, 'freinds'), HP('say'), err(6, 'can to be'),
             err(7, 'dont'), err(8, 'many'), err(9, 'becuase') , HP("when I'm not in class"), HP('when I can, I like'), err(10, 'english')))

def char_toggle(tid):
    return ('<div class="btn-row" style="justify-content:flex-start;"><button class="btn-akey" onclick="toggleSuggested(\'%s\')">📖 Show / hide the profile</button></div>'
            '<div class="akey-box" id="%s" style="background:#fff;">%s</div>') % (tid, tid, CHARLIE)

slide('s-w1', 'Writing – Charlie\'s Profile', '''<div class="slide" id="s-w1">
  <div class="banner banner-speaking">✍️ Writing</div>
  <div class="slide-main"><div class="content">
    <h2>Describing yourself</h2>
    <p class="instruction">Read Charlie's profile and answer the questions.</p>
    <!-- SB Writing 1a (SB p.113). Show the profile as in the book (with the ten mistakes) - the mistakes are corrected in the next slide. TB answers: 1 Carlos 2 Guadalajara, Mexico 3 He's a (physics) student 4 His parents and his dog 5 He has black hair, brown eyes, and a nice nose 6 He's positive and funny, but he can be serious, too 7 He watches TV and plays computer games -->
    <div class="art-two">
      <div>%s</div>
      <div>%s%s%s%s%s%s%s</div>
    </div>
  </div></div>
</div>''' % (CHARLIE, ph('📸', 'Photo: Charlie (Carlos), a smiling young man with black hair, in a blue sweater, in front of a city skyline'),
             qrow(1, "What's Charlie's real name?", 'Carlos.'), qrow(2, "Where's he from?", 'Guadalajara, Mexico.'),
             qrow(3, 'What does he do?', "He's a (physics) student."), qrow(4, 'Who does he live with?', 'His parents (and his dog).'),
             qrow(5, 'What does he look like?', 'He has black hair, brown eyes, and a nice nose.'),
             qrow(6, "What's he like?", "He's positive and funny, but he can be serious, too.") + qrow(7, 'What does he do in his free time?', 'He watches TV series and plays computer games.')))

corr = [(1, "I'm 21 years old", "I am 21 years old|i'm 21|21 years old"), (2, 'studying', ''), (3, 'photo', ''), (4, 'brown', ''), (5, 'friends', ''),
        (6, 'can be', ''), (7, "don't", 'do not'), (8, 'much', ''), (9, 'because', ''), (10, 'English', '')]
def crow(n, a, alt):
    altattr = (' data-alt="%s"' % alt) if alt else ''
    return '<div class="ex-row" style="display:inline-block;width:48%%;"><span class="circ-num">%d</span><input class="ans-input" style="width:200px" data-ans="%s"%s aria-label="correction %d"></div>' % (n, a, altattr, n)
slide('s-w2', 'Writing – Correct the Mistakes', '''<div class="slide" id="s-w2">
  <div class="banner banner-speaking">✍️ Writing</div>
  <div class="slide-main"><div class="content">
    <h2>Find the ten mistakes</h2>
    <p class="instruction">The computer has found ten mistakes in Charlie's profile. They are <b>grammar</b>, <b>punctuation</b>, or <b>spelling</b> mistakes. Can you correct them?</p>
    <!-- SB Writing 1b. TB answers: 1 I'm 21 years old 2 studying 3 photo 4 brown 5 friends 6 can be 7 don't 8 much 9 because 10 English -->
    %s
    <div id="w2">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('w2')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('w2')">Reset</button>
    </div>
    <div class="gram-note">🔤 Remember: <b>English, Spanish, Mexican</b> always start with a capital letter. <b>much</b> + uncountable (<i>much free time</i>) · <b>many</b> + countable (<i>many friends</i>).</div>
  </div></div>
</div>''' % (char_toggle('w2-prof'), ''.join(crow(*c) for c in corr)))

# ------------------------------------------------------------------ Writing 1c: chart
topics = [('work / study, family', 'p2'), ('physical appearance', 'p3'), ('personality', 'p4'), ('hobbies and interests', 'p5')]
wchips = ''.join('<button class="classify-chip" data-ans="%s" onclick="classifyPick(this)">%s</button>' % (t, w) for w, t in topics)
wcols = ''.join('<div class="classify-col" data-target="%s" onclick="classifyTarget(this)"><div class="col-head"><span>Paragraph %s</span></div></div>' % (t, t[1]) for w, t in topics)
phr = [('Paragraph 2', "I'm going to tell you about… · I live with…"), ('Paragraph 3', 'As you can see from the… · My father always says…'),
       ('Paragraph 4', "I think I'm a… · My… say…"), ('Paragraph 5', "…when I'm not in class… · …when I can, I like…")]
phr_rows = '<tr><td class="pn">Paragraph 1</td><td>name, age, nationality</td><td>My name\'s… · Everyone calls me…</td><td><input class="ans-input" type="text" style="width:100%%" aria-label="my information paragraph 1"></td></tr>'
phr_rows = phr_rows.replace('100%%', '100%')
for i, (p, t) in enumerate(phr, 2):
    phr_rows += ('<tr><td class="pn">%s</td><td>%s</td><td>%s</td><td><input class="ans-input" type="text" style="width:100%%" aria-label="my information paragraph %d"></td></tr>'
                 % (p, [w for w, tt in topics if tt == 'p%d' % i][0], t, i)).replace('100%%', '100%')
slide('s-w3', 'Writing – Plan Your Profile', '''<div class="slide" id="s-w3">
  <div class="banner banner-speaking">✍️ Writing</div>
  <div class="slide-main"><div class="content">
    <h2>What goes in each paragraph?</h2>
    <p class="instruction">Write the topic of each paragraph in the correct column. Then check the highlighted phrases from the profile, and plan <b>your</b> profile: add notes to <b>My information</b>.</p>
    <!-- SB Writing 1c, 1d. Paragraph 1 (name, age, nationality) is the example. -->
    <div class="ex-row ex-given"><span class="example-badge">✓</span><b>Paragraph 1:</b> name, age, nationality</div>
    <div class="classify-bank" id="wc-bank">%s</div>
    <div class="classify-cols four" id="wc-cols">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkClassifySlide('wc')">Check Answers</button>
      <button class="btn-reset" onclick="resetClassifySlide('wc')">Reset</button>
    </div>
    <table class="wr-chart">
      <tr><th></th><th>Content</th><th>Phrases</th><th>My information</th></tr>
      %s
    </table>
  </div></div>
</div>''' % (wchips, wcols, phr_rows))

slide('s-w4', 'Writing – Write Your Profile', '''<div class="slide" id="s-w4">
  <div class="banner banner-speaking">✍️ Writing</div>
  <div class="slide-main"><div class="content">
    <h2>Write your profile</h2>
    <p class="instruction">Write your profile. Use your notes and the phrases to help you. Then check your profile for mistakes (grammar, punctuation, and spelling).</p>
    <!-- SB Writing 1e, 1f -->
    <textarea class="write-ta" aria-label="your profile" placeholder="Hi. My name's…"></textarea>
    <ul class="self-check">
      <li><input type="checkbox" aria-label="grammar"> Grammar: <i>I'm 21 years old</i> (not <s>I have 21 years old</s>) · he / she + <b>-s</b></li>
      <li><input type="checkbox" aria-label="punctuation"> Punctuation: capital letters, apostrophes (<i>don't, I'm</i>), full stops</li>
      <li><input type="checkbox" aria-label="spelling"> Spelling: <i>friends, because, photo, studying</i></li>
    </ul>
  </div></div>
</div>''')

# ================================================================== WRAP-UP lock puzzle
def lock(code, q, n):
    return '<div class="lock" data-code="%s"><span class="lock-icon">🔒</span><div class="lock-body"><p class="lock-q">%s</p><input class="lock-input" type="text" oninput="checkLock(this.closest(\'.lock\'))" aria-label="answer %d"></div></div>' % (code, q, n)
slide('s-review', 'Wrap-Up – Find "The One"', '''<div class="slide" id="s-review">
  <div class="banner banner-review">🔓 Wrap-Up</div>
  <div class="slide-main"><div class="content">
    <h2>Find "the one"</h2>
    <p class="instruction">Type the answer in each box to open all four locks and find a match!</p>
    <div class="lock-row">%s%s%s%s</div>
    <div id="lock-win">💘 It's a match! You found "the one"!</div>
    <p class="discuss-label" style="margin-top:20px;">💬 Now ask me about my best friend: <i>What does he / she look like? What's he / she like? What does he / she like doing?</i></p>
  </div></div>
</div>''' % (lock('she often goes to the gym', 'Put the words in order: <i>often / she / goes / to / the / gym</i>', 1),
             lock('talkative', 'A person who talks a lot is <b>t _ _ _ _ _ _ _ _</b> (9 letters)', 2),
             lock('does', 'What ___ she look like? (one word)', 3),
             lock('z|/z/', 'How do you say the final -s in <i>boys</i>: /s/, /z/ or /ɪz/? (type the sound)', 4)))

# ================================================================== HOMEWORK
slide('hw-cover', 'Homework Cover', '''<div class="slide" id="hw-cover">
  <div class="title-inner">
    <div class="hw-badge">📝 Homework</div>
    <div class="title-main">The perfect<br><span class="title-accent">date?</span></div>
  </div>
</div>''')

# ---- HW 1a: cross out the odd word
h1a = [
 ('hair', ['red', 'curly', 'straight', 'tall'], 'tall'),
 ('eyes', ['blonde', 'big', 'blue', 'brown'], 'blonde'),
 ('man', ['thin', 'short', 'long', 'overweight'], 'long'),
 ('woman', ['medium height', 'slim', 'beautiful', 'handsome'], 'handsome'),
]
def h1a_row(n, noun, words, odd):
    g = 'h1a-%d' % n
    btns = ''.join('<button class="circ-opt" data-group="%s" data-correct="%s" onclick="circPick(this)">%s</button>' % (g, odd, w) for w in words)
    return '<div class="ex-row"><span class="circ-num">%d</span><b style="display:inline-block;min-width:70px;">%s</b> %s</div>' % (n, noun, btns)
slide('hw-1a-slide', 'HW1a – Cross Out the Word', '''<!-- WB 1B ex 1a -->
<div class="slide" id="hw-1a-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW1 — Describing people</h2>
    <p class="instruction"><b>a.</b> Click the word that can't be used with the <b>bold</b> noun.</p>
    %s
    <div id="hw1a">%s%s%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkCircSlide('hw1a')">Check Answers</button>
      <button class="btn-reset" onclick="resetCircSlide('hw1a')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<span class="example-badge">1</span><b>hair</b> &nbsp; red · curly · straight · <span class="strike-opt">tall</span>'),
             h1a_row(2, *h1a[1]), h1a_row(3, *h1a[2]), h1a_row(4, *h1a[3])))

# ---- HW 1b: unscramble
h1b = [
 ('Sarah\'s really {} . She makes me laugh.', 'nynfu', 'funny'),
 ('Sam\'s very {} . Everybody likes him.', 'rdfylnei', 'friendly'),
 ('John never does his homework. He\'s very {} .', 'alzy', 'lazy'),
 ('Imogen is a {} girl. She\'ll do well on her exams.', 'artms', 'smart'),
 ('That was a very {} thing to say.', 'dinukn', 'unkind'),
 ('David is very intelligent, but sometimes he says really {} things.', 'updits', 'stupid'),
 ('Paula is really {} . She doesn\'t like meeting new people.', 'hsy', 'shy'),
 ('Laura\'s usually very {} . She doesn\'t talk very much.', 'iuetq', 'quiet'),
]
def h1b_row(n, tpl, scr, ans):
    inp = '<input class="ans-input" style="width:130px" data-ans="%s" aria-label="word %d"> <span class="cue-chip">%s</span>' % (ans, n, scr)
    return '<div class="ex-row"><span class="circ-num">%d</span>%s</div>' % (n, tpl.replace('{} .', inp).replace('{}', inp))
slide('hw-1b-slide', 'HW1b – Order the Letters', '''<!-- WB 1B ex 1b -->
<div class="slide" id="hw-1b-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW1 — Personality</h2>
    <p class="instruction"><b>b.</b> Order the letters to make words that complete the sentences.</p>
    %s
    <div id="hw1b">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('hw1b')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('hw1b')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<span class="example-badge">1</span>Thanks for paying for dinner. That was very %s <span class="cue-chip">enersuog</span>' % green('generous')),
             ''.join(h1b_row(i + 2, *h1b[i]) for i in range(len(h1b)))))

# ---- HW 1c: first letters
def fl(first, ans, n, w=140):
    return '<span class="cue-chip" style="padding:0 8px;">%s</span><input class="ans-input" style="width:%dpx" data-ans="%s" data-alt="%s" aria-label="word %d">' % (first, w, ans, ans[len(first):], n)
h1c = [
 (2, "Tanya's dad doesn't have any hair. He's {b|bald}."),
 (3, "Jamie's new girlfriend is really {e|extroverted}. She loves meeting new people."),
 (4, "My dad never shaves. He has a {b|beard} and a {m|mustache}."),
 (5, "What does your sister look {l|like}? Is she tall and blonde, too?"),
 (6, "When Jake was young, he was very {th|thin}, but now he's a little {o|overweight}."),
 (7, "My dad is really {h|hardworking}. He starts work at 7:00 and gets home at 6:00."),
 (8, "I'm not {l|like} my sister. I don't say much, but she's very {t|talkative}. In fact, she never stops talking."),
 (9, "George is a very {s|serious} student. He works hard and wants to do well."),
 (10, "Dan is really {c|cheap}. He never pays for anything."),
]
import re as _re
def h1c_row(n, tpl):
    k = [0]
    def sub(m):
        k[0] += 1
        f, a = m.group(1), m.group(2)
        return fl(f, a, n * 10 + k[0], 150 if len(a) > 6 else 110)
    return '<div class="ex-row"><span class="circ-num">%d</span>%s</div>' % (n, _re.sub(r'\{([a-z]+)\|([a-z]+)\}', sub, tpl))
slide('hw-1c-slide', 'HW1c – Complete the Sentences', '''<!-- WB 1B ex 1c -->
<div class="slide" id="hw-1c-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW1 — Complete the sentences</h2>
    <p class="instruction"><b>c.</b> Complete the sentences. The first letter is given.</p>
    %s
    <div id="hw1c">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('hw1c')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('hw1c')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<span class="example-badge">1</span>Does your boyfriend have %s eyes or %s eyes?' % (green('brown'), green('blue'))), ''.join(h1c_row(*r) for r in h1c)))

# ---- HW 2a: conversations
def bl(ans, alt='', w=110):
    return '<input class="ans-input" style="width:%dpx" data-ans="%s"%s aria-label="blank">' % (w, ans, (' data-alt="%s"' % alt) if alt else '')
def cv(n, a, b):
    return '<div class="ex-row" style="margin-bottom:12px;"><span class="circ-num">%d</span><b>A</b> %s<br><span style="margin-left:32px;display:inline-block;"><b>B</b> %s</span></div>' % (n, a, b)
h2a = [
 cv(2, '%s Louisa %s to marry her boyfriend? <span class="cue-chip">want</span>' % (bl('Does', '', 70), bl('want', '', 90)), 'Maybe in a few years.'),
 cv(3, "What's the weather like where you live?", "It rains a lot in the winter, but it %s often %s in the summer. <span class=\"cue-chip\">not rain</span>" % (bl("doesn't", 'does not|doesnt', 100), bl('rain', '', 80))),
 cv(4, 'What does José do in the evenings?', 'He %s a lot of TV. <span class="cue-chip">watch</span>' % bl('watches', '', 110)),
 cv(5, '%s your sister %s Spanish? <span class="cue-chip">speak</span>' % (bl('Does', '', 70), bl('speak', '', 90)), 'No, but she speaks English and Italian.'),
 cv(6, '%s you %s Monday to Friday? <span class="cue-chip">work</span>' % (bl('Do', '', 60), bl('work', '', 90)), 'Yes, and I usually work on Saturdays, too.'),
 cv(7, 'How often do you play tennis in the winter?', "We %s very often because it's cold and wet. <span class=\"cue-chip\">not play</span>" % bl("don't play", 'do not play|dont play', 140)),
 cv(8, 'Does your sister like living in Brazil?', 'Yes, she %s it. <span class="cue-chip">love</span>' % bl('loves', '', 100)),
]
slide('hw-2a-slide', 'HW2a – Complete the Conversation', '''<!-- WB 1B ex 2a -->
<div class="slide" id="hw-2a-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW2 — Simple present</h2>
    <p class="instruction"><b>a.</b> Complete the conversation with the simple present form of the verbs in parentheses.</p>
    %s
    <div class="fixed-two-col" id="hw2a"><div>%s</div><div>%s</div></div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('hw2a')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('hw2a')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<span class="example-badge">1</span><b>A</b> <u>Do</u> your parents <u>live</u> together? <span class="cue-chip">live</span><br><span style="margin-left:24px;"><b>B</b> No, they don\'t. They\'re divorced now.</span>'), ''.join(h2a[:4]), ''.join(h2a[4:])))

# ---- HW 2b: adverb position
h2b = [
 ('You are too old to get married. (never)', "You're never too old to get married.", 'You are never too old to get married'),
 ('Candice sees her boyfriend. (every day)', 'Candice sees her boyfriend every day.', ''),
 ('Alice meets people on the internet. (sometimes)', 'Alice sometimes meets people on the internet.', 'Sometimes Alice meets people on the internet'),
 ('It is fun to go on a date. (always)', "It's always fun to go on a date.", 'It is always fun to go on a date'),
 ('I see my wife these days. (hardly ever)', 'I hardly ever see my wife these days.', 'Hardly ever do I see my wife these days'),
 ('I go out during the week. (never)', 'I never go out during the week.', ''),
]
def h2b_row(n, s, a, alt):
    return ('<div class="ex-row"><span class="circ-num">%d</span>%s<br><input class="ans-input" style="width:min(640px,100%%);margin-left:32px;" data-ans="%s"%s aria-label="sentence %d"></div>'
            % (n, s, a, (' data-alt="%s"' % alt) if alt else '', n))
slide('hw-2b-slide', 'HW2b – Adverbs of Frequency', '''<!-- WB 1B ex 2b -->
<div class="slide" id="hw-2b-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW2 — Word order</h2>
    <p class="instruction"><b>b.</b> Rewrite the sentences with the words in parentheses in the correct place. Use contractions where possible.</p>
    %s
    <div id="hw2b">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('hw2b')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('hw2b')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<span class="example-badge">1</span>My dad lives alone and he does not go out. <span class="cue-chip">often</span><br><span class="given-line">%s</span>' % green("My dad lives alone and he doesn't often go out.")),
             ''.join(h2b_row(i + 2, *h2b[i]) for i in range(len(h2b)))))

# ---- HW 2c: My best friend Tabitha
def tb(n, ans, alt='', w=120):
    return '<sup style="font-weight:800;color:#FF4F7B;">%d</sup><input class="ans-input" style="width:%dpx" data-ans="%s"%s aria-label="blank %d">' % (n, w, ans, (' data-alt="%s"' % alt) if alt else '', n)
tabitha = '''<div class="article" style="max-width:100%%;">
  <h3 style="font-family:'Fredoka','Segoe UI',sans-serif;">My best friend Tabitha</h3>
  <p>I am very different from my best friend, Tabitha. Tabitha <sup style="font-weight:800;color:#FF4F7B;">1</sup>%s as a vet, and she %s a lot of money. I'm a student, and I %s music in college. I %s to be a music teacher.</p>
  <p>Tabitha %s in a small house in the country, and I %s an apartment with some friends in the city. We often %s friends for dinner, but Tabitha %s. She's really shy, so she %s being with other people. I'm very extroverted, so I %s to be in a group.</p>
  <p>I %s Tabitha very often because she's usually very busy. But when we're together, we always %s really well. Some people say that opposites attract, and for me and my best friend, it's true.</p>
</div>''' % (green('works'), tb(2, 'earns'), tb(3, 'study'), tb(4, 'want', '', 90), tb(5, 'lives'), tb(6, 'share'), tb(7, 'invite'),
             tb(8, "doesn't come", 'does not come|doesnt come', 150), tb(9, "doesn't like", 'does not like|doesnt like', 150), tb(10, 'prefer'),
             tb(11, "don't see", 'do not see|dont see', 150), tb(12, 'get along', '', 130))
slide('hw-2c-slide', 'HW2c – My Best Friend Tabitha', '''<!-- WB 1B ex 2c -->
<div class="slide" id="hw-2c-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW2 — My best friend Tabitha</h2>
    <p class="instruction"><b>c.</b> Complete the text with the correct form of the words from the list.</p>
    <div class="card" style="font-size:1.12rem;color:var(--navy);"><b>earn · get along · invite · live · not come · not like · not see · prefer · share · study · want · <span class="strike-opt">work</span></b></div>
    %s
    <div id="hw2c">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('hw2c')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('hw2c')">Reset</button>
    </div>
  </div></div>
</div>''' % (ph('📸', 'Photo: two young women smiling in scarves and coats, holding take-away coffee cups, walking in a city street'), tabitha))

# ---- HW 2d: questions about you and Anna
h2d = [
 (2, 'Where / you / live?', 'Where do you live?', 'Where / Anna / live?', 'Where does Anna live?'),
 (3, 'Who / you / live / with?', 'Who do you live with?', 'Who / Anna / live with?', 'Who does Anna live with?'),
 (4, 'you / like going to parties?', 'Do you like going to parties?', 'Anna / like going to parties?', 'Does Anna like going to parties?'),
 (5, 'you / be shy or extroverted?', 'Are you shy or extroverted?', 'Anna / be shy or extroverted?', 'Is Anna shy or extroverted?'),
]
def h2d_row(n, c1, a1, c2, a2):
    return ('<div class="ex-row"><span class="circ-num">%d</span><b>a</b> <span class="cue-chip">%s</span><br><input class="ans-input" style="width:min(560px,100%%);margin-left:32px;" data-ans="%s" aria-label="question %da"><br>'
            '<b style="margin-left:32px;">b</b> <span class="cue-chip">%s</span><br><input class="ans-input" style="width:min(560px,100%%);margin-left:32px;" data-ans="%s" aria-label="question %db"></div>') % (n, c1, a1, n, c2, a2, n)
slide('hw-2d-slide', 'HW2d – Questions about Anna', '''<!-- WB 1B ex 2d -->
<div class="slide" id="hw-2d-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW2 — Questions about you and Anna</h2>
    <p class="instruction"><b>d.</b> Write questions about you and your best friend, Anna.</p>
    %s
    <div id="hw2d">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('hw2d')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('hw2d')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<span class="example-badge">1</span><b>a</b> <span class="cue-chip">What / you / do?</span> → %s<br><b style="margin-left:22px;">b</b> <span class="cue-chip">What / Anna / do?</span> → %s' % (green('What do you do?'), green('What does Anna do?'))),
             ''.join(h2d_row(*r) for r in h2d)))

slide('hw-2e-slide', 'HW2e – Write a Paragraph', '''<!-- WB 1B ex 2e -->
<div class="slide" id="hw-2e-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW2 — A good friend</h2>
    <p class="instruction"><b>e.</b> Think about a good friend. Write a paragraph about the differences between you. Use the text in <b>c</b> and the questions in <b>d</b> to help you.</p>
    <textarea class="write-ta" style="min-height:260px;" aria-label="paragraph about a good friend" placeholder="I am very different from my friend…"></textarea>
  </div></div>
</div>''')

# ---- HW 3: pronunciation (circle the verb with a different final sound)
h3 = [
 ('🐍', 'snake', ['works', 'laughs', 'watches'], 'watches'),
 ('🐍', 'snake', ['lives', 'thinks', 'drinks'], 'lives'),
 ('🦓', 'zebra', ['knows', 'rains', 'likes'], 'likes'),
 ('🦓', 'zebra', ['runs', 'starts', 'goes'], 'starts'),
 ('🐝', '/ɪz/', ['leaves', 'dresses', 'washes'], 'leaves'),
 ('🐝', '/ɪz/', ['teaches', 'cooks', 'uses'], 'cooks'),
]
def h3_row(n, pic, w, opts, odd):
    g = 'h3-%d' % n
    btns = ''.join('<button class="circ-opt" data-group="%s" data-correct="%s" onclick="circPick(this)">%s</button>' % (g, odd, o) for o in opts)
    return '<div class="ex-row" style="display:flex;align-items:center;gap:14px;border-bottom:1px solid #F5D9E3;padding-bottom:8px;"><span class="circ-num">%d</span><span style="min-width:110px;"><span style="font-size:1.8rem;">%s</span> <b>%s</b></span>%s</div>' % (n, pic, w, btns)
slide('hw-3-slide', 'HW3 – Final -s and -es', '''<!-- WB 1B ex 3a + 3b (WB audio 1.2). The book's table has sound pictures snake, snake, zebra, zebra, /ɪz/, /ɪz/ -->
<div class="slide" id="hw-3-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW3 — Pronunciation</h2>
    <p class="instruction"><b>a.</b> Click the verb with a different final sound. <b>b.</b> Then listen and check, and listen again and repeat the words.</p>
    %s
    %s
    <div id="hw3" style="max-width:820px;">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkCircSlide('hw3')">Check Answers</button>
      <button class="btn-reset" onclick="resetCircSlide('hw3')">Reset</button>
    </div>
  </div></div>
</div>''' % (audio('WB1.2'),
             ex_block('<span class="example-badge">1</span>🐍 <b>snake</b> &nbsp; works · laughs · <span class="ok-chip">watches ✓</span>'),
             ''.join(h3_row(i + 2, *h3[i + 1]) for i in range(5))))
