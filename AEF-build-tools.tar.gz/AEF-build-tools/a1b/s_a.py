# -*- coding: utf-8 -*-
# 1B part 1: cover -> vocabulary
S = []   # list of (id, label, html)

def slide(sid, label, html):
    S.append((sid, label, html))

def audio(track):
    return '<div class="audio-box pending"><audio controls data-track="%s"></audio></div>' % track

def green(txt):
    return '<span style="color:#1A7A4A;font-weight:800;background:#E3F5EA;padding:1px 7px;border-radius:5px;">%s</span>' % txt

def ccq(q, a):
    return '<li>%s <button class="ccq-reveal-btn" onclick="this.nextElementSibling.classList.toggle(\'show\')">Show answer</button><span class="ccq-answer">%s</span></li>' % (q, a)

def reveal(label, content, cls='ccq-answer'):
    return '<button class="ccq-reveal-btn" onclick="this.nextElementSibling.classList.toggle(\'show\')">%s</button><span class="%s">%s</span>' % (label, cls, content)

def ph(icon, text, extra=''):
    return '<div class="img-placeholder"%s><span class="ip-icon">%s</span>%s</div>' % (extra, icon, text)

def script_box(sid, inner):
    return ('<div class="btn-row" style="justify-content:flex-start;"><button class="btn-akey" onclick="toggleSuggested(\'%s\')">📜 Script</button></div>'
            '<div class="akey-box" id="%s"><div class="small-script">%s</div></div>') % (sid, sid, inner)

# ------------------------------------------------------------------ COVER
slide('s1', 'Cover', '''<div class="slide active" id="s1">
  <div class="cover-bubble cb1" aria-hidden="true">What does she look like?</div>
  <div class="cover-bubble cb2" aria-hidden="true">He's tall, dark, and handsome!</div>
  <div class="cover-bubble cb3" aria-hidden="true">She's funny and smart.</div>
  <div class="cover-bubble cb4" aria-hidden="true">It's a match!</div>
  <div class="cover-heart h1" aria-hidden="true">💖</div><div class="cover-heart h2" aria-hidden="true">💘</div>
  <div class="cover-heart h3" aria-hidden="true">💗</div><div class="cover-heart h4" aria-hidden="true">💝</div>
  <div class="title-inner">
    <div class="title-label">Conversational English</div>
    <div class="title-sub">with teacher Nanda</div>
    <div class="title-main">The perfect<br><span class="title-accent">date?</span></div>
    <a href="../index.html" title="All AEF Courses" style="position:absolute;bottom:70px;left:32px;font-size:1.7rem;line-height:1;text-decoration:none;filter:drop-shadow(0 1px 3px rgba(0,0,0,.3));z-index:5;">🏠</a>
    <div style="position:absolute;bottom:70px;right:32px;z-index:5;">
      <button onclick="goToId('hw-cover')" style="background:#1C2B3A;color:#fff;border:none;border-radius:10px;padding:11px 24px;font-size:.95rem;font-weight:700;cursor:pointer;letter-spacing:.03em;">📝 Homework</button>
    </div>
  </div>
</div>''')

# ------------------------------------------------------------------ BRIDGE (from 1A: question word order, verb phrases, spelling)
slide('s-bridge', 'Bridge – Sign Up for Spark', '''<div class="slide" id="s-bridge">
  <div class="banner banner-bridge">🌉 Bridge</div>
  <div class="slide-main"><div class="content">
    <h2>Sign up for Spark</h2>
    <p class="instruction">Imagine you're helping me sign up for a dating app called <b>Spark</b>. You need to ask me some questions to complete my account. Write your question in each box, then ask me!</p>
    <!-- Bridge: re-uses 1A learning points - spelling with the alphabet, question word order (Where do you...? What do you...?), and verb phrases (live, work, have, go). No "review" wording. -->
    <div class="party-grid">
      <div class="party-card">
        <div class="pc-icon">🔤</div>
        <h4>Spell it</h4>
        <p>The app needs my <b>last name</b> and my <b>email address</b>. It has to get every letter right.</p>
        <input class="ans-input" type="text" aria-label="ask about spelling">
        %s
      </div>
      <div class="party-card">
        <div class="pc-icon">🏙️</div>
        <h4>Where and what</h4>
        <p>The app needs to know my <b>home</b> and my <b>job</b>. Write two questions.</p>
        <input class="ans-input" type="text" aria-label="where do you live question">
        <input class="ans-input" type="text" aria-label="what do you do question" style="margin-top:8px;">
        %s
      </div>
      <div class="party-card">
        <div class="pc-icon">🐶</div>
        <h4>Free time</h4>
        <p>The app asks about my <b>free time</b>: pets, activities, movies… Write one question.</p>
        <input class="ans-input" type="text" aria-label="free time question">
        %s
      </div>
    </div>
    <div class="gram-note">💬 Now it's your turn to answer! Which questions would <i>you</i> like to see on a dating app?</div>
  </div></div>
</div>''' % (reveal('💡 Possible question', 'How do you spell your last name? / What\'s your email address?'),
             reveal('💡 Possible questions', 'Where do you live? / What do you do?'),
             reveal('💡 Possible question', 'Do you have any pets? / What do you do on the weekend? / What TV shows do you watch?')))

# ------------------------------------------------------------------ WARM-UP: swipe game (new format, different from 1A)
slide('s-warm', 'Warm-Up – Swipe Right or Left?', '''<div class="slide" id="s-warm">
  <div class="banner banner-leadin">🎯 Warm-Up</div>
  <div class="slide-main"><div class="content">
    <h2>Swipe right or left?</h2>
    <p class="instruction">Imagine these are things you read on a dating profile. Swipe <b>right</b> 💚 if you like it, swipe <b>left</b> ✖ if you don't. Always say <i>why</i>!</p>
    <div class="swipe-wrap">
      <div class="swipe-stage" id="swipe-stage"></div>
      <p class="swipe-why" id="swipe-why">I like it because… / I don't like it because…</p>
      <div class="swipe-btns" id="swipe-btns">
        <button class="swipe-btn no" onclick="swipeDo('left')">✖ Swipe left</button>
        <button class="swipe-btn yes" onclick="swipeDo('right')">💚 Swipe right</button>
      </div>
      <div class="swipe-verdict" id="swipe-verdict">
        <p class="sv-big" id="sv-big"></p>
        <p id="sv-text" style="margin:0 0 12px;font-size:1.15rem;font-weight:700;"></p>
        <button class="btn-reset" onclick="swipeInit()">↺ Play again</button>
      </div>
      <div class="swipe-tally" id="swipe-tally"></div>
    </div>
  </div></div>
</div>''')

# ------------------------------------------------------------------ PRE-TEACH (before audio 1.11): Build the dad
def pbtn(grp, val, label, on=False):
    return '<button class="pb-opt%s" data-g="%s" data-v="%s" onclick="prepSet(\'%s\',\'%s\')">%s</button>' % (' on' if on else '', grp, val, grp, val, label)
pb_rows = (
 '<div class="pb-row"><span class="pb-lab">Height</span>%s%s%s</div>' % (pbtn('h','tall','tall'), pbtn('h','med','medium height',True), pbtn('h','short','short')) +
 '<div class="pb-row"><span class="pb-lab">Weight</span>%s%s%s</div>' % (pbtn('b','thin','thin'), pbtn('b','med','average',True), pbtn('b','over','overweight')) +
 '<div class="pb-row"><span class="pb-lab">Hair</span>%s%s%s%s</div>' % (pbtn('c','blond','blond'), pbtn('c','dark','dark',True), pbtn('c','gray','gray'), pbtn('c','bald','bald')) +
 '<div class="pb-row"><span class="pb-lab">Face</span>%s%s%s</div>' % (pbtn('x','glasses','glasses'), pbtn('x','nose','big nose'), pbtn('x','smile','amazing smile')))
pw = [("good-looking", "😍", "attractive — nice to look at"),
      ("unattractive", "😬", "not nice to look at (the opposite of <i>good-looking</i>)"),
      ("overweight", "⚖️", "too heavy for your height"),
      ("serious", "😐", "doesn't smile or laugh much"),
      ("a sense of humor", "😂", "you understand jokes and you make people laugh"),
      ("talkative", "🗣️", "talks a lot"),
      ("careful", "🧐", "thinks before doing something, to avoid problems")]
pwcards = ''.join('<button class="verb-card" onclick="this.classList.toggle(\'open\')"><span class="vc-verb">%s %s</span><span class="vc-hint">what does it mean?</span><span class="vc-partner">%s</span></button>' % (e, w, m) for w, e, m in pw)
slide('s-prep', 'Pre-teach – Build the Dad', '''<div class="slide" id="s-prep">
  <div class="banner banner-leadin">🎯 Lead-in</div>
  <div class="slide-main"><div class="content">
    <h2>Build the dad!</h2>
    <p class="instruction">Listen and click the words to build the dad you hear about. Then describe him to me!</p>
    <!-- Pre-teaches the appearance vocabulary of audio 1.11 (tall / short, thin / overweight, blond / dark / gray hair, glasses, big nose, amazing smile). Warm-up audio: one dad. -->
    %s
    <div class="pb-layout">
      <div class="pb-stage"><svg id="pb-svg" viewBox="0 0 320 340" width="100%%" role="img" aria-label="A dad you can build"></svg>
        <div class="pb-ref">👧 Charlotte</div></div>
      <div class="pb-panel">
        %s
        <div class="btn-row" style="justify-content:flex-start;">
          <button class="btn-reset" onclick="prepReset()">Reset</button>
        </div>
      </div>
    </div>
  </div></div>
</div>''' % (audio('1.11w'), pb_rows))

# ------------------------------------------------------------------ LEAD-IN: family word web
def famcard(title, eg, sugg):
    return '''<div class="fam-card"><h4>%s</h4><div class="fam-eg">e.g., <i>%s</i></div>
      <input class="ans-input" type="text" aria-label="%s word 1"><input class="ans-input" type="text" aria-label="%s word 2"><input class="ans-input" type="text" aria-label="%s word 3">
      <button class="ccq-reveal-btn" onclick="this.nextElementSibling.classList.toggle('show')">💡 More words</button>
      <div class="fam-sugg">%s</div></div>''' % (title, eg, title, title, title, sugg)
slide('s-lead', 'Lead-in – Family Words', '''<div class="slide" id="s-lead">
  <div class="banner banner-leadin">🎯 Lead-in</div>
  <div class="slide-main"><div class="content">
    <h2>Family words</h2>
    <p class="instruction">Write more words in each category. Then click to see some more ideas.</p>
    <!-- Optional lead-in (TB 1B, books closed): direct family / other relatives / husband's or wife's family -->
    <div class="fam-grid">%s%s%s</div>
    <div class="gram-note">🔊 Careful with the pronunciation of <b>daughter</b> /ˈdɔtər/ — the <i>gh</i> is silent.</div>
    <p class="discuss-label" style="margin-top:16px;">💬 Ask me: <i>What does your father look like?</i> How would you describe him in a few words?</p>
  </div></div>
</div>''' % (famcard('DIRECT FAMILY', 'mother', 'father, sister, brother, son, daughter, husband, wife, parents, children'),
             famcard('OTHER RELATIVES', 'grandmother', 'grandfather, aunt, uncle, cousin, niece, nephew, grandson, granddaughter'),
             famcard("HUSBAND'S / WIFE'S FAMILY", 'mother-in-law', 'father-in-law, brother-in-law, sister-in-law, son-in-law, daughter-in-law')))

# ------------------------------------------------------------------ 1a: three women (1.11)
script111 = '''<p><b>1</b> My dad's very tall and thin, with a big nose. He looks a bit like a tall, thin bird! He has blond hair and blue eyes, which is typical of Sweden – his grandmother was from Sweden. Um, he looks a bit serious, but he isn't, really. He's very funny – he has a great sense of humor.</p>
<p><b>2</b> I think my dad's very good-looking. He's not very tall – a little taller than me – and he still has his hair: it was dark, but it's gray now. He's not thin, but he isn't overweight. He's careful about what he eats. And he has an amazing smile.</p>
<p><b>3</b> My dad's short and thin, and he wears glasses. He isn't exactly good-looking, but he's not unattractive, either. He's very friendly, and very talkative. In fact, he never stops talking.</p>'''
def circ_opt_btn(g, text, correct):
    return '<button class="circ-opt" data-group="%s" data-correct="%s" onclick="circPick(this)">%s</button>' % (g, correct, text)
slide('s-v1a', 'Vocabulary & Reading – Three Women', '''<div class="slide" id="s-v1a">
  <div class="banner banner-vocab">📚 Vocabulary &amp; Reading</div>
  <div class="slide-main"><div class="content">
    <h2>Describing people</h2>
    <p class="instruction">Listen to three women describing their fathers. Which one is Charlotte, the woman with her father in the two photos?</p>
    <!-- SB 1.11. Answer: speaker 2 (Charlotte). -->
    %s
    <div class="photo-strip" style="grid-template-columns:repeat(2,1fr);">
      %s
      %s
    </div>
    <div class="speaker-row" id="v1a">
      <div class="speaker-card"><div class="sp-pic">👩</div>%s</div>
      <div class="speaker-card"><div class="sp-pic">👩‍🦰</div>%s</div>
      <div class="speaker-card"><div class="sp-pic">👩‍🦳</div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkCircSlide('v1a')">Check Answer</button>
      <button class="btn-reset" onclick="resetCircSlide('v1a')">Reset</button>
    </div>
    <div class="ccq-box"><p class="ccq-label">💭 Which words helped you decide?</p>
      <ul class="ccq-list">%s</ul></div>
    %s
  </div></div>
</div>''' % (audio('1.11'),
             ph('📸', 'Photo: Charlotte (26, dark hair) laughing and holding a party popper, next to her father Clint (52, gray hair, dark suit and bow tie) – confetti flying'),
             ph('📸', 'Photo: Charlotte straightening her father Clint\'s bow tie; he is smiling with his eyes closed'),
             circ_opt_btn('v1a', 'Speaker 1', 'Speaker 2'),
             circ_opt_btn('v1a', 'Speaker 2', 'Speaker 2'),
             circ_opt_btn('v1a', 'Speaker 3', 'Speaker 2'),
             ccq('What does Charlotte say about her dad\'s <b>height</b>?', '<i>He\'s not very tall – a little bit taller than me.</i>') + ccq('…and about his <b>looks</b>?', '<i>He\'s very good-looking.</i>'),
             script_box('v1a-script', script111)))

# ------------------------------------------------------------------ 1b: listen again (1.12)
def vrow2(n, label, ans, alt, hint=''):
    return '<div class="ex-row"><span class="circ-num">%d</span><b>%s</b> %s<input class="ans-input" style="width:min(520px,100%%)" data-ans="%s" data-alt="%s" aria-label="%s"></div>' % (n, label, hint, ans, alt, label)
slide('s-v1b', 'Vocabulary & Reading – Listen Again', '''<div class="slide" id="s-v1b">
  <div class="banner banner-vocab">📚 Vocabulary &amp; Reading</div>
  <div class="slide-main"><div class="content">
    <h2>Charlotte's father</h2>
    <p class="instruction">Listen to Charlotte again. What adjectives does she use to describe her father's <b>height, hair, weight,</b> and <b>smile</b>?</p>
    <!-- SB 1.12. TB answers: height = not very tall; hair = was dark, now gray; weight = not thin, but isn't overweight; smile = amazing. -->
    %s
    <div id="v1b">%s%s%s%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('v1b')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('v1b')">Reset</button>
    </div>
    <div class="gram-note">✏️ <b>height</b> /haɪt/ and <b>weight</b> /weɪt/ end in the same sound — but they're spelled differently! Can you spell <b>overweight</b>?</div>
    <div class="ccq-box"><p class="ccq-label">💭 Check your understanding</p>
      <ul class="ccq-list">%s%s</ul></div>
    <p class="discuss-label" style="margin-top:14px;">🗣️ Compare with me. Listen once more: <i>I think my dad's very good-looking. He's not very tall – a little taller than me – and he still has his hair: it was dark, but it's gray now. He's not thin, but he isn't overweight. He's careful about what he eats. And he has an amazing smile.</i></p>
  </div></div>
</div>''' % (audio('1.12'),
             vrow2(1, 'height:', 'not very tall', 'not tall|a little taller than me|a little bit taller than me|not very tall - a little taller than me'),
             vrow2(2, 'hair:', 'dark, now gray', 'dark but gray now|was dark now gray|dark, but gray now|gray|dark and gray|dark'),
             vrow2(3, 'weight:', "not thin, but not overweight", "not thin but isn't overweight|not thin, but isn't overweight|not thin|not overweight|isn't overweight|not thin but not overweight"),
             vrow2(4, 'smile:', 'amazing', 'an amazing smile|amazing smile'),
             ccq('Is her dad <b>thin</b>?', 'No — he\'s <i>not thin</i>, but he\'s also <i>not overweight</i>: in the middle.'),
             ccq('Does he <b>still</b> have dark hair?', 'No. It was dark <i>before</i>, but it\'s gray <i>now</i>. He still has his hair (he isn\'t bald).')))

# ------------------------------------------------------------------ Vocab Bank 1: appearance - match photos (1.13)
sent = [  # (letter, sentence, photo number)
 ('a', 'She has curly red hair.', 2), ('b', 'She has long straight hair.', 3), ('c', 'She has big blue eyes.', 1),
 ('d', 'She has short blonde hair.', 6), ('e', 'He has a beard and a mustache.', 5), ('f', "He's bald.", 4),
 ('g', "He's very tall and thin.", 7), ('h', "He's medium height and very slim.", 9), ('i', "He's short and a little overweight.", 8)]
photo_desc = {1:'a baby with big blue eyes', 2:'a woman with curly red hair', 3:'a woman with long straight dark hair', 4:'a bald man', 5:'a man with a beard and a mustache',
              6:'a woman with short blonde hair', 7:'a very tall, thin young man', 8:'a short man, a little overweight, in a blue shirt and jeans', 9:'a medium-height, very slim man in a black tank top and red pants'}
phtml = ''
for n in range(1, 10):
    if n == 1:
        phtml += '<div class="match-item example-pair"><span class="circ-num">1</span>🖼️ Photo 1</div>'
    else:
        phtml += '<div class="match-item" data-side="left" data-pair="%d" onclick="matchPick(this)"><span class="circ-num">%d</span>🖼️ Photo %d</div>' % (n, n, n)
shtml = ''
for l, s, p in sent:
    if p == 1:
        shtml += '<div class="match-item example-pair"><span class="circ-num">%s</span>%s</div>' % (l, s)
    else:
        shtml += '<div class="match-item" data-side="right" data-pair="%d" onclick="matchPick(this)"><span class="circ-num">%s</span>%s</div>' % (p, l, s)
photo_comment = '; '.join('Photo %d = %s' % (k, v) for k, v in photo_desc.items())
slide('s-app1', 'Vocabulary – Appearance Match', '''<div class="slide" id="s-app1">
  <div class="banner banner-vocab">📚 Vocabulary</div>
  <div class="slide-main"><div class="content">
    <h2>What does he / she look like?</h2>
    <p class="instruction">Match the sentences to the photos. Then listen and check.</p>
    <!-- Vocabulary Bank 1 Appearance ex a (photo 1 = example: big blue eyes). IMAGES TO ADD: %s -->
    <div class="match-wrap" id="app1-match">
      <div><div class="match-col-head mc-left">Photos</div>%s</div>
      <div><div class="match-col-head mc-right">Sentences</div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkMatchSlide('app1-match')">Check Answers</button>
      <button class="btn-reset" onclick="resetMatchSlide('app1-match')">Reset</button>
    </div>
    <!-- VB 1.13 -->
    %s
    <div class="photo-strip" style="grid-template-columns:repeat(3,1fr);">
      %s %s %s
    </div>
    <p class="discuss-label" style="margin-top:8px;">🖼️ Replace the placeholders with photos 1–9 (the nine people in the Vocabulary Bank).</p>
  </div></div>
</div>''' % (photo_comment, phtml, shtml, audio('1.13'),
             ph('🖼️', 'Photos 1–3: a baby; a woman with curly red hair; a woman with long dark hair'),
             ph('🖼️', 'Photos 4–6: a bald man; a man with a beard; a woman with short blonde hair'),
             ph('🖼️', 'Photos 7–9: a tall thin man; a short man in a blue shirt; a very slim man in a black top')))

# ------------------------------------------------------------------ Vocab Bank 1: using two adjectives together + word choices (CCQ)
def ord_row(n, words, ans):
    return ('<div class="ex-row"><span class="circ-num">%d</span><span class="order-chip" style="margin-right:6px;">%s</span><br>'
            '<input class="ans-input" style="width:min(520px,100%%);margin-left:32px;" data-ans="%s" aria-label="order %d"></div>') % (n, words.replace(' / ', '</span> <span class="order-chip">'), ans, n)
slide('s-app2', 'Vocabulary – Two Adjectives & Careful Words', '''<div class="slide" id="s-app2">
  <div class="banner banner-vocab">📚 Vocabulary</div>
  <div class="slide-main"><div class="content">
    <h2>Using two adjectives together</h2>
    <p class="inst-light">Adjectives go in this order:</p>
    <!-- Vocabulary Bank 1 info box: size -> style -> color noun -->
    <div class="order-strip"><span class="order-chip">size</span><span class="order-arrow">→</span><span class="order-chip">style</span><span class="order-arrow">→</span><span class="order-chip">color</span><span class="order-arrow">→</span><span class="order-chip">noun</span></div>
    <div class="mini-two">
      <div class="card" style="margin:0;"><i>She has <b>long straight blonde</b> hair.</i><br><i>He has <b>big brown</b> eyes.</i></div>
      <div class="card" style="margin:0;"><b>Your turn:</b> put the words in order.
        <div id="app2-ord">
          %s
          %s
        </div>
        <div class="btn-row" style="margin-top:6px;"><button class="btn-check" onclick="checkSlide('app2-ord')">Check</button><button class="btn-reset" onclick="resetSlide('app2-ord')">Reset</button></div>
      </div>
    </div>
    <div class="ccq-box"><p class="ccq-label">💭 Careful with these words!</p>
      <ul class="ccq-list">
        %s
        %s
        %s
        %s
      </ul>
    </div>
    <div class="gram-note">🔊 Silent letters: <b>handsome</b> (silent <i>d</i>) · <b>height</b> /haɪt/ · <b>weight</b> /weɪt/ · <b>mustache</b> /ˈmʌstæʃ/ · <b>beard</b> /bɪrd/</div>
  </div></div>
</div>''' % (ord_row(1, 'blonde / hair / short', 'short blonde hair'),
             ord_row(2, 'eyes / blue / big', 'big blue eyes'),
             ccq('<b>thin</b> or <b>slim</b>? Which one is a compliment (positive)?', '<b>Slim</b> = thin in an attractive way. Both are the opposite of <i>fat</i>.'),
             ccq('Is it polite to say <i>"He\'s fat"</i>?', 'No — <i>fat</i> is not very polite. It is more polite to say someone is <b>(a little) overweight</b>.'),
             ccq('<b>handsome</b> or <b>beautiful</b>: which word is for a man? For a woman?', '<b>Handsome</b> → men. <b>Beautiful</b> → women. <b>Good-looking</b> and <b>attractive</b> → both men and women.'),
             ccq('<i>"blonde"</i> or <i>"blond"</i>?', '<b>blonde</b> for women\'s / girls\' hair; <b>blond</b> for men\'s / boys\' hair (same sound).')))

# ------------------------------------------------------------------ Vocab bank 1: cover & test (photo flip cards)
pf = ''
for n in range(1, 10):
    sentence = [s for l, s, p in sent if p == n][0]
    pf += '<div class="pflip"><span class="pf-n">Photo %d</span>%s<button class="ccq-reveal-btn" onclick="this.nextElementSibling.classList.toggle(\'show\')">💡 Say it, then check</button><div class="pf-phrase">%s</div></div>' % (n, ph('🖼️', 'Photo %d' % n), sentence)
slide('s-app3', 'Vocabulary – Cover and Test Yourself', '''<div class="slide" id="s-app3">
  <div class="banner banner-vocab">📚 Vocabulary</div>
  <div class="slide-main"><div class="content">
    <h2>Describe the photo</h2>
    <p class="instruction">Look at each photo and describe the person. Then click to check your sentence.</p>
    <!-- Vocabulary Bank 1 ex c: cover the phrases and look at the photos, test yourself or a partner. Same photos 1-9. -->
    <div class="photo-flip-grid">%s</div>
  </div></div>
</div>''' % pf)

# ------------------------------------------------------------------ What does she look like? What is she like?
def circ_row(n, pre, o1, o2, correct, post=''):
    g = 'wh-%d' % n
    return '<div class="ex-row"><span class="circ-num">%d</span>%s<br><span style="margin-left:32px;">%s<span class="circ-sep">/</span>%s</span></div>' % (n, pre, circ_opt_btn(g, o1, correct), circ_opt_btn(g, o2, correct))
LOOK = 'What does he / she look like?'
LIKE = 'What is he / she like?'
whrows = [
 (1, '"<i>She has short blonde hair and blue eyes.</i>"', LOOK, LIKE, LOOK),
 (2, '"<i>He\'s very friendly and funny.</i>"', LOOK, LIKE, LIKE),
 (3, '"<i>He\'s tall, dark, and handsome.</i>"', LOOK, LIKE, LOOK),
 (4, '"<i>She\'s shy, but she\'s very kind.</i>"', LOOK, LIKE, LIKE),
 (5, '"<i>He\'s bald, and he has a beard.</i>"', LOOK, LIKE, LOOK),
 (6, '"<i>She\'s smart and hardworking.</i>"', LOOK, LIKE, LIKE),
]
slide('s-app4', 'Vocabulary – Look Like or Like?', '''<div class="slide" id="s-app4">
  <div class="banner banner-vocab">📚 Vocabulary</div>
  <div class="slide-main"><div class="content">
    <h2>What does she look like? What is she like?</h2>
    <p class="inst-light">These two questions are very different!</p>
    <!-- Vocabulary Bank info box. Meaning first: CCQs, then a quick sort. -->
    <div class="chat" style="max-width:640px;"><div class="bub a"><span class="who">A</span>What does she look like?</div><div class="bub b"><span class="who">B</span>She has blonde hair and blue eyes.</div></div>
    <div class="mini-two">
      <div class="gram-box" style="margin:0;"><h3>What does she look like?</h3><p>= Tell me about her <span class="hl">appearance</span>.</p><p><i>Is she tall / short? What color hair does she have?</i></p></div>
      <div class="gram-box" style="margin:0;"><h3>What is she like?</h3><p>= Tell me what kind of <span class="hl">person</span> she is.</p><p><i>Is she friendly? Is she shy?</i></p></div>
    </div>
    <div class="ccq-box"><p class="ccq-label">💭 Check your understanding</p>
      <ul class="ccq-list">
        %s
        %s
      </ul>
    </div>
    <p class="instruction" style="margin-top:16px;">Which question does each answer match? Click the correct question.</p>
    <div id="app4">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkCircSlide('app4')">Check Answers</button>
      <button class="btn-reset" onclick="resetCircSlide('app4')">Reset</button>
    </div>
  </div></div>
</div>''' % (ccq('You want to know if a new colleague is <b>tall or short</b>. Which question do you ask?', '<i>What does she look like?</i>'),
             ccq('You want to know if your friend\'s boyfriend is <b>friendly or shy</b>. Which question?', '<i>What is he like?</i>'),
             ''.join(circ_row(*r) for r in whrows)))

# ------------------------------------------------------------------ Vocab Bank 2: personality definitions (a)
defs = [
 (1, 'A person who is open and warm is', 'friendly', None),
 (2, 'A person who talks a lot is', 'talkative', None),
 (3, 'A person who likes giving people things is', 'generous', None),
 (4, 'A person who is friendly and good to other people is', 'kind', None),
 (5, "A person who doesn't want to work is", 'lazy', None),
 (6, 'A person who makes people laugh is', 'funny', None),
 (7, 'A person who is quick at learning and understanding things is', 'smart', None),
 (8, "A person who can't talk easily to people he / she doesn't know is", 'shy', None),
]
def defrow(n, d, a):
    if n == 1:
        return '<div class="ex-row"><span class="example-badge">1</span>%s %s</div>' % (d, green('friendly'))
    return '<div class="ex-row"><span class="circ-num">%d</span>%s <input class="ans-input" style="width:150px" data-ans="%s" aria-label="adjective %d"></div>' % (n, d, a, n)
bank_a = ' · '.join('<b>%s</b> %s' % (w, p) for w, p in [('friendly', '/ˈfrɛndli/'), ('funny', '/ˈfʌni/'), ('shy', '/ʃaɪ/'), ('generous', '/ˈdʒɛnərəs/'), ('kind', '/kaɪnd/'), ('lazy', '/ˈleɪzi/'), ('smart', '/smɑrt/'), ('talkative', '/ˈtɔkətɪv/')])
slide('s-per1', 'Vocabulary – Personality (a)', '''<div class="slide" id="s-per1">
  <div class="banner banner-vocab">📚 Vocabulary</div>
  <div class="slide-main"><div class="content">
    <h2>Personality: What's he / she like?</h2>
    <p class="instruction">Match the adjectives to the definitions: write the adjective.</p>
    <!-- Vocabulary Bank 2 Personality ex a. Book numbers the example 1 (friendly). -->
    <div class="card" style="font-size:1.1rem;line-height:1.9;color:var(--navy);">%s</div>
    <div id="per1">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('per1')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('per1')">Reset</button>
    </div>
  </div></div>
</div>''' % (bank_a, ''.join(defrow(*d[:3]) for d in defs)))

# ------------------------------------------------------------------ Vocab Bank 2: opposites (b) + 1.14
opps = [(1, 'friendly', 'unfriendly'), (2, 'talkative', 'quiet'), (3, 'generous', 'cheap'), (4, 'kind', 'unkind'),
        (5, 'lazy', 'hardworking'), (6, 'funny', 'serious'), (7, 'smart', 'stupid'), (8, 'shy', 'extroverted')]
bank_b = ' · '.join('<b>%s</b> %s' % (w, p) for w, p in [('cheap', '/tʃip/'), ('extroverted', '/ˈɛkstrəˌvɜrtɪd/'), ('hardworking', '/ˌhɑrdˈwɜrkɪŋ/'), ('quiet', '/ˈkwaɪət/'), ('serious', '/ˈsɪriəs/'), ('stupid', '/ˈstupəd/'), ('unfriendly', '/ʌnˈfrɛndli/'), ('unkind', '/ʌnˈkaɪnd/')])
def opprow(n, a, o):
    if n == 1:
        return '<div class="ex-row"><span class="circ-num">1</span><span style="display:inline-block;width:150px;font-weight:800;">%s</span> ↔ <input class="ans-input" style="width:180px" data-ans="%s" aria-label="opposite %d"></div>' % (a, o, n)
    return '<div class="ex-row"><span class="circ-num">%d</span><span style="display:inline-block;width:150px;font-weight:800;">%s</span> ↔ <input class="ans-input" style="width:180px" data-ans="%s" aria-label="opposite %d"></div>' % (n, a, o, n)
slide('s-per2', 'Vocabulary – Personality (b, c)', '''<div class="slide" id="s-per2">
  <div class="banner banner-vocab">📚 Vocabulary</div>
  <div class="slide-main"><div class="content">
    <h2>Opposites</h2>
    <p class="instruction">Complete the <b>Opposite</b> column with an adjective from the list. Then listen and check.</p>
    <!-- Vocabulary Bank 2 Personality ex b, c (VB 1.14) -->
    <div class="card" style="font-size:1.1rem;line-height:1.9;color:var(--navy);">%s</div>
    <div id="per2">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('per2')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('per2')">Reset</button>
    </div>
    %s
    <div class="gram-note">🇺🇸 In American English, <b>mean</b> = <i>unkind</i>. In British English people say <b>mean</b> instead of <b>cheap</b> (= doesn't like spending money).</div>
  </div></div>
</div>''' % (bank_b, ''.join(opprow(*o) for o in opps), audio('1.14')))

# ------------------------------------------------------------------ personality: CCQ meaning check + cover & say
slide('s-per3', 'Vocabulary – Check the Meaning', '''<div class="slide" id="s-per3">
  <div class="banner banner-vocab">📚 Vocabulary</div>
  <div class="slide-main"><div class="content">
    <h2>Are you sure you understand?</h2>
    <p class="instruction">Answer the questions. Click to check.</p>
    <!-- CELTA-style CCQs for the personality adjectives (Vocabulary Bank 2 ex d: cover the adjectives and say the adjective + opposite). -->
    <div class="ccq-box"><p class="ccq-label">💭 CCQs</p>
      <ul class="ccq-list">
        %s%s%s%s%s%s%s%s
      </ul>
    </div>
    <div class="gram-note">🗣️ <b>Cover and say:</b> look at the definitions on the previous slides, cover the adjectives, and say each adjective <i>and</i> its opposite. e.g., <i>friendly – unfriendly</i>.</div>
    <div class="gram-note">🔊 Stress: <b>GEN</b>erous · <b>EX</b>troverted · <b>HARD</b>working · <b>QUI</b>et (two syllables!) · <b>TALK</b>ative · <b>SE</b>rious</div>
  </div></div>
</div>''' % (ccq('Does a <b>lazy</b> person work hard?', 'No. A lazy person doesn\'t want to work. The opposite is <b>hardworking</b>.'),
             ccq('Is a <b>shy</b> person comfortable with new people?', 'No — he / she can\'t talk easily to people he / she doesn\'t know. The opposite is <b>extroverted</b>.'),
             ccq('Does a <b>generous</b> person like giving things to people?', 'Yes. The opposite is <b>cheap</b> (he / she never pays for anything).'),
             ccq('Is a <b>talkative</b> person quiet?', 'No — a talkative person talks a lot (<i>he never stops talking</i>). The opposite is <b>quiet</b>.'),
             ccq('If someone is <b>funny</b>, what do you do when you are with him / her?', 'You laugh! The opposite is <b>serious</b>.'),
             ccq('Is a <b>smart</b> person good at learning things?', 'Yes. The opposite is <b>stupid</b>.'),
             ccq('Is a <b>kind</b> person good to other people?', 'Yes. The opposite is <b>unkind</b> (in American English, also <b>mean</b>).'),
             ccq('Is a <b>friendly</b> person open and warm?', 'Yes. The opposite is <b>unfriendly</b>.')))

# ------------------------------------------------------------------ GAME: matchmaker
mm = [
 ("Clint is looking for a partner who is <b>independent, funny, and smart</b>.", [("Dina", "shy, lazy, stupid"), ("Helen", "smart, funny, independent"), ("Rita", "quiet, serious, cheap")], 'Helen'),
 ("Maria wants a man who is <b>generous and kind</b>, with <b>a beard</b>.", [("Tom", "cheap, unkind, bald"), ("Mark", "generous, kind, a beard"), ("Joe", "lazy, shy, a mustache")], 'Mark'),
 ("Sam hates quiet people. He wants a partner who is <b>talkative and extroverted</b>.", [("Lena", "shy, quiet, serious"), ("Paula", "talkative, extroverted, funny"), ("Ana", "quiet, hardworking, kind")], 'Paula'),
 ("Ellen works 12 hours a day. She wants a <b>hardworking</b> and <b>serious</b> man — not <b>lazy</b>!", [("Pete", "lazy, funny, talkative"), ("Carl", "hardworking, serious, smart"), ("Nick", "lazy, stupid, cheap")], 'Carl'),
 ("Alex is a <b>tall, slim</b> woman with <b>long straight dark hair</b>. Who's the best <i>look-alike</i> for her profile photo?", [("Meg", "short, overweight, curly red hair"), ("Zoe", "tall, slim, long straight dark hair"), ("Kim", "medium height, short blonde hair")], 'Zoe'),
]
mmhtml = ''
for i, (q, opts, corr) in enumerate(mm, 1):
    g = 'mm-%d' % i
    btns = ''.join('<button class="circ-opt" data-group="%s" data-correct="%s" onclick="circPick(this)"><b>%s</b>: %s</button>' % (g, '%s: %s' % (n, d), n, d) for n, d in opts)
    # circ check compares textContent to data-correct -> keep the same text ("Name: desc")
    mmhtml += '<div class="ex-row"><span class="circ-num">%d</span>%s<br><span style="margin-left:32px;display:inline-block;margin-top:6px;">%s</span></div>' % (i, q, btns)
slide('s-game1', 'Game – The Matchmaker', '''<div class="slide" id="s-game1">
  <div class="banner banner-speaking">🎮 Game</div>
  <div class="slide-main"><div class="content">
    <h2>The Matchmaker</h2>
    <p class="instruction">You're the matchmaker at Spark! Read what each person wants and click the best match. Then say why: <i>She's a good match because she's…</i></p>
    <div id="game1">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkCircSlide('game1')">Check Matches</button>
      <button class="btn-reset" onclick="resetCircSlide('game1')">Reset</button>
    </div>
  </div></div>
</div>''' % mmhtml)

# ------------------------------------------------------------------ Activation (VB): describe a family member or friend
slide('s-act1', 'Speaking – Describe Someone', '''<div class="slide" id="s-act1">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Tell me about…</h2>
    <p class="instruction">Ask and answer questions with your teacher about a member of your family or a good friend. Draw a person and a question!</p>
    <!-- Vocabulary Bank 1 Activation + 2 Activation (TB: back to main lesson 1B) -->
    <div class="chat" style="max-width:760px;">
      <div class="bub a"><span class="who">A</span>What does your sister look like?</div>
      <div class="bub b"><span class="who">B</span>She's very tall and she has short dark hair.</div>
      <div class="bub a"><span class="who">A</span>What's she like?</div>
    </div>
    <div class="roul-layout">
      <div class="roul-ball empty" id="dg-ball" style="font-size:2.6rem;">👤</div>
      <div class="roul-prompt card" style="margin:0;">
        <p class="roul-q" id="dg-q">Press the button to draw a person and a question.</p>
        <p class="roul-sub" id="dg-sub"></p>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-roul" onclick="dgDraw()">🎲 Draw a card</button>
      <button class="btn-reset" onclick="dgReset()">Reset</button>
    </div>
  </div></div>
</div>''')
