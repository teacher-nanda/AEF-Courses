
/* ===================== AUDIO FILES (fill in when the files are available) ===================== */
var AUDIO = {
  '1.11':'', '1.12':'', '1.13':'', '1.14':'', '1.15':'', '1.16':'', '1.17':'', '1.18':'', '1.19':'', '1.20':'', '1.21':'', '1.22':'', 'WB1.2':'', '1.11w':'AEF3e_Level_2_SB_1.11-warmup.mp3'
};
document.querySelectorAll('audio[data-track]').forEach(function(a){
  var f = AUDIO[a.dataset.track];
  if (f) { a.src = f; var box = a.closest('.audio-box'); if (box) box.classList.remove('pending'); }
});


/* ===================== WARM-UP: SWIPE GAME ===================== */
var SWIPE_CARDS = [
  ["💸", "He always pays for dinner."],
  ["📱", "She checks her phone every five minutes."],
  ["⏰", "He's never late."],
  ["🗣️", "She talks about her ex all night."],
  ["🎂", "He remembers your birthday every year."],
  ["🙏", "She never says thank you."]
];
var swipeIdx = 0, swipeRight = 0, swipeBusy = false;
function swipeRender(){
  var stage = document.getElementById('swipe-stage');
  if (!stage) return;
  stage.innerHTML = '';
  if (swipeIdx >= SWIPE_CARDS.length) return;
  var c = SWIPE_CARDS[swipeIdx];
  var d = document.createElement('div');
  d.className = 'swipe-card'; d.id = 'swipe-card';
  d.innerHTML = '<div class="sw-emoji">' + c[0] + '</div><div class="sw-text">' + c[1] + '</div><div class="sw-count">' + (swipeIdx + 1) + ' / ' + SWIPE_CARDS.length + '</div>';
  stage.appendChild(d);
}
function swipeInit(){
  swipeIdx = 0; swipeRight = 0; swipeBusy = false;
  document.getElementById('swipe-verdict').classList.remove('show');
  document.getElementById('swipe-btns').style.display = 'flex';
  document.getElementById('swipe-why').textContent = "I like it because… / I don't like it because…";
  document.getElementById('swipe-tally').textContent = '';
  swipeRender();
}
function swipeDo(dir){
  if (swipeBusy || swipeIdx >= SWIPE_CARDS.length) return;
  swipeBusy = true;
  var card = document.getElementById('swipe-card');
  card.classList.add(dir === 'right' ? 'gone-right' : 'gone-left');
  if (dir === 'right') swipeRight++;
  document.getElementById('swipe-why').textContent = dir === 'right' ? 'Swipe right! Why do you like it? I like it because…' : "Swipe left! Why don't you like it? I don't like it because…";
  setTimeout(function(){
    swipeIdx++; swipeBusy = false;
    document.getElementById('swipe-tally').textContent = '💚 ' + swipeRight + ' right  ·  ✖ ' + (swipeIdx - swipeRight) + ' left';
    if (swipeIdx >= SWIPE_CARDS.length){
      document.getElementById('swipe-stage').innerHTML = '';
      document.getElementById('swipe-btns').style.display = 'none';
      var big, txt;
      if (swipeRight >= 5){ big = '💚 Easy to please!'; txt = 'You swiped right on almost everyone. You see the good in people!'; }
      else if (swipeRight >= 3){ big = '⚖️ Balanced!'; txt = 'You know what you like and what you don\'t. A good matchmaker!'; }
      else { big = '🧐 Super picky!'; txt = 'You swiped left on almost everyone. Your perfect date has to be really perfect!'; }
      document.getElementById('sv-big').textContent = big;
      document.getElementById('sv-text').textContent = txt + '  (' + swipeRight + ' / ' + SWIPE_CARDS.length + ' right swipes)';
      document.getElementById('swipe-verdict').classList.add('show');
    } else { swipeRender(); }
  }, 380);
}
swipeInit();

/* ===================== SPEAKING: DRAW A PERSON + A QUESTION ===================== */
var DG_PEOPLE = ["your mother", "your father", "your grandfather or grandmother", "your best friend", "your brother or sister", "your boss or your teacher", "a famous actor or singer"];
var DG_QS = ["What does he / she look like?", "What's he / she like?", "What does he / she do?", "What does he / she like doing?", "How old is he / she?", "What doesn't he / she like doing?", "Is he / she shy or extroverted?", "Does he / she have a partner?"];
var dgBusy = false;
function dgDraw(){
  if (dgBusy) return; dgBusy = true;
  var ball = document.getElementById('dg-ball'); ball.classList.remove('empty'); ball.classList.add('spin');
  var icons = ['👩','👨','👵','👴','🧑','👧','👦'], n = 0;
  var t = setInterval(function(){
    ball.textContent = icons[Math.floor(Math.random() * icons.length)];
    if (++n > 8){
      clearInterval(t); ball.classList.remove('spin');
      var p = nextNoRepeat('dgp', DG_PEOPLE.length), q = nextNoRepeat('dgq', DG_QS.length);
      ball.textContent = icons[p];
      document.getElementById('dg-q').textContent = DG_QS[q];
      document.getElementById('dg-sub').textContent = 'Ask me about ' + DG_PEOPLE[p] + '. Then answer — and ask a follow-up question!';
      dgBusy = false;
    }
  }, 70);
}
function dgReset(){
  shuffleBags['dgp'] = null; shuffleBags['dgq'] = null;
  var ball = document.getElementById('dg-ball'); ball.textContent = '👤'; ball.classList.add('empty'); ball.classList.remove('spin');
  document.getElementById('dg-q').textContent = 'Press the button to draw a person and a question.';
  document.getElementById('dg-sub').textContent = '';
}
var DG2_QS = ["How old is he / she?", "What does he / she look like?", "What's he / she like?", "What does he / she do?", "What does he / she like doing?", "What doesn't he / she like?", "Is he / she shy or extroverted?", "Does he / she live alone?"];
function dg2Draw(){
  var ball = document.getElementById('dg2-ball'); ball.classList.remove('empty');
  var i = nextNoRepeat('dg2', DG2_QS.length);
  ball.textContent = i + 1;
  document.getElementById('dg2-q').textContent = DG2_QS[i];
  document.getElementById('dg2-sub').textContent = 'Ask it about my person — and answer in full sentences.';
}
function dg2Reset(){
  shuffleBags['dg2'] = null;
  var ball = document.getElementById('dg2-ball'); ball.textContent = '❓'; ball.classList.add('empty');
  document.getElementById('dg2-q').textContent = 'Need an idea for a question? Draw one!';
  document.getElementById('dg2-sub').textContent = '';
}

/* ===================== GAME: SENTENCE SLOT MACHINE ===================== */
var SLOT_WHO = [["I", false], ["my mom", true], ["my best friend", true], ["my parents", false], ["my teacher", true], ["my neighbors", false]];
var SLOT_HOW = ["always", "usually", "often", "sometimes", "hardly ever", "never"];
var SLOT_WHAT = [["get up early", "gets up early"], ["go out on Friday night", "goes out on Friday night"], ["eat breakfast in bed", "eats breakfast in bed"],
  ["watch TV in the evening", "watches TV in the evening"], ["study English", "studies English"], ["cook dinner", "cooks dinner"],
  ["go to the gym", "goes to the gym"], ["pay for dinner", "pays for dinner"], ["talk on the phone", "talks on the phone"], ["help with the housework", "helps with the housework"]];
var slotBusy = false;
function slotSpin(){
  if (slotBusy) return; slotBusy = true;
  var r = [document.getElementById('reel1'), document.getElementById('reel2'), document.getElementById('reel3')];
  r.forEach(function(e){ e.classList.add('spin'); });
  var n = 0;
  var t = setInterval(function(){
    r[0].textContent = SLOT_WHO[Math.floor(Math.random() * SLOT_WHO.length)][0];
    r[1].textContent = SLOT_HOW[Math.floor(Math.random() * SLOT_HOW.length)];
    r[2].textContent = SLOT_WHAT[Math.floor(Math.random() * SLOT_WHAT.length)][0];
    if (++n > 9){
      clearInterval(t);
      var w = SLOT_WHO[nextNoRepeat('slw', SLOT_WHO.length)], h = SLOT_HOW[nextNoRepeat('slh', SLOT_HOW.length)], a = SLOT_WHAT[nextNoRepeat('sla', SLOT_WHAT.length)];
      var verb = w[1] ? a[1] : a[0];
      r[0].textContent = w[0]; r[1].textContent = h; r[2].textContent = verb;
      r.forEach(function(e){ e.classList.remove('spin'); });
      var s = w[0] + ' ' + h + ' ' + verb + '.';
      document.getElementById('slot-sentence').textContent = s.charAt(0).toUpperCase() + s.slice(1);
      slotBusy = false;
    }
  }, 80);
}
function slotReset(){
  ['reel1','reel2','reel3'].forEach(function(id, i){ var e = document.getElementById(id); e.innerHTML = '<small>' + ['who','how often','what'][i] + '</small>'; e.classList.remove('spin'); });
  document.getElementById('slot-sentence').innerHTML = 'Press <b>Spin</b>!';
  shuffleBags['slw'] = null; shuffleBags['slh'] = null; shuffleBags['sla'] = null;
}

/* ===================== VOTE + CHIPS ===================== */
function voteAdd(id, d){
  var el = document.getElementById('vote-' + id);
  el.textContent = Math.max(0, parseInt(el.textContent, 10) + d);
}
function chipPick(btn){
  var was = btn.classList.contains('on');
  btn.parentElement.querySelectorAll('.tchip').forEach(function(c){ c.classList.remove('on'); });
  if (!was) btn.classList.add('on');
}

/* ===================== WRAP-UP: LOCK PUZZLE ===================== */
function checkLock(lockEl){
  var input = lockEl.querySelector('.lock-input');
  var codes = (lockEl.dataset.code || '').split('|').map(norm);
  var ok = codes.indexOf(norm(input.value)) > -1;
  lockEl.classList.toggle('unlocked', ok);
  lockEl.querySelector('.lock-icon').textContent = ok ? '🔓' : '🔒';
  var all = document.querySelectorAll('#s-review .lock').length;
  var open = document.querySelectorAll('#s-review .lock.unlocked').length;
  document.getElementById('lock-win').classList.toggle('show', open === all);
}

/* ===================== PRINT LESSON ===================== */
function printAll(){
  saveNotes();
  var injected = [];
  slides.forEach(function(slide, i){
    if (i === 0){
      var linkEl = document.createElement('div');
      linkEl.className = 'lesson-link-print';
      linkEl.innerHTML = '<span class="lp-title">__LESSON_NAME__</span>' +
        '<span class="lp-sub">📝 Here you can see our Notes from Class.</span>' +
        '<span class="lp-sub" style="margin-top:6px;">You can also access <a href="__URL__" target="_blank">this link</a> to review the lesson material and do your optional Homework activities.</span>';
      slide.insertBefore(linkEl, slide.firstChild);
      injected.push(linkEl);
    }
    var n = notesData[i] || '';
    if (n.replace(/<[^>]*>/g,'').trim()){
      var notesEl = document.createElement('div');
      notesEl.className = 'slide-notes-print';
      notesEl.innerHTML = '<div class="slide-notes-print-label">📝 Teacher Notes</div>' + n;
      slide.appendChild(notesEl);
      injected.push(notesEl);
    }
  });
  document.body.classList.add('print-all');
  window.print();
  setTimeout(function(){
    document.body.classList.remove('print-all');
    injected.forEach(function(el){ el.parentNode && el.parentNode.removeChild(el); });
  }, 1500);
}

/* ===================== UNSAVED-NOTES WARNING + PROGRESS BAR ===================== */
(function(){
  var notesUnsaved = false;
  document.addEventListener('input', function(e){ if (e.target && e.target.id === 'notesTA') notesUnsaved = true; });
  document.addEventListener('click', function(e){
    var t = e.target && e.target.closest ? e.target.closest('#dlNotesBtn') : null;
    if (t) setTimeout(function(){ notesUnsaved = false; }, 300);
  });
  window.addEventListener('beforeunload', function(e){
    if (notesUnsaved) { e.preventDefault(); e.returnValue = ''; return ''; }
  });
  var bar = document.getElementById('progBar'); var all = Array.prototype.slice.call(document.querySelectorAll('.slide'));
  function upd(){ var i = all.findIndex(function(x){ return x.classList.contains('active'); }); if (i < 0) return; bar.style.width = ((i+1)/all.length*100) + '%'; }
  new MutationObserver(upd).observe(document.getElementById('deck'), {attributes:true, subtree:true, attributeFilter:['class']});
  upd();
})();

/* init */
document.getElementById('counter').textContent = '1/' + slides.length;
document.getElementById('prevBtn').disabled = true;
loadNotes(0);

/* ===== Pre-teach: build the dad ===== */
var PB = {h:'med', b:'med', c:'dark', x:{}}, PB_TARGET = null, PB_LAST = -1;
var PB_CHALLENGES = [
  {t:"He's <b>very tall and thin</b>, with a <b>big nose</b>. He has <b>blond</b> hair.", h:'tall', b:'thin', c:'blond', x:{nose:1}},
  {t:"He's <b>short and thin</b>, and he wears <b>glasses</b>.", h:'short', b:'thin', c:'dark', x:{glasses:1}},
  {t:"He's <b>not very tall</b> – a little taller than his daughter. He isn't thin, but he isn't <b>overweight</b>. He has <b>gray</b> hair and an <b>amazing smile</b>.", h:'med', b:'med', c:'gray', x:{smile:1}},
  {t:"He's <b>tall and overweight</b>. He's <b>bald</b> and he wears <b>glasses</b>.", h:'tall', b:'over', c:'bald', x:{glasses:1}},
  {t:"He's <b>short and overweight</b>, with <b>dark</b> hair and an <b>amazing smile</b>.", h:'short', b:'over', c:'dark', x:{smile:1}},
  {t:"He's <b>tall</b> with <b>gray</b> hair, a <b>big nose</b> and <b>glasses</b>. He isn't thin and he isn't overweight.", h:'tall', b:'med', c:'gray', x:{nose:1, glasses:1}}
];
function prepRender(){
  var H = {tall:262, med:214, short:170}[PB.h], W = {thin:34, med:54, over:90}[PB.b];
  var g = 300, top = g - H, hr = 22, headY = top + hr, torsoY = top + hr*2, torsoH = (H - hr*2) * 0.5, legH = H - hr*2 - torsoH;
  var cx = 205, hair = {blond:'#F2CF5B', dark:'#3A2A22', gray:'#B9BAC4'}[PB.c];
  var o = '<line x1="10" y1="'+g+'" x2="310" y2="'+g+'" stroke="#3B1747" stroke-width="3" stroke-linecap="round"/>';
  /* Charlotte, fixed height, as a reference */
  o += '<g><circle cx="70" cy="'+(g-150)+'" r="16" fill="#F7D2B5" stroke="#3B1747" stroke-width="2.5"/><path d="M54 '+(g-152)+' q16 -22 32 0 q2 18 -6 26 l-20 0 q-8 -8 -6 -26z" fill="#3A2A22" opacity=".9"/><circle cx="70" cy="'+(g-148)+'" r="13" fill="#F7D2B5"/><path d="M52 '+(g-132)+' l36 0 l8 66 l-52 0z" fill="#FF4F7B" stroke="#3B1747" stroke-width="2.5"/><rect x="58" y="'+(g-66)+'" width="9" height="66" fill="#F7D2B5" stroke="#3B1747" stroke-width="2.5"/><rect x="73" y="'+(g-66)+'" width="9" height="66" fill="#F7D2B5" stroke="#3B1747" stroke-width="2.5"/></g>';
  /* dad: legs, torso, head */
  o += '<rect x="'+(cx-W*0.34-3)+'" y="'+(torsoY+torsoH)+'" width="'+(W*0.32)+'" height="'+legH+'" fill="#3B1747" stroke="#3B1747" stroke-width="2.5"/>';
  o += '<rect x="'+(cx+3)+'" y="'+(torsoY+torsoH)+'" width="'+(W*0.32)+'" height="'+legH+'" fill="#3B1747" stroke="#3B1747" stroke-width="2.5"/>';
  o += '<rect x="'+(cx-W/2)+'" y="'+torsoY+'" width="'+W+'" height="'+torsoH+'" rx="'+Math.min(22,W/2.2)+'" fill="#4FB0C6" stroke="#3B1747" stroke-width="2.5"/>';
  o += '<rect x="'+(cx-W/2-9)+'" y="'+(torsoY+4)+'" width="9" height="'+(torsoH*0.85)+'" rx="4" fill="#F7D2B5" stroke="#3B1747" stroke-width="2.5"/><rect x="'+(cx+W/2)+'" y="'+(torsoY+4)+'" width="9" height="'+(torsoH*0.85)+'" rx="4" fill="#F7D2B5" stroke="#3B1747" stroke-width="2.5"/>';
  o += '<circle cx="'+cx+'" cy="'+headY+'" r="'+hr+'" fill="#F7D2B5" stroke="#3B1747" stroke-width="2.5"/>';
  if (PB.c !== 'bald') o += '<path d="M'+(cx-hr)+' '+(headY-2)+' q'+hr+' -'+(hr+14)+' '+(hr*2)+' 0 q-6 -10 -'+hr+' -10 q-'+(hr-6)+' 0 -'+hr+' 10z" fill="'+hair+'" stroke="#3B1747" stroke-width="2"/>';
  else o += '<path d="M'+(cx-hr+2)+' '+(headY-6)+' q-6 4 -4 12 M'+(cx+hr-2)+' '+(headY-6)+' q6 4 4 12" stroke="#3B1747" stroke-width="2" fill="none"/>';
  o += '<circle cx="'+(cx-8)+'" cy="'+(headY-2)+'" r="2.6" fill="#3B1747"/><circle cx="'+(cx+8)+'" cy="'+(headY-2)+'" r="2.6" fill="#3B1747"/>';
  if (PB.x.glasses) o += '<circle cx="'+(cx-8)+'" cy="'+(headY-2)+'" r="7" fill="none" stroke="#3B1747" stroke-width="2.2"/><circle cx="'+(cx+8)+'" cy="'+(headY-2)+'" r="7" fill="none" stroke="#3B1747" stroke-width="2.2"/><line x1="'+(cx-1)+'" y1="'+(headY-2)+'" x2="'+(cx+1)+'" y2="'+(headY-2)+'" stroke="#3B1747" stroke-width="2"/>';
  o += PB.x.nose ? '<path d="M'+cx+' '+(headY-2)+' l-9 15 l11 0z" fill="#EBB48F" stroke="#3B1747" stroke-width="2"/>' : '<path d="M'+cx+' '+(headY+1)+' l-3 7 l5 0" fill="none" stroke="#3B1747" stroke-width="1.8"/>';
  o += PB.x.smile ? '<path d="M'+(cx-12)+' '+(headY+11)+' q12 14 24 0z" fill="#fff" stroke="#3B1747" stroke-width="2"/>' : '<path d="M'+(cx-6)+' '+(headY+13)+' l12 0" stroke="#3B1747" stroke-width="2" stroke-linecap="round"/>';
  document.getElementById('pb-svg').innerHTML = o;
  document.querySelectorAll('.pb-opt').forEach(function(b){
    var g = b.dataset.g, v = b.dataset.v;
    b.classList.toggle('on', g === 'x' ? !!PB.x[v] : PB[g] === v);
  });
}
function prepSet(g, v){
  if (g === 'x') PB.x[v] = PB.x[v] ? 0 : 1; else PB[g] = v;
  prepRender();
}
function prepChallenge(){
  var i = nextNoRepeat('pbc', PB_CHALLENGES.length); PB_TARGET = PB_CHALLENGES[i];
  document.getElementById('pb-chal').innerHTML = '🎧 ' + PB_TARGET.t;
  var fb = document.getElementById('pb-fb'); fb.textContent = ''; fb.className = 'pb-fb';
}
function prepCheck(){
  var fb = document.getElementById('pb-fb');
  if (!PB_TARGET){ fb.textContent = 'Press New challenge first!'; fb.className = 'pb-fb no'; return; }
  var bad = [];
  if (PB.h !== PB_TARGET.h) bad.push('height');
  if (PB.b !== PB_TARGET.b) bad.push('weight');
  if (PB.c !== PB_TARGET.c) bad.push('hair');
  var faceBad = ['glasses','nose','smile'].some(function(k){ return !!PB.x[k] !== !!PB_TARGET.x[k]; });
  if (faceBad) bad.push('face');
  if (!bad.length){ fb.textContent = '✔ Perfect! That\'s the dad. Now describe him to me!'; fb.className = 'pb-fb ok'; }
  else { fb.textContent = 'Not quite – check the ' + bad.join(', ') + '.'; fb.className = 'pb-fb no'; }
}
function prepReset(){
  PB = {h:'med', b:'med', c:'dark', x:{}}; PB_TARGET = null; shuffleBags['pbc'] = null;
  prepRender();
}
document.addEventListener('DOMContentLoaded', function(){ if (document.getElementById('pb-svg')) prepRender(); });

/* ===================== SAVE NOTES AS PDF (student-friendly cover) ===================== */
function savePDF(){
  saveNotes();
  var hasNotes = Object.keys(notesData).some(function(k){ return notesData[k] && notesData[k].replace(/<[^>]*>/g,'').trim(); });
  if (!hasNotes){ alert('No notes to save yet!'); return; }
  var LESSON = '__URL__', HW = LESSON + '#homework';
  var win = window.open('', '_blank');
  var cards = '';
  slideIds.forEach(function(sid, idx){
    var note = notesData[idx] || '';
    if (!note.replace(/<[^>]*>/g,'').trim()) return;
    cards += '<div class="card"><div class="card-header">Slide '+(idx+1)+' &mdash; '+slideLabels[idx]+'</div><div class="card-body">'+note+'</div></div>';
  });
  var css =
    'body{font-family:"DM Sans","Segoe UI",system-ui,sans-serif;max-width:820px;margin:0 auto;padding:0 0 32px;color:#1C2B3A;background:#fff}'+
    '.hero{background:linear-gradient(135deg,#2B1B5E 0%,#5A2E8C 55%,#FF6B5E 130%);color:#fff;border-radius:0 0 28px 28px;padding:34px 36px 30px;position:relative;overflow:hidden}'+
    '.hero:after{content:"";position:absolute;right:-40px;top:-40px;width:200px;height:200px;border-radius:50%;background:rgba(255,255,255,.08)}'+
    '.hero .kicker{font-size:.85rem;letter-spacing:.22em;text-transform:uppercase;color:#FFD84D;font-weight:800;margin:0 0 6px}'+
    '.hero h1{font-family:"Fredoka","Segoe UI",sans-serif;font-size:2.3rem;line-height:1.1;margin:0 0 6px;font-weight:600}'+
    '.hero .sub{font-size:1.1rem;opacity:.92;margin:0}'+
    '.hero .date{display:inline-block;margin-top:14px;background:rgba(255,255,255,.16);border-radius:999px;padding:4px 14px;font-size:.9rem}'+
    '.how{margin:26px 28px 8px;background:#FFF8E1;border:3px solid #FFD84D;border-radius:22px;padding:20px 24px}'+
    '.how h2{font-family:"Fredoka","Segoe UI",sans-serif;font-size:1.45rem;margin:0 0 14px;color:#2B1B5E}'+
    '.step{display:flex;gap:14px;align-items:flex-start;margin:0 0 14px}'+
    '.step .n{flex:none;width:34px;height:34px;border-radius:50%;background:#2B1B5E;color:#fff;font-weight:800;display:flex;align-items:center;justify-content:center;font-size:1.1rem}'+
    '.step p{margin:0;font-size:1.08rem;line-height:1.55}'+
    '.btns{display:flex;gap:14px;flex-wrap:wrap;margin:6px 0 6px 48px}'+
    '.bigbtn{display:inline-block;text-decoration:none;color:#fff!important;font-weight:800;font-size:1.2rem;padding:13px 26px;border-radius:999px;border:3px solid #2B1B5E;box-shadow:0 5px 0 #2B1B5E}'+
    '.bigbtn.lesson{background:#1F9D6B}.bigbtn.hw{background:#FF6B5E}'+
    '.link-note{margin:6px 0 0 48px;font-size:.88rem;color:#5b5b6b;word-break:break-all}'+
    '.tip{margin-top:12px;font-size:.95rem;color:#5b5b6b}'+
    '.notes-title{font-family:"Fredoka","Segoe UI",sans-serif;font-size:1.5rem;color:#2B1B5E;margin:26px 28px 12px}'+
    '.card{border:1px solid #DDD;border-radius:12px;margin:0 28px 16px;overflow:hidden}'+
    '.card-header{background:#2B1B5E;color:#fff;padding:8px 14px;font-weight:700;font-size:.92rem;break-after:avoid-page;page-break-after:avoid}'+
    '.card-body{padding:12px 16px;font-size:1rem;line-height:1.7;orphans:3;widows:3}'+
    'mark{background:#FFE066;color:#1a1a1a;padding:0 2px}'+
    '[style*="background-color"]{color:#1a1a1a!important}'+
    '.card-body,.card-body *{color:#1a1a1a!important}'+
    '*{print-color-adjust:exact;-webkit-print-color-adjust:exact}'+
    '@media print{@page{margin:1.2cm}body{padding:0}.hero,.how{break-inside:avoid}}';
  var today = new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
  var html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Notes – '+document.title+'</title>'+
    '<link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600&family=DM+Sans:wght@400;700;800&display=swap" rel="stylesheet">'+
    '<style>'+css+'</style></head><body>'+
    '<div class="hero"><p class="kicker">Conversational English with teacher Nanda</p>'+
      '<h1>'+document.title.replace(' — ',' · ')+'</h1>'+
      '<p class="sub">📝 Your notes from class</p><span class="date">'+today+'</span></div>'+
    '<div class="how"><h2>👋 How to use this PDF</h2>'+
      '<div class="step"><div class="n">1</div><p><b>Read your notes</b> below. These are the notes we made together in class.</p></div>'+
      '<div class="step"><div class="n">2</div><p><b>Click the green button</b> to open the lesson on your computer, tablet or phone. You can practice our lesson content again or go to the Homework to review.</p></div>'+
      '<div class="btns"><a class="bigbtn lesson" href="'+LESSON+'" target="_blank">▶ Open the lesson</a></div>'+
      '<p class="link-note">If the button does not open, copy this link: '+LESSON+'</p></div>'+
    '<h2 class="notes-title">📝 Notes from class</h2>'+cards+'</body></html>';
  win.document.write(html);
  win.document.close();
  setTimeout(function(){ win.print(); }, 700);
}
/* open the Homework directly from the PDF button */
if (location.hash === '#homework' && document.getElementById('hw-cover')) { goToId('hw-cover'); }
