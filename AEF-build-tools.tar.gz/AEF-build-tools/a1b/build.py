# -*- coding: utf-8 -*-
import re, json, subprocess
import s_b
from s_a import S

TITLE_FULL = "AEF2 1B — The perfect date?"
LESSON_NAME = "The perfect date?"
URL = "https://teacher-nanda.github.io/AEF-Courses/AEF2-1B/index.html"

ids = [s[0] for s in S]
labels = [s[1] for s in S]
import sys; sys.path.insert(0,'..')
from balance import fix_all
S = fix_all(S)
_lead = [x for x in S if x[0]=='s-lead'][0]
S = [x for x in S if x[0]!='s-lead']
_hw = next(i for i,x in enumerate(S) if x[0].startswith('hw-'))
S.insert(_hw, _lead)
slides_html = "\n\n".join(s[2] for s in S)

head = '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>%s</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=DM+Sans:wght@400;500;700;800&display=swap" rel="stylesheet">
<style>
''' % TITLE_FULL

base_css = open('base.css', encoding='utf-8').read()
base_css = base_css.replace('AEF4 4B \\2014  A Risky Business', 'AEF2 1B \\2014  ' + LESSON_NAME)
theme = open('theme.css', encoding='utf-8').read() + open('theme_add.css', encoding='utf-8').read()

chrome = open('chrome.html', encoding='utf-8').read()
nav = open('nav.html', encoding='utf-8').read()
js_nav = open('js_nav.js', encoding='utf-8').read()
js_gen = open('js_generic.js', encoding='utf-8').read()
js_new = open('js_new.js', encoding='utf-8').read()

# ---- adapt generic js
js_gen = js_gen.replace("function saveNotes(){ notesData[current] = document.getElementById('notesTA').innerHTML; }",
                        "function saveNotes(){ notesData[current] = document.getElementById('notesTA').innerHTML; try{ localStorage.setItem(notesStoreKey, JSON.stringify(notesData)); }catch(e){} }")
js_gen = js_gen.replace('Notes – AEF4 4B', 'Notes – AEF2 1B')
js_gen = js_gen.replace('AEF4 4B – A Risky Business', 'AEF2 1B – ' + LESSON_NAME)
js_gen = js_gen.replace('https://teacher-nanda.github.io/AEF-Courses/AEF4-4B/index.html', URL)

js_new = js_new.replace('__LESSON_NAME__', LESSON_NAME).replace('__URL__', URL)

out = head + base_css + "\n" + theme + "\n</style>\n</head>\n<body>\n"
out += chrome + "\n<div id=\"deck\">\n\n" + slides_html + "\n\n</div><!-- END #deck -->\n\n" + nav + "\n"
out += "<script>\n/* ===================== SLIDE NAV DATA ===================== */\n"
out += "var slideIds = " + json.dumps(ids) + ";\n"
out += "var slideLabels = " + json.dumps(labels, ensure_ascii=False) + ";\n"
out += js_nav + "\n" + js_gen + "\n" + js_new + "\n</script>\n</body>\n</html>\n"

open('index.html', 'w', encoding='utf-8').write(out)
print(len(S), 'slides', len(out), 'bytes')
