import asyncio
from playwright.async_api import async_playwright
JS = r'''
(sid)=>{
  const s=document.getElementById(sid); const out={};
  // typed
  s.querySelectorAll('input.ans-input[data-ans]').forEach(i=>{ i.value=i.dataset.ans; });
  // notice rows
  s.querySelectorAll('.notice-row').forEach(r=>{ const ok=r.dataset.ok; r.querySelectorAll('.circ-opt').forEach(b=>{ if(b.textContent.trim()===ok) b.click(); }); });
  // circle groups
  const seen={}; s.querySelectorAll('.circ-opt[data-correct]').forEach(b=>{ if(b.closest('.notice-row')) return; if(b.textContent.trim()===b.dataset.correct) b.click(); });
  // match
  s.querySelectorAll('.match-item[data-side="left"]').forEach(l=>{ const r=s.querySelector('.match-item[data-side="right"][data-pair="'+l.dataset.pair+'"]'); l.click(); if(r) r.click(); });
  // wb
  s.querySelectorAll('.wb-blank').forEach(b=>{ const t=[...s.querySelectorAll('.wb-tile')].find(x=>!x.classList.contains('used') && !x.classList.contains('example-used') && x.dataset.val===b.dataset.ans); if(t){ t.click(); b.click(); } });
  // classify
  s.querySelectorAll('.classify-chip[data-ans]').forEach(c=>{ c.click(); const col=[...s.querySelectorAll('.classify-col')].find(x=>x.dataset.target===c.dataset.ans); if(col) col.click(); });
  s.querySelectorAll('.btn-check').forEach(b=>b.click());
  const wrong=[...s.querySelectorAll('.wrong,.wrongpair,.empty-warn')].map(e=>e.outerHTML.slice(0,80));
  const ok=s.querySelectorAll('.correct,.correctpair').length;
  return {wrong, ok};
}
'''
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':1366,'height':820})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file:///tmp/aef/a1b/index.html'); await pg.wait_for_timeout(500)
        ids=await pg.evaluate('slideIds')
        for sid in ids:
            await pg.evaluate("goToId('%s')"%sid)
            r=await pg.evaluate(JS,sid)
            if r['wrong'] or r['ok']: print(sid,'ok=',r['ok'],'wrong=',r['wrong'][:3])
        # wrong answer test
        await pg.evaluate("goToId('s-per1')")
        await pg.evaluate("document.querySelector('#per1 input').value='zzz'; checkSlide('per1')")
        print('wrong flagged:', await pg.evaluate("document.querySelector('#per1 input').classList.contains('wrong')"))
        await pg.evaluate("goToId('s-review')")
        await pg.evaluate("document.querySelectorAll('#s-review .lock').forEach(l=>{l.querySelector('input').value=l.dataset.code.split('|')[0]; checkLock(l);})")
        print('win shown:', await pg.evaluate("document.getElementById('lock-win').classList.contains('show')"))
        # games
        await pg.evaluate("goToId('s-warm')")
        for k in range(6):
            await pg.evaluate("swipeDo('%s')" % ('right' if k%2==0 else 'left')); await pg.wait_for_timeout(450)
        print('swipe verdict:', await pg.evaluate("document.getElementById('sv-big').textContent"))
        await pg.evaluate("goToId('s-g-game')"); await pg.evaluate("slotSpin()"); await pg.wait_for_timeout(1200)
        print('slot:', await pg.evaluate("document.getElementById('slot-sentence').textContent"))
        await pg.evaluate("goToId('s-act1')"); await pg.evaluate("dgDraw()"); await pg.wait_for_timeout(900)
        print('draw:', await pg.evaluate("document.getElementById('dg-q').textContent"), await pg.evaluate("document.getElementById('dg-sub').textContent"))
        await pg.evaluate("goToId('s-sp2')"); await pg.evaluate("dg2Draw()")
        print('dg2:', await pg.evaluate("document.getElementById('dg2-q').textContent"))
        await pg.evaluate("goToId('s-comm3'); voteAdd('a',1); voteAdd('a',1); voteAdd('b',1);")
        print('votes:', await pg.evaluate("document.getElementById('vote-a').textContent+'-'+document.getElementById('vote-b').textContent"))
        await pg.evaluate("goToId('s-bridge'); document.getElementById('notesTA').innerHTML='hello'; saveNotes();")
        print('ls:', await pg.evaluate("localStorage.getItem(notesStoreKey)"))
        print('errors',errs)
        await b.close()
asyncio.run(main())
