# -*- coding: utf-8 -*-
from s_a import S, slide, audio, green, ccq, reveal, ph, script_box, circ_opt_btn
import s_r

# ================================================================== GRAMMAR: simple present
# ------------------------------------------------------------------ meaning (CCQ) with the article's sentences
mean_items = [
 ('They <span class="hl">often go out</span> together in the evening.',
  ccq('Are they going out <b>right now</b>?', 'No — it\'s not happening at this moment.') + ccq('Does it happen again and again?', 'Yes — it\'s a <b>habit / routine</b>. How often? <i>Often</i> (not always, not rarely).')),
 ('Charlotte thinks that Clint <span class="hl">needs</span> a new partner.',
  ccq('Is this a short action or a situation?', 'A <b>situation</b> (a state) — and it is true now and in general.')),
 ("Charlotte <span class=\"hl\">doesn't want</span> her dad to end up alone.",
  ccq('Does Charlotte want her dad to be alone?', 'No. We use <b>doesn\'t</b> + base form (<i>want</i>) for negatives with he / she / it.')),
 ('<span class="hl">Does</span> Clint <span class="hl">like</span> internet dating?',
  ccq('How do we make a question with he / she / it?', '<b>Does</b> + subject + <b>base form</b>. The verb doesn\'t change: <i>Does he like…?</i>')),
]
mhtml = ''.join('<div class="gram-box" style="margin:0 0 14px;"><p style="font-size:1.2rem;margin-bottom:6px;">%s</p><div class="ccq-box" style="margin:0;border-width:2px;box-shadow:none;"><ul class="ccq-list">%s</ul></div></div>' % (a, b) for a, b in mean_items)
slide('s-g-meaning', 'Grammar – Meaning (Simple Present)', '''<div class="slide" id="s-g-meaning">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Simple present: what does it mean?</h2>
    <p class="inst-light">Look at these sentences from the article. Answer the questions about the meaning.</p>
    <!-- Meaning first (CELTA): CCQs on article sentences. -->
    %s
    <div class="gram-note">📌 We use the <b>simple present</b> for things we do every day / week / year, or for things that are <b>generally true</b> or <b>always happen</b>.</div>
  </div></div>
</div>''' % mhtml)

# ------------------------------------------------------------------ 2a complete the chart
def cell_in(ans, w=130, alt=''):
    return '<input class="ans-input" style="width:%dpx" data-ans="%s"%s aria-label="chart answer">' % (w, ans, (' data-alt="%s"' % alt) if alt else '')
slide('s-g-chart', 'Grammar – Complete the Chart', '''<div class="slide" id="s-g-chart">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Simple present</h2>
    <p class="instruction">Complete the chart.</p>
    <!-- SB 2a. TB answers: needs / doesn't / do, does -->
    <div class="qa-table-wrap" id="g-chart">
      <table class="qa">
        <tr><th></th><th>I / you / we / they</th><th>he / she / it</th></tr>
        <tr><td><b>＋</b></td><td>I need a new partner.</td><td>He %s a new partner.</td></tr>
        <tr><td><b>－</b></td><td>I don't want my dad to end up alone.</td><td>She %s want her dad to end up alone.</td></tr>
        <tr><td><b>？</b></td><td>What kind of person %s you want to meet?</td><td>What kind of person %s he want to meet?</td></tr>
      </table>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('g-chart')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('g-chart')">Reset</button>
    </div>
    <div class="ccq-box"><p class="ccq-label">💭 Check your understanding</p>
      <ul class="ccq-list">
        %s
        %s
      </ul>
    </div>
  </div></div>
</div>''' % (cell_in('needs', 110), cell_in("doesn't", 120, 'does not|doesnt'), cell_in('do', 70), cell_in('does', 80),
             ccq('What changes in the verb <i>need</i> after <b>he / she / it</b>?', 'We add <b>-s</b>: <i>needs</i>.'),
             ccq('In the negative, does the main verb take an <b>-s</b> too? (<i>She doesn\'t wants…</i>?)', 'No! After <b>doesn\'t</b> we use the <b>base form</b>: <i>She doesn\'t want…</i>')))

# ------------------------------------------------------------------ 2b check the correct sentences
def pair_row(n, a, b, correct):
    g = 'gn-%d' % n
    return ('<div class="ex-row"><span class="circ-num">%d</span>%s<span class="circ-sep">/</span>%s</div>' % (n, circ_opt_btn(g, a, correct), circ_opt_btn(g, b, correct)))
slide('s-g-notice', 'Grammar – Check the Correct Sentences', '''<div class="slide" id="s-g-notice">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Which sentence is correct?</h2>
    <p class="instruction">Click the correct sentence in each pair.</p>
    <!-- SB 2b. TB answers: 1 A, 2 B. Extra challenge: why are the others wrong? -->
    <div id="gnotice">%s%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkCircSlide('gnotice')">Check Answers</button>
      <button class="btn-reset" onclick="resetCircSlide('gnotice')">Reset</button>
    </div>
    <div class="gram-note">💭 What's the difference? Look at the position of <b>often</b> and <b>always</b>. Why are the other two sentences wrong?</div>
    <div class="ccq-box"><ul class="ccq-list">%s</ul></div>
  </div></div>
</div>''' % (pair_row(1, 'They often go out together.', 'They go out often together.', 'They often go out together.'),
             pair_row(2, 'He always is the one who pays.', "He's always the one who pays.", "He's always the one who pays."),
             ccq('Where does <b>often</b> go in a sentence with a normal verb (<i>go</i>)?', 'Before the main verb: <i>They <b>often</b> go out.</i>') +
             ccq('Where does <b>always</b> go with the verb <b>be</b>?', 'After <i>be</i>: <i>He\'s <b>always</b> the one who pays.</i>')))

# ------------------------------------------------------------------ form: Grammar Bank 1B
slide('s-g-form', 'Grammar – Form: Simple Present', '''<div class="slide" id="s-g-form">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Simple present: form</h2>
    <p class="inst-light">Study the positive, negative, and question forms.</p>
    <!-- Grammar Bank 1B (audio 1.15 on the pronunciation slide) -->
    <div class="qa-table-wrap">
      <table class="qa">
        <tr><th></th><th>I / you / we / they</th><th>he / she / it</th></tr>
        <tr><td><b>＋</b></td><td>I usually <b>work</b> at home.</td><td>My brother <b>works</b> in the city.</td></tr>
        <tr><td><b>－</b></td><td>My parents <span class="aux" style="font-weight:800;color:#9A2C8E;">don't live</span> near here.</td><td>It <span style="font-weight:800;color:#9A2C8E;">doesn't often rain</span> here.</td></tr>
        <tr><td><b>？</b></td><td><b>Do</b> you <b>speak</b> French?</td><td><b>Does</b> he <b>like</b> pop music?</td></tr>
        <tr><td>✔ ✘</td><td>Yes, I <b>do</b>. / No, I <b>don't</b>.</td><td>Yes, he <b>does</b>. / No, he <b>doesn't</b>.</td></tr>
      </table>
    </div>
    <div class="gram-box">
      <p>We use the simple present for things we do <span class="hl">every day / week / year</span>, or for things that are <span class="hl">generally true</span> or always happen.</p>
      <p>We use <b>don't / doesn't</b> in negative sentences, and <b>do / does</b> to make questions.</p>
    </div>
    <div class="ccq-box"><p class="ccq-label">💭 Check your understanding</p>
      <ul class="ccq-list">
        %s
        %s
        %s
      </ul>
    </div>
    <div class="gram-mistake"><b>⚠️ Typical mistakes</b>
      <p style="margin:8px 0 0;"><s>She don't like pop music.</s> → She <b>doesn't</b> like pop music.</p>
      <p style="margin:4px 0 0;"><s>Does he likes pop music?</s> → Does he <b>like</b> pop music?</p>
      <p style="margin:4px 0 0;"><s>My brother work in the city.</s> → My brother work<b>s</b> in the city.</p>
    </div>
    <div class="gram-note" style="margin-top:14px;">🔊 <b>do</b> /du/ · <b>don't</b> /doʊnt/ · <b>does</b> /dʌz/ · <b>doesn't</b> /ˈdʌzənt/ · <b>goes</b> /goʊz/ · <b>has</b> /hæz/. In conversation we always use the short forms <b>don't</b> and <b>doesn't</b>.</div>
  </div></div>
</div>''' % (ccq('Which pronouns take <b>-s</b> on the verb: <i>I, you, he, she, it, we, they</i>?', '<b>he / she / it</b> only.'),
             ccq('<i>"Does she <u>likes</u> pop music?"</i> — what\'s wrong?', 'After <b>does</b> we use the base form: <i>Does she <b>like</b>…?</i> The <i>-s</i> goes on <i>does</i>.'),
             ccq('<i>"He doesn\'t often rain"</i> — can we say this? Why (not)?', 'We can\'t use <i>he</i> for weather. <i>It doesn\'t often rain here.</i> — the same pattern: <b>doesn\'t</b> + base form.')))

# ------------------------------------------------------------------ third-person spelling
sp = [('work', 'works', 'add -s'), ('study', 'studies', 'consonant + y → ies'), ('finish', 'finishes', 'add -es after ch, c, g, sh, s, z, and x'),
      ('go / do', 'goes / does', 'add -es'), ('have', 'has', 'change to -s')]
sprows = ''.join('<tr><td><b>%s</b></td><td>%s</td><td>%s</td></tr>' % r for r in sp)
sp_ex = [('play', 'plays'), ('watch', 'watches'), ('try', 'tries'), ('teach', 'teaches'), ('wash', 'washes'), ('live', 'lives'), ('fly', 'flies'), ('miss', 'misses'), ('enjoy', 'enjoys'), ('cook', 'cooks')]
sp_rows = ''.join('<div class="ex-row" style="display:inline-block;width:48%%;"><span class="circ-num">%d</span>%s → <input class="ans-input" style="width:130px" data-ans="%s" aria-label="he/she form of %s"></div>' % (i + 2, b, a, b) for i, (b, a) in enumerate(sp_ex))
slide('s-g-spell', 'Grammar – Spelling: he / she / it', '''<div class="slide" id="s-g-spell">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Spelling: he / she / it</h2>
    <p class="inst-light">Study the spelling rules for the third person. Then write the <i>he / she / it</i> form of each verb.</p>
    <!-- Grammar Bank 1B spelling table + extra practice (same rules, more verbs). -->
    <div class="qa-table-wrap">
      <table class="qa"><tr><th>I / you / we / they</th><th>he / she / it</th><th>Rule</th></tr>%s</table>
    </div>
    <div class="ccq-box"><p class="ccq-label">💭 Check your understanding</p>
      <ul class="ccq-list">%s%s</ul>
    </div>
    <div id="gspell"><div class="ex-row"><span class="example-badge">1</span>work → %s</div>%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('gspell')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('gspell')">Reset</button>
    </div>
  </div></div>
</div>''' % (sprows,
             ccq('<b>study</b> ends in a consonant + <i>y</i> (d + y). What happens?', 'The <i>y</i> changes to <b>-ies</b>: <i>studies</i>.'),
             ccq('<b>play</b> ends in a <u>vowel</u> + <i>y</i> (a + y). Does it change to <i>-ies</i>?', 'No — just add <b>-s</b>: <i>plays</i>.'),
             green('works'), sp_rows))

# ------------------------------------------------------------------ adverbs and expressions of frequency
ladder = [('always', 100), ('usually', 80), ('often', 65), ('sometimes', 45), ('hardly ever', 15), ('never', 0)]
lhtml = ''.join('<div class="freq-step"><span class="fw">%s</span><span class="fbar" style="width:%dpx;min-width:12px;"></span><span class="fpct">%s</span></div>' % (w, 8 + p * 4, ('%d' % p) + '%') for w, p in ladder)
slide('s-g-adv', 'Grammar – Adverbs of Frequency', '''<div class="slide" id="s-g-adv">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Adverbs and expressions of frequency</h2>
    <p class="inst-light">How often? Study the adverbs and the rules.</p>
    <!-- Grammar Bank 1B right-hand box (audio 1.16 on the pronunciation slide) -->
    <div class="freq-ladder">%s</div>
    <div class="gram-box">
      <p><b>1</b> We often use the simple present with adverbs of frequency (<i>always, often, sometimes, usually, hardly ever, never</i>).</p>
      <p style="margin-left:18px;"><i>We <span class="hl">often</span> go out on Friday night.</i><br><i>She doesn't <span class="hl">usually</span> study on weekends.</i><br><i>I'm <span class="hl">never</span> sick.</i><br><i>He's <span class="hl">always</span> late for work.</i></p>
      <p>• Adverbs of frequency go <u>before</u> the main verb.</p>
      <p>• Adverbs of frequency go <u>after</u> <b>be</b>: <i>She's never sick.</i> <s>She never is sick.</s></p>
      <p>• Remember to use a <b>positive</b> verb with <b>never</b>: <i>It never rains.</i> <s>It doesn't never rain.</s></p>
      <p><b>2</b> Expressions of frequency (<i>every day, once a week, twice a week</i>, etc.) usually go at the <u>end</u> of a sentence.</p>
      <p style="margin-left:18px;"><i>She gets up early <span class="hl">every day</span>.</i><br><i>We have English classes <span class="hl">twice a week</span>.</i></p>
    </div>
    <div class="ccq-box"><p class="ccq-label">💭 Check your understanding</p>
      <ul class="ccq-list">
        %s
        %s
        %s
      </ul>
    </div>
    <div class="gram-note">📌 <b>once</b> and <b>twice</b> are irregular: <i>once a month, twice a year</i> — but from three on we use <b>times</b>: <i>three times a week, ten times a year</i>. <b>Usually</b>, <b>normally</b>, and <b>sometimes</b> can also go at the beginning: <i>Sometimes I get up late on Saturday.</i></div>
  </div></div>
</div>''' % (lhtml,
             ccq('Maria <b>never</b> eats meat. How often does she eat meat?', 'Zero times (0%).'),
             ccq('Tom <b>hardly ever</b> goes to the gym. Does he go often?', 'No — almost never (very rarely).'),
             ccq('Is <i>"I go twice a week to the gym"</i> correct? Where does the expression usually go?', 'Better: <i>I go to the gym <b>twice a week</b>.</i> — at the end of the sentence.')))

# ------------------------------------------------------------------ pronunciation of the grammar boxes 1.15 / 1.16
def sent_list(items):
    return '<div class="card" style="margin:0 0 10px;">' + ''.join('<div class="ex-row" style="margin-bottom:6px;">%s</div>' % s for s in items) + '</div>'
slide('s-g-pron', 'Grammar – Say It with Rhythm', '''<div class="slide" id="s-g-pron">
  <div class="banner banner-pron">🔊 Pronunciation</div>
  <div class="slide-main"><div class="content">
    <h2>Say it with rhythm</h2>
    <p class="instruction">Listen and repeat the example sentences from the grammar boxes. Copy the rhythm.</p>
    <!-- SB Grammar Bank 1.15 and 1.16 -->
    <div class="fixed-two-col" style="gap:0 30px;">
      <div>
        <p class="discuss-label">Simple present</p>
        %s
        %s
      </div>
      <div>
        <p class="discuss-label">Adverbs and expressions of frequency</p>
        %s
        %s
      </div>
    </div>
  </div></div>
</div>''' % (audio('1.15'), sent_list(["I usually work at home.", "My brother works in the city.", "My parents don't live near here.", "It doesn't often rain here.", "Do you speak French?", "Does he like pop music?", "Yes, I do. / No, I don't.", "Yes, he does. / No, he doesn't."]),
              audio('1.16'), sent_list(["We often go out on Friday night.", "She doesn't usually study on weekends.", "I'm never sick.", "He's always late for work.", "She gets up early every day.", "We have English classes twice a week."])))

# ------------------------------------------------------------------ GB 1B exercise a
ga = [
 ('?', 'Anna / like music', 'Does Anna like music?', ''),
 ('+', 'my sister / have a lot of hobbies', 'My sister has a lot of hobbies.', ''),
 ('−', 'I / get along very well with my parents', "I don't get along very well with my parents.", 'I do not get along very well with my parents'),
 ('+', 'my brother / study English at school', 'My brother studies English at school.', ''),
 ('−', 'my neighbors / have any children', "My neighbors don't have any children.", 'My neighbors do not have any children'),
 ('?', 'What time / the movie start', 'What time does the movie start?', ''),
 ('+', 'he / go out twice a week', 'He goes out twice a week.', ''),
 ('−', 'we / often talk about politics', "We don't often talk about politics.", 'We do not often talk about politics'),
 ('?', 'how often / you see your brother', 'How often do you see your brother?', ''),
 ('−', 'Sally / go on Facebook very often', "Sally doesn't go on Facebook very often.", 'Sally does not go on Facebook very often'),
]
def sym(s):
    return {'+': '＋', '−': '－', '?': '？'}[s]
def ga_row(n, s, cue, ans, alt):
    altattr = (' data-alt="%s"' % alt) if alt else ''
    return ('<div class="ex-row"><span class="circ-num">%d</span><span class="cue-chip">%s</span> %s<br>'
            '<input class="ans-input" style="width:min(520px,100%%);margin-left:32px;" data-ans="%s"%s aria-label="sentence %d"></div>') % (n, sym(s), cue, ans, altattr, n)
colA = ''.join(ga_row(i + 1, *ga[i]) for i in range(0, 5)); colB = ''.join(ga_row(i + 1, *ga[i]) for i in range(5, 10))
slide('s-g-ex1', 'Grammar – Write Sentences and Questions', '''<div class="slide" id="s-g-ex1">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Write sentences and questions</h2>
    <p class="instruction">Write sentences and questions with the simple present. ＋ = positive · － = negative · ？ = question</p>
    <!-- SB Grammar Bank 1B ex a (SB p.127) -->
    <div class="ex-row ex-given"><span class="example-badge">✓</span><span class="cue-chip">＋</span> he / usually get up late<br><span class="given-line">%s</span></div>
    <div class="fixed-two-col" id="g-ex1">
      <div>%s</div>
      <div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('g-ex1')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('g-ex1')">Reset</button>
    </div>
  </div></div>
</div>''' % (green('He usually gets up late.'), colA, colB))

# ------------------------------------------------------------------ GB 1B exercise b
gb = [
 ('always / before / go / I / bed / 11:00 / to', 'I always go to bed before 11:00.', ''),
 ('ever / her / Kate / sees / family / hardly', 'Kate hardly ever sees her family.', ''),
 ('Saturday / never / shopping / on / go / we', 'We never go shopping on Saturday.', ''),
 ('a / to / I / dentist / year / go / twice / the', 'I go to the dentist twice a year.', ''),
 ('in / they / breakfast / sometimes / bed / have', 'They sometimes have breakfast in bed.', 'Sometimes they have breakfast in bed'),
 ('usually / car / I / the / listen / the / in / radio / to', 'I usually listen to the radio in the car.', ''),
 ('in / day / park / every / Alan / the / runs', 'Alan runs in the park every day.', ''),
 ('often / late / Sam / is / work / for', 'Sam is often late for work.', ''),
 ('often / John / to / go / doesn\'t / movies / the', "John doesn't often go to the movies.", 'John does not often go to the movies'),
 ('visit / I / once / my / month / a / mom', 'I visit my mom once a month.', ''),
]
def gb_row(n, words, ans, alt):
    altattr = (' data-alt="%s"' % alt) if alt else ''
    return ('<div class="ex-row"><span class="circ-num">%d</span><span style="letter-spacing:.02em;">%s</span><br>'
            '<input class="ans-input" style="width:min(520px,100%%);margin-left:32px;" data-ans="%s"%s aria-label="sentence %d"></div>') % (n, words, ans, altattr, n)
colA = ''.join(gb_row(i + 1, *gb[i]) for i in range(0, 5)); colB = ''.join(gb_row(i + 1, *gb[i]) for i in range(5, 10))
slide('s-g-ex2', 'Grammar – Put the Words in Order', '''<div class="slide" id="s-g-ex2">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Put the words in order</h2>
    <p class="instruction">Put the words in the correct order to make sentences.</p>
    <!-- SB Grammar Bank 1B ex b (SB p.127) -->
    <div class="ex-row ex-given"><span class="example-badge">✓</span>go / movies / we / often / the / to<br><span class="given-line">%s</span></div>
    <div class="fixed-two-col" id="g-ex2">
      <div>%s</div>
      <div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('g-ex2')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('g-ex2')">Reset</button>
    </div>
  </div></div>
</div>''' % (green('We often go to the movies.'), colA, colB))

# ------------------------------------------------------------------ GAME: slot machine (freer practice)
slide('s-g-game', 'Game – Sentence Slot Machine', '''<div class="slide" id="s-g-game">
  <div class="banner banner-speaking">🎮 Game</div>
  <div class="slide-main"><div class="content">
    <h2>Sentence slot machine</h2>
    <p class="instruction">Spin the reels to make a sentence. Is it true for you? Say <i>"That's true / That's not true"</i> and give more information!</p>
    <div class="slot-wrap">
      <div class="slot-reels">
        <div class="reel" id="reel1"><small>who</small></div>
        <div class="reel" id="reel2"><small>how often</small></div>
        <div class="reel" id="reel3"><small>what</small></div>
      </div>
      <div class="slot-sentence" id="slot-sentence">Press <b>Spin</b>!</div>
    </div>
    <div class="btn-row">
      <button class="btn-roul" onclick="slotSpin()">🎰 Spin</button>
      <button class="btn-reset" onclick="slotReset()">Reset</button>
    </div>
    <div class="chat" style="max-width:760px;margin-top:14px;">
      <div class="bub a"><span class="who">A</span>My best friend never goes to the gym.</div>
      <div class="bub b"><span class="who">B</span>That's not true! She goes twice a week. What about you?</div>
    </div>
  </div></div>
</div>''')

# ------------------------------------------------------------------ Two truths and a lie
def tl(n):
    return '<div class="ex-row"><span class="circ-num">%d</span><input class="ans-input" type="text" style="width:min(720px,100%%)" aria-label="sentence %d"></div>' % (n, n)
slide('s-g-truth', 'Speaking – Two Truths and a Lie', '''<div class="slide" id="s-g-truth">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Two truths and a lie</h2>
    <p class="instruction">Write <b>three sentences</b> about your habits or about someone in your family. Use an adverb or an expression of frequency. Two are true and one is a lie. I'll guess which is the lie!</p>
    <div class="chat" style="max-width:760px;">
      <div class="bub a"><span class="who">A</span>1. My dad never watches TV. 2. My mom goes to the gym twice a week. 3. My sister hardly ever eats pizza.</div>
      <div class="bub b"><span class="who">B</span>I think number 2 is a lie! Does your mom really go to the gym?</div>
    </div>
    %s%s%s
    <div class="gram-note">💬 Questions you can ask: <i>How often does she…? Does he really…? What time do you usually…?</i></div>
  </div></div>
</div>''' % (tl(1), tl(2), tl(3)))

# ================================================================== PRONUNCIATION: final -s and -es
def sfx(txt, cls):
    return '<span class="sfx %s">%s</span>' % (cls, txt)
slide('s-p1', 'Pronunciation – Final -s and -es', '''<div class="slide" id="s-p1">
  <div class="banner banner-pron">🔊 Pronunciation &amp; Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Final -s and -es</h2>
    <p class="instruction">Listen and repeat. Notice the three different sounds at the end of the verbs and nouns.</p>
    <!-- SB 3a (1.17): sound pictures snake /s/, zebra /z/, and /ɪz/ -->
    %s
    <div class="classify-cols three" style="margin:10px 0;">
      <div class="card" style="margin:0;"><div style="font-size:2.4rem;">🐍</div><b style="font-size:1.3rem;color:#FF4F7B;">snake /s/</b>
        <p class="eg-line">He like%s going to concert%s.</p><p class="eg-line">He meet%s interesting people on date%s.</p></div>
      <div class="card" style="margin:0;"><div style="font-size:2.4rem;">🦓</div><b style="font-size:1.3rem;color:#2FA07F;">zebra /z/</b>
        <p class="eg-line">He pay%s for their meal%s.</p><p class="eg-line">He wear%s nice clothe%s.</p></div>
      <div class="card" style="margin:0;"><div style="font-size:2.4rem;">🐝</div><b style="font-size:1.3rem;color:#7A2A86;">/ɪz/</b>
        <p class="eg-line">He us%s reading glasses.</p><p class="eg-line">He relax%s with boxes of chocolates.</p></div>
    </div>
    <div class="gram-box">
      <h3>Pronunciation of final -s and -es</h3>
      <p>The final <b>-s</b> is pronounced <span class="hl">/s/</span> or <span class="hl">/z/</span>.</p>
      <p>The final <b>-es</b> is pronounced <span class="hl">/ɪz/</span> after <b>c, ch, g, s, sh, x,</b> and <b>z</b>.</p>
    </div>
    <div class="ccq-box"><p class="ccq-label">💭 Try it!</p>
      <ul class="ccq-list">
        %s
        %s
      </ul>
    </div>
  </div></div>
</div>''' % (audio('1.17'),
             sfx('s', ''), sfx('s', ''), sfx('s', ''), sfx('s', ''),
             sfx('s', 'z'), sfx('s', 'z'), sfx('s', 'z'), sfx('s', 'z'),
             sfx('es', 'iz'), sfx('es', 'iz'),
             ccq('<b>Voiced</b> sounds: put your hand on your throat and say /z/. Can you feel it vibrate? And /s/?', '/z/ vibrates (voiced). /s/ does not (unvoiced). A <b>snake</b> = /s/. A <b>bee or fly</b> = /z/.'),
             ccq('The final <i>s</i> is /s/ after <b>unvoiced</b> sounds: /k/, /p/, /f/, /t/ (<i>walks, stops, laughs, eats</i>). What about <i>plays, parties</i>?', '/z/ — in all other cases the final <i>s</i> is voiced.')))

# ------------------------------------------------------------------ 3b classify verbs + nouns
def classify_block(prefix, items, eg):
    cols = [('snake', '🐍', '/s/', 'snake'), ('zebra', '🦓', '/z/', 'zebra'), ('iz', '🐝', '/ɪz/', 'iz')]
    colhtml = ''
    for tgt, pic, ipa, w in cols:
        e = ('<span class="given eg" data-ans="%s">%s</span>' % (tgt, eg[0])) if (eg and eg[1] == tgt) else ''
        colhtml += '<div class="classify-col" data-target="%s" onclick="classifyTarget(this)"><div class="col-head"><span class="pic">%s</span><span>%s</span><span class="ipa">%s</span></div>%s</div>' % (tgt, pic, w, ipa, e)
    chips = ''.join('<button class="classify-chip" data-ans="%s" onclick="classifyPick(this)">%s</button>' % (t, w) for w, t in items)
    return ('<div class="classify-bank" id="%s-bank" style="align-items:center;">%s</div><div class="classify-cols three" id="%s-cols">%s</div>'
            '<div class="btn-row"><button class="btn-check" onclick="checkClassifySlide(\'%s\')">Check Answers</button><button class="btn-reset" onclick="resetClassifySlide(\'%s\')">Reset</button></div>') % (prefix, chips, prefix, colhtml, prefix, prefix)
verbs = [('cooks', 'snake'), ('goes', 'zebra'), ('lives', 'zebra'), ('stops', 'snake'), ('teaches', 'iz')]
nouns = [('books', 'snake'), ('boys', 'zebra'), ('classes', 'iz'), ('friends', 'zebra'), ('languages', 'iz'), ('parents', 'snake')]
slide('s-p2', 'Pronunciation – Which Sound? (Verbs)', '''<div class="slide" id="s-p2">
  <div class="banner banner-pron">🔊 Pronunciation &amp; Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>How do you say the <i>he / she / it</i> form?</h2>
    <p class="instruction">How do you say the <i>he / she / it</i> form of these verbs? Click a verb, then click the column with the same final sound. Then listen and check.</p>
    <!-- SB 3b (1.18) verbs: choose cook go live stop teach. Example: chooses = /ɪz/ (TB). -->
    <div class="card" style="font-size:1.12rem;color:var(--navy);"><b>verbs:</b> choose · cook · go · live · stop · teach <span style="margin-left:18px;"><span class="example-badge">✓</span> <b>chooses</b> → /ɪz/</span></div>
    %s
    %s
    <div class="gram-note">⚠️ Most important: <b>lives</b> /lɪvz/ and <b>goes</b> /goʊz/ — NOT /ˈlɪvɪz/ or /ˈgoʊɪz/. In <b>chooses, teaches, classes,</b> and <b>languages</b> the <i>-es</i> is pronounced /ɪz/.</div>
  </div></div>
</div>''' % (audio('1.18'), classify_block('pv', verbs, ('chooses', 'iz'))))

slide('s-p3', 'Pronunciation – Which Sound? (Nouns)', '''<div class="slide" id="s-p3">
  <div class="banner banner-pron">🔊 Pronunciation &amp; Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>…and the plural of nouns</h2>
    <p class="instruction">Now do the same with the plural forms of these nouns. Click a noun, then click the column with the same final sound.</p>
    <!-- SB 3b (1.18) nouns: book boy class friend language parent. -->
    <div class="card" style="font-size:1.12rem;color:var(--navy);"><b>nouns:</b> book · boy · class · friend · language · parent</div>
    %s
    <div class="discuss-box" style="margin-top:14px;"><p class="discuss-label">🗣️ Say it!</p>
      <p style="margin:0;font-size:1.12rem;color:var(--navy);">Make one true sentence with each sound about <i>your</i> family: <i>My dad <b>cooks</b>… · My sister <b>lives</b>… · My mom <b>teaches</b>…</i></p></div>
  </div></div>
</div>''' % classify_block('pn', nouns, None))

# ================================================================== COMMUNICATION: A date for Clint
slide('s-comm1', 'Speaking – A Date for Clint', '''<div class="slide" id="s-comm1">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>A date for Clint</h2>
    <p class="instruction">Clint needs a date! Look at the two possible dates, <b>Maggie</b> and <b>Tessa</b>. Ask and answer questions about them. Then decide who is the better date for Clint.</p>
    <!-- SB 3c (Communication 1B). -->
    <div class="two-profiles">
      <div class="profile-card">
        %s
        <div class="pf-body"><p class="pf-name">Clint Bouchez</p><span class="pf-tag">52</span><span class="pf-tag">divorced</span><span class="pf-tag">businessman</span>
          <p class="pf-row"><span class="pf-lab">Looking for:</span> a woman who works, preferably a businesswoman. Someone who's independent, but funny and smart.</p></div>
      </div>
      <div>
        <div class="ccq-box" style="margin-top:0;"><p class="ccq-label">💭 Before you start</p>
          <ul class="ccq-list">
            %s
            %s
          </ul>
        </div>
        <div class="gram-box" style="margin:12px 0 0;"><h3>How it works</h3>
          <p>👩 <b>You</b> read Maggie's profile. 👩 <b>I</b> read Tessa's profile.</p>
          <p>Describe your woman when I ask. Ask <b>seven questions</b> about the other woman. Then <b>change roles</b>.</p></div>
      </div>
    </div>
  </div></div>
</div>''' % (ph('📸', 'Photo: Clint Bouchez, smiling, in a dark suit and bow tie'),
             ccq('What kind of woman does Clint want to meet?', 'A woman who works, is independent, funny and smart.'),
             ccq('Which question asks about her <b>appearance</b>? Which asks about her <b>personality</b>?', '<i>What does she look like?</i> = appearance · <i>What\'s she like?</i> = personality.')))

def qlist(items):
    return '<ol style="margin:6px 0 0 22px;padding:0;font-size:1.1rem;color:var(--navy);line-height:1.8;">' + ''.join('<li>%s <input type="text" class="ans-input" style="width:min(300px,100%%)" aria-label="note"></li>' % q for q in items) + '</ol>'
qa_ = ['What does she look like?', 'How old is she?', "What's her status?", 'What does she do?', "What's she like?", 'What does she like doing?', "What kind of men doesn't she like?"]
qb_ = ['What does she look like?', 'How old is she?', "What's her status?", 'What does she do?', "What's she like?", 'What does she like doing?', "What doesn't she like doing?"]
slide('s-comm2', 'Speaking – You and Your Teacher', '''<div class="slide" id="s-comm2">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>You · Teacher</h2>
    <p class="instruction"><b>You:</b> read Maggie's profile, then answer my questions about her. Ask me questions 1–7 about Tessa. <b>Teacher:</b> I do the same with Tessa. You can hide your profile so you can answer from memory!</p>
    <!-- SB Communication 1B: A p.102, B p.108. Notes boxes let each student write down the answers. -->
    <div class="two-profiles">
      <div>
        <span class="role-head">You</span>
        <div class="profile-card" id="pfA">
          <div class="profile-hide">🙈 Profile hidden — click “Show profile” to see it again.</div>
          %s
          <div class="pf-body"><p class="pf-name">Maggie Carter, 49, divorced</p>
            <p class="pf-row"><span class="pf-lab">Occupation:</span> I have a small cosmetics business.</p>
            <p class="pf-row"><span class="pf-lab">Adjectives that describe you:</span> hardworking, independent, kind</p>
            <p class="pf-row"><span class="pf-lab">Likes and dislikes:</span> I like traveling and listening to classical music. I don't like clubbing or going to places with loud music.</p></div>
        </div>
        <button class="btn-suggest pf-toggle" onclick="document.getElementById('pfA').classList.toggle('hidden')" style="margin-top:12px;">👁️ Hide / show profile</button>
        <p class="discuss-label">Ask me about <b>Tessa</b>:</p>%s
      </div>
      <div>
        <span class="role-head">Teacher</span>
        <div class="profile-card alt" id="pfB">
          <div class="profile-hide">🙈 Profile hidden — click “Show profile” to see it again.</div>
          %s
          <div class="pf-body"><p class="pf-name">Tessa Mills, 42, single</p>
            <p class="pf-row"><span class="pf-lab">Occupation:</span> I'm a nurse.</p>
            <p class="pf-row"><span class="pf-lab">Adjectives that describe you:</span> fun, talkative, generous</p>
            <p class="pf-row"><span class="pf-lab">Likes and dislikes:</span> I like traveling, going to pop concerts, going out. I don't like cheap men who never pay for dates.</p></div>
        </div>
        <button class="btn-suggest pf-toggle" onclick="document.getElementById('pfB').classList.toggle('hidden')" style="margin-top:12px;">👁️ Hide / show profile</button>
        <p class="discuss-label">I ask you about <b>Maggie</b>:</p>%s
      </div>
    </div>
  </div></div>
</div>''' % (ph('📸', 'Photo: Maggie Carter, 49, short light hair and glasses, smiling, black jacket'), qlist(qa_),
             ph('📸', 'Photo: Tessa Mills, 42, long blonde hair, smiling, blue shirt, outdoors'), qlist(qb_)))

cg = [("works / has a job", True, True), ("independent", True, False), ("funny", False, True), ("smart", None, None)]
def cgrid():
    rows = ''
    items = [("A woman who works (a businesswoman?)",), ("Independent",), ("Funny / fun",), ("Smart",)]
    for (t,) in items:
        rows += '<div>%s</div><div class="cg-tick" onclick="this.classList.toggle(\'on\');this.textContent=this.classList.contains(\'on\')?\'✔\':\'\'"></div><div class="cg-tick" onclick="this.classList.toggle(\'on\');this.textContent=this.classList.contains(\'on\')?\'✔\':\'\'"></div>' % t
    return '<div class="check-grid"><div class="cg-h">What Clint wants</div><div class="cg-h" style="text-align:center;">Maggie</div><div class="cg-h" style="text-align:center;">Tessa</div>%s</div>' % rows
slide('s-comm3', 'Speaking – Who Is the Better Date?', '''<div class="slide" id="s-comm3">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Who is the better date for Clint?</h2>
    <p class="instruction">Compare the photos and the profiles. Tick what matches Clint's wishes. Then decide: who do you think is the better date for Clint, Maggie or Tessa? Say why – and I'll tell you my opinion!</p>
    <!-- SB 3c-d: compare photos; class vote with a show of hands. -->
    %s
    <div class="vote-wrap">
      <div class="vote-card"><h4>Maggie</h4><div class="vote-count" id="vote-a">0</div><div class="vote-btns"><button onclick="voteAdd('a',1)">＋ vote</button><button class="minus" onclick="voteAdd('a',-1)">−</button></div></div>
      <div class="vote-card b"><h4>Tessa</h4><div class="vote-count" id="vote-b">0</div><div class="vote-btns"><button onclick="voteAdd('b',1)">＋ vote</button><button class="minus" onclick="voteAdd('b',-1)">−</button></div></div>
    </div>
    <div class="chat" style="max-width:760px;">
      <div class="bub a"><span class="who">A</span>I think Maggie is a better date because she's…</div>
      <div class="bub b"><span class="who">B</span>I don't agree. Tessa is better because she…</div>
    </div>
  </div></div>
</div>''' % cgrid())
