# -*- coding: utf-8 -*-
from s_a import S, slide, audio, green, ccq, reveal, ph, script_box, circ_opt_btn

def H(t):
    return '<span class="art-hl">%s</span>' % t

ARTICLE = '''<div class="article">
  <h3>Please date my dad!</h3>
  <p class="art-sub">"So, how was the date?"</p>
  <p>You probably think this is a parent asking the question to their child. But many children are now helping their single parents find love, too.</p>
  <p>Clint Bouchez, a 52-year-old businessman, was divorced ten years ago. His daughter, 26-year-old Charlotte, doesn't want her dad to end up alone – her mom remarried five years ago, and Charlotte has a boyfriend.</p>
  <p>Charlotte and Clint are very close. They often go out together in the evening, they're planning a trip to India for later in the year, and they're both Bruce Springsteen fans. But Charlotte thinks that Clint needs a new partner, and he agrees.</p>
  <p>"My dad is the perfect man," she says. "He's warm, he's generous, he knows how to look after a woman, how to treat a woman. He's a gentleman. He's always the one who pays on dates. He's romantic and he's %s. I don't mind spending Friday and Saturday nights with my dad and that says a lot – I'm only 26."</p>
  <p>Dating in the 21st century is very different from when Clint was young. Internet dating has changed everything. "It's difficult now just to walk over to a woman and ask her 'Can I buy you a drink?'" "Before, when you met people face to face, there was sometimes a 'spark,' a feeling of romantic destiny – you don't get that from someone's profile picture."</p>
  <p>Charlotte wrote Clint's dating profile for an online dating website. Clint would like to meet a woman who works, preferably a businesswoman. Someone who's independent, but %s and smart. He has had several dates, but none of the women were right for him. He and Charlotte are still looking. "I'm always hopeful," he says. "I really believe that sooner or later I'm going to find 'the one.'"</p>
</div>''' % (H('fun'), H('funny'))

def article_toggle(tid):
    return ('<div class="btn-row" style="justify-content:flex-start;"><button class="btn-akey" onclick="toggleSuggested(\'%s\')">📖 Show / hide the article</button></div>'
            '<div class="akey-box" id="%s" style="background:#fff;">%s</div>') % (tid, tid, ARTICLE)

# ------------------------------------------------------------------ 1d: read and find info about Clint
def inf(n, label, ans, alt):
    return '<div class="ex-row"><span class="circ-num">%d</span><b>%s</b> <input class="ans-input" style="width:min(560px,100%%)" data-ans="%s" data-alt="%s" aria-label="%s"></div>' % (n, label, ans, alt, label)
slide('s-read1', 'Reading – Please Date My Dad!', '''<div class="slide" id="s-read1">
  <div class="banner banner-vocab">📖 Reading</div>
  <div class="slide-main"><div class="content">
    <h2>Please date my dad!</h2>
    <p class="instruction">First, look at the title. Then read the article about Charlotte and her father Clint. Find the information about Clint.</p>
    <!-- SB 1d. Before reading (TB): elicit the meaning of the verb date and the noun date. -->
    <div class="ccq-box"><p class="ccq-label">💭 Before you read: the word <b>date</b></p>
      <ul class="ccq-list">
        %s
        %s
      </ul>
    </div>
    <div class="art-two">
      <div class="art-scroll">%s</div>
      <div>
        %s
        %s
        <p class="discuss-label" style="margin-top:14px;">Find the information about Clint:</p>
        <div id="read1">%s%s%s%s%s</div>
        <div class="btn-row">
          <button class="btn-check" onclick="checkSlide('read1')">Check Answers</button>
          <button class="btn-reset" onclick="resetSlide('read1')">Reset</button>
        </div>
      </div>
    </div>
  </div></div>
</div>''' % (ccq('<b>date</b> as a <i>verb</i>: "Charlotte wants her father to date." What does Clint do?', 'He goes out with someone in a <b>romantic</b> relationship (e.g., to dinner, to the movies).'),
             ccq('<b>date</b> as a <i>noun</i>: "How was the date?" What is a date?', 'A <b>romantic meeting</b> — e.g., dinner with someone you like.'),
             ARTICLE,
             ph('📸', 'Photo: Charlotte and Clint laughing and throwing confetti'),
             ph('📸', 'Photo: Charlotte fixing Clint\'s bow tie'),
             inf(1, 'his age:', '52', '52 years old|fifty-two|fifty two'),
             inf(2, 'his job:', 'businessman', 'a businessman|business man'),
             inf(3, 'his marital status:', 'divorced', 'he is divorced|he\'s divorced'),
             inf(4, 'his personality:', 'warm, generous, a gentleman, romantic, fun', 'warm|generous|romantic|fun|a gentleman|gentleman|warm, generous, romantic, fun|warm, generous|warm and generous'),
             inf(5, 'his perfect partner:', 'a woman who works, independent, funny, smart', 'a businesswoman|independent|funny and smart|a woman who works|independent, funny and smart|independent, funny, smart')))

# ------------------------------------------------------------------ 1e: answer the questions
def qrow(n, q, a, extra=''):
    return ('<div class="ex-row"><span class="circ-num">%d</span><b>%s</b><br>'
            '<input class="ans-input" style="width:min(720px,100%%);margin-left:32px;" aria-label="answer %d">'
            '<br><span style="margin-left:32px;">%s</span></div>') % (n, q, n, reveal('💡 Possible answer', a))
slide('s-read2', 'Reading – Answer the Questions', '''<div class="slide" id="s-read2">
  <div class="banner banner-vocab">📖 Reading</div>
  <div class="slide-main"><div class="content">
    <h2>Read again and answer</h2>
    <p class="instruction">Read the article again and answer the questions in your own words.</p>
    <!-- SB 1e. TB answers: 1 Because she doesn't want him to end up alone. 2 They go out together and are planning a trip together. 3 You met people face to face and, for example, invited them for a drink. 4 He finds dates online / on the internet. Charlotte has helped by writing his profile. -->
    %s
    %s%s%s%s
  </div></div>
</div>''' % (article_toggle('read2-art'),
             qrow(1, 'Why does Charlotte want to find Clint a partner?', "Because she doesn't want him to end up alone."),
             qrow(2, 'How do we know that Charlotte and Clint are close?', "They often go out together and they're planning a trip together (to India)."),
             qrow(3, 'What was dating like when Clint was young?', "You met people face to face and, for example, invited them for a drink. Sometimes there was a \"spark.\""),
             qrow(4, 'How does Clint find dates now, and how has Charlotte helped him?', 'He finds dates online (on the internet). Charlotte has helped by writing his dating profile.')))

# ------------------------------------------------------------------ 1f, 1g
slide('s-read3', 'Reading – Words and Opinions', '''<div class="slide" id="s-read3">
  <div class="banner banner-vocab">📖 Reading</div>
  <div class="slide-main"><div class="content">
    <h2>Two highlighted words</h2>
    <p class="instruction">Look at the two highlighted words in the article. Which word describes…?</p>
    <!-- SB 1f: 1 funny, 2 fun. 1g: whole-class opinions. -->
    %s
    <div id="read3">
      <div class="ex-row"><span class="circ-num">1</span>a person who makes you laugh <input class="ans-input" style="width:150px" data-ans="funny" aria-label="word 1"></div>
      <div class="ex-row"><span class="circ-num">2</span>a person who you can have a good time with <input class="ans-input" style="width:150px" data-ans="fun" aria-label="word 2"></div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('read3')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('read3')">Reset</button>
    </div>
    <div class="ccq-box"><p class="ccq-label">💭 Check your understanding</p>
      <ul class="ccq-list">
        %s
        %s
      </ul>
    </div>
    <div class="discuss-box" style="margin-top:16px;"><p class="discuss-label">💬 What do you think?</p>
      <ul class="discuss-list"><li>Do you think Charlotte is the best person to help find her dad a date? Why (not)?</li>
      <li>Would <i>you</i> like your family to help you find a partner?</li></ul></div>
  </div></div>
</div>''' % (article_toggle('read3-art'),
             ccq('Is <i>"Sofia is funny"</i> the same as <i>"Sofia is fun"</i>?', 'Not exactly. <b>Funny</b> = she makes you laugh. <b>Fun</b> = you have a good time with her (you don\'t have to laugh all the time).'),
             ccq('Can a party be <b>fun</b>? Can it be <b>funny</b>?', 'A party can be <b>fun</b> (a good time). A <b>funny</b> thing = it makes you laugh.')))

# ------------------------------------------------------------------ Useful verbs for people & relationships (teaches target language of the workbook)
vb = [
 ('get along (with)', '<i>I get along very well with my parents.</i><br>= you like each other and have no problems'),
 ('share', '<i>I share an apartment with some friends.</i><br>= two or more people use the same thing'),
 ('invite', '<i>We often invite friends for dinner.</i><br>= ask someone to come to your home / to an event'),
 ('earn', '<i>She earns a lot of money.</i><br>= you get money for your work'),
 ('prefer', '<i>I prefer to be in a group.</i><br>= you like it more than something else'),
 ('marry / get married', '<i>Louisa wants to marry her boyfriend.</i><br>= become husband and wife'),
 ('pay for', '<i>He\'s always the one who pays for dinner.</i><br>= give money for something you buy'),
 ('make (someone) laugh', '<i>She\'s funny. She makes me laugh.</i>'),
 ('end up alone', '<i>She doesn\'t want her dad to end up alone.</i><br>= finally be without a partner'),
]
vcards = ''.join('<button class="verb-card" onclick="this.classList.toggle(\'open\')"><span class="vc-verb">%s</span><span class="vc-hint">click for an example</span><span class="vc-partner">%s</span></button>' % (v, p) for v, p in vb)
slide('s-vbs', 'Vocabulary – Useful Verbs', '''<div class="slide" id="s-vbs">
  <div class="banner banner-vocab">📚 Vocabulary</div>
  <div class="slide-main"><div class="content">
    <h2>Verbs for people and relationships</h2>
    <p class="instruction">Click each verb to see an example sentence and the meaning. Then make a true sentence about you or someone you know.</p>
    <!-- These verbs come from the article, the Grammar Bank and the Workbook (WB 2a, 2c), so the homework target language is taught in class. -->
    <div class="verb-grid">%s</div>
    <div class="ccq-box" style="margin-top:16px;"><p class="ccq-label">💭 CCQs</p>
      <ul class="ccq-list">
        %s
        %s
        %s
      </ul>
    </div>
    <div class="gram-note">🐾 Two extra words from the exercises: a <b>vet</b> = an animal doctor · <b>rain</b> (verb) = <i>It rains a lot in the winter.</i></div>
  </div></div>
</div>''' % (vcards,
             ccq('If you <b>get along</b> well with your boss, do you like working with him / her?', 'Yes — you have a good relationship and no problems.'),
             ccq('Do you <b>earn</b> money when you go shopping?', 'No — you <i>spend</i> money. You <b>earn</b> money when you work.'),
             ccq('If I <b>prefer</b> tea to coffee, which do I drink more often?', 'Tea.')))
