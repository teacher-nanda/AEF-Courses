
/* ===================== AUDIO FILES (fill in when the files are available) ===================== */
var AUDIO = {
  '1.2':'AEF3e_Level_2_SB_1.2.mp3', '1.3':'', '1.4':'AEF3e_Level_2_SB_1.4.mp3', '1.5':'AEF3e_Level_2_SB_1.5.mp3', '1.6':'', '1.7':'', '1.8':'AEF3e_Level_2_SB_1.8.mp3', '1.9':'AEF3e_Level_2_SB_1.9.mp3', '1.10':'AEF3e_Level_2_SB_1.10.mp3', 'WB1.1':'AEF3e_Level_2_WB_1.1.mp3'
};
document.querySelectorAll('audio[data-track]').forEach(function(a){
  var f = AUDIO[a.dataset.track];
  if (f) { a.src = f; var box = a.closest('.audio-box'); if (box) box.classList.remove('pending'); }
});

/* ===================== GRAMMAR: SPOT THE MISTAKES ===================== */
function checkNotice(sid){
  var box = document.getElementById(sid);
  box.querySelectorAll('.notice-row').forEach(function(row){
    var ok = row.dataset.ok;
    var btns = row.querySelectorAll('.circ-opt');
    var picked = null;
    btns.forEach(function(b){ b.classList.remove('correct','wrong'); if (b.classList.contains('picked')) picked = b; });
    var inp = row.querySelector('.notice-in');
    inp.classList.remove('correct','wrong','empty-warn');
    if (!picked) { inp.classList.add('empty-warn'); return; }
    picked.classList.add(picked.textContent.trim() === ok ? 'correct' : 'wrong');
    if (ok === '✗') {
      var val = norm(inp.value);
      if (!val) { inp.classList.add('empty-warn'); return; }
      var ans = norm(inp.dataset.ans);
      var alts = (inp.dataset.alt || '').split('|').map(norm).filter(Boolean);
      inp.classList.add((val === ans || alts.indexOf(val) > -1) ? 'correct' : 'wrong');
    }
  });
}
function resetNotice(sid){
  var box = document.getElementById(sid);
  box.querySelectorAll('.circ-opt').forEach(function(b){ b.classList.remove('picked','correct','wrong'); });
  box.querySelectorAll('.notice-in').forEach(function(i){ i.value=''; i.classList.remove('correct','wrong','empty-warn'); });
}

/* ===================== SPEAKING: QUESTION ROULETTE ===================== */
var ROUL_Q = [
  "Where are you from?", "Where were you born?", "Where do you live?", "Do you live in a house or an apartment?",
  "Do you have any brothers and sisters?", "Do you have any pets?", "What do you do?", "What time do you get up during the week?",
  "Where do you usually have lunch?", "What time do you usually go to bed?", "Where did you study English before?",
  "Can you speak any other languages? Which?", "What kind of music do you listen to?", "What TV shows or series do you watch?",
  "Do you exercise or play any sports? What?", "What kinds of books or magazines do you read?", "How often do you go to the movies?",
  "What did you do last weekend?"
];
var roulBusy = false;
function roulDraw(){
  if (roulBusy) return;
  roulBusy = true;
  var ball = document.getElementById('roul-ball');
  ball.classList.remove('empty'); ball.classList.add('spin');
  var n = 0;
  var t = setInterval(function(){
    ball.textContent = 1 + Math.floor(Math.random() * ROUL_Q.length);
    if (++n > 8) {
      clearInterval(t);
      var i = nextNoRepeat('roul', ROUL_Q.length);
      ball.classList.remove('spin');
      ball.textContent = i + 1;
      document.getElementById('roul-q').textContent = ROUL_Q[i];
      document.getElementById('roul-sub').textContent = 'Answer it with extra information — then return it: And you? / What about you?';
      roulBusy = false;
    }
  }, 70);
}
function roulReset(){
  shuffleBags['roul'] = null; shuffleLast['roul'] = undefined;
  var ball = document.getElementById('roul-ball');
  ball.textContent = '?'; ball.classList.add('empty'); ball.classList.remove('spin');
  document.getElementById('roul-q').textContent = 'Press the button to draw a question.';
  document.getElementById('roul-sub').textContent = '';
}

/* ===================== WRAP-UP: LOCK PUZZLE ===================== */
function checkLock(lockEl){
  var input = lockEl.querySelector('.lock-input');
  var codes = (lockEl.dataset.code || '').split('|').map(norm);
  var ok = codes.indexOf(norm(input.value)) > -1;
  lockEl.classList.toggle('unlocked', ok);
  lockEl.querySelector('.lock-icon').textContent = ok ? '🔓' : '🔒';
  var all = document.querySelectorAll('#s-review .lock').length;
  var open = document.querySelectorAll('#s-review .lock.unlocked').length;
  document.getElementById('lock-win').classList.toggle('show', open === all);
}


/* ===================== CONVERSATION: CHAT WITH ALEX ===================== */
var CC = [
 {hi:"Hi! I'm Alex. Nice to meet you! 😊", task:"Ask Alex where he's from.", opts:[["Where are you from?",1],["Where you are from?",0],["Are you where from?",0]], reply:"I'm from Toronto. And you?", answer:"Answer Alex."},
 {task:"Ask Alex if he has any brothers or sisters.", opts:[["Do you have any brothers or sisters?",1],["You have any brothers or sisters?",0],["Do have you any brothers or sisters?",0]], reply:"Yes, I have a sister. She's 15. What about you?", answer:"Answer Alex."},
 {task:"Ask what Alex's sister does.", opts:[["What does your sister do?",1],["What your sister does?",0],["What does do your sister?",0]], reply:"She's a student. She studies music and she plays the violin!", answer:"Answer Alex."},
 {task:"Ask if Alex can speak other languages.", opts:[["Can you speak any other languages?",1],["Do you can speak any other languages?",0],["You can speak any other languages?",0]], reply:"Yes, I can speak French and a little Spanish. Can you speak any other languages?", answer:"Answer Alex."},
 {task:"Ask where Alex went last weekend.", opts:[["Where did you go last weekend?",1],["Where you went last weekend?",0],["Where went you last weekend?",0]], reply:"I went to the movies with some friends. And you? What did you do?", answer:"Answer Alex."},
 {task:"Ask what kind of music Alex listens to.", opts:[["What kind of music do you listen to?",1],["What kind of music you listen to?",0],["What kind of music do you listen?",0]], reply:"I listen to electronic music. What about you?", answer:"Answer Alex."}
];
var ccI = 0, ccMistakes = 0;
function ccBub(who, html, typing){
  var d = document.createElement('div'); d.className = 'bub ' + who + (typing ? ' typing' : ''); d.innerHTML = html;
  var th = document.getElementById('cc-thread'); th.appendChild(d); th.scrollTop = th.scrollHeight; return d;
}
function ccInit(){
  ccI = 0; ccMistakes = 0;
  var th = document.getElementById('cc-thread'); if (!th) return;
  th.innerHTML = '';
  ccBub('a', CC[0].hi);
  ccAsk();
}
function ccAsk(){
  var c = CC[ccI], box = document.getElementById('cc-controls');
  var opts = shuffleArray(c.opts);
  box.innerHTML = '<p class="cc-task">💬 ' + c.task + '</p>' + opts.map(function(o, k){
    return '<button class="cc-opt" data-ok="' + o[1] + '" onclick="ccPick(this)">' + o[0] + '</button>';
  }).join('') + '<p class="cc-hint" id="cc-hint"></p>';
}
function ccPick(btn){
  if (btn.dataset.ok !== '1'){
    btn.classList.add('bad'); ccMistakes++;
    document.getElementById('cc-hint').textContent = 'Not quite — try again!';
    return;
  }
  var c = CC[ccI], box = document.getElementById('cc-controls');
  ccBub('b', btn.textContent);
  box.innerHTML = '';
  var t = ccBub('a', '…', true);
  setTimeout(function(){
    t.classList.remove('typing'); t.innerHTML = c.reply;
    var th = document.getElementById('cc-thread'); th.scrollTop = th.scrollHeight;
    var last = ccI === CC.length - 1;
    box.innerHTML = '<p class="cc-task">🎤 ' + c.answer + '</p><div class="cc-row"><input type="text" aria-label="your answer" placeholder="Type or say your answer…"><button class="btn-check" onclick="ccNext()">' + (last ? 'Finish ✔' : 'Next ▶') + '</button></div>';
  }, 700);
}
function ccNext(){
  var box = document.getElementById('cc-controls');
  var inp = box.querySelector('input');
  if (inp && inp.value.trim()) ccBub('b', inp.value.trim().replace(/</g,'&lt;'));
  ccI++;
  if (ccI >= CC.length){
    ccBub('a', "This was fun! Let's talk again soon! 👋");
    box.innerHTML = '<p class="cc-task">🎉 Great chat! ' + (ccMistakes === 0 ? 'No mistakes — perfect word order!' : ccMistakes + ' wrong ' + (ccMistakes === 1 ? 'try' : 'tries') + ' — good practice!') + '</p><p style="margin:0 0 10px;font-size:1.1rem;color:var(--navy);">Now it\'s your turn: ask <i>me</i> the same questions (and returning them: <i>And you?</i>).</p><button class="btn-reset" onclick="ccInit()">↺ Chat again</button>';
  } else { ccAsk(); }
}
ccInit();

/* ===================== PRINT LESSON ===================== */
function printAll(){
  saveNotes();
  var injected = [];
  slides.forEach(function(slide, i){
    if (i === 0){
      var linkEl = document.createElement('div');
      linkEl.className = 'lesson-link-print';
      linkEl.innerHTML = '<span class="lp-title">__LESSON_NAME__</span>' +
        '<span class="lp-sub">📝 Here you can see our Notes from Class.</span>' +
        '<span class="lp-sub" style="margin-top:6px;">You can also access <a href="__URL__" target="_blank">this link</a> to review the lesson material and do your optional Homework activities.</span>';
      slide.insertBefore(linkEl, slide.firstChild);
      injected.push(linkEl);
    }
    var n = notesData[i] || '';
    if (n.replace(/<[^>]*>/g,'').trim()){
      var notesEl = document.createElement('div');
      notesEl.className = 'slide-notes-print';
      notesEl.innerHTML = '<div class="slide-notes-print-label">📝 Teacher Notes</div>' + n;
      slide.appendChild(notesEl);
      injected.push(notesEl);
    }
  });
  document.body.classList.add('print-all');
  window.print();
  setTimeout(function(){
    document.body.classList.remove('print-all');
    injected.forEach(function(el){ el.parentNode && el.parentNode.removeChild(el); });
  }, 1500);
}

/* ===================== UNSAVED-NOTES WARNING + PROGRESS BAR ===================== */
(function(){
  var notesUnsaved = false;
  document.addEventListener('input', function(e){ if (e.target && e.target.id === 'notesTA') notesUnsaved = true; });
  document.addEventListener('click', function(e){
    var t = e.target && e.target.closest ? e.target.closest('#dlNotesBtn') : null;
    if (t) setTimeout(function(){ notesUnsaved = false; }, 300);
  });
  window.addEventListener('beforeunload', function(e){
    if (notesUnsaved) { e.preventDefault(); e.returnValue = ''; return ''; }
  });
  var bar = document.getElementById('progBar'); var all = Array.prototype.slice.call(document.querySelectorAll('.slide'));
  function upd(){ var i = all.findIndex(function(x){ return x.classList.contains('active'); }); if (i < 0) return; bar.style.width = ((i+1)/all.length*100) + '%'; }
  new MutationObserver(upd).observe(document.getElementById('deck'), {attributes:true, subtree:true, attributeFilter:['class']});
  upd();
})();

/* init */
document.getElementById('counter').textContent = '1/' + slides.length;
document.getElementById('prevBtn').disabled = true;
loadNotes(0);

/* blank slots in the alphabet table */
(function(){
  var _ct = classifyTarget, _rs = resetClassifySlide;
  classifyTarget = function(col){
    var before = col.querySelectorAll('.placed').length;
    _ct(col);
    var tags = col.querySelectorAll('.placed');
    if (tags.length > before){
      var b = col.querySelector('.slot-blank:not(.gone)'), t = tags[tags.length-1], old = t.onclick;
      if (b){ b.classList.add('gone'); }
      t.onclick = function(e){ old(e); if (b) b.classList.remove('gone'); };
      var L = col.querySelector('.sc-letters'); if (L && b) L.insertBefore(t, L.querySelector('.slot-blank:not(.gone)') || null);
    }
  };
  resetClassifySlide = function(p){ _rs(p); document.querySelectorAll('#'+p+'-cols .slot-blank').forEach(function(x){ x.classList.remove('gone'); }); };
})();

/* ===================== SAVE NOTES AS PDF (student-friendly cover) ===================== */
function savePDF(){
  saveNotes();
  var hasNotes = Object.keys(notesData).some(function(k){ return notesData[k] && notesData[k].replace(/<[^>]*>/g,'').trim(); });
  if (!hasNotes){ alert('No notes to save yet!'); return; }
  var LESSON = '__URL__', HW = LESSON + '#homework';
  var win = window.open('', '_blank');
  var cards = '';
  slideIds.forEach(function(sid, idx){
    var note = notesData[idx] || '';
    if (!note.replace(/<[^>]*>/g,'').trim()) return;
    cards += '<div class="card"><div class="card-header">Slide '+(idx+1)+' &mdash; '+slideLabels[idx]+'</div><div class="card-body">'+note+'</div></div>';
  });
  var css =
    'body{font-family:"DM Sans","Segoe UI",system-ui,sans-serif;max-width:820px;margin:0 auto;padding:0 0 32px;color:#1C2B3A;background:#fff}'+
    '.hero{background:linear-gradient(135deg,#2B1B5E 0%,#5A2E8C 55%,#FF6B5E 130%);color:#fff;border-radius:0 0 28px 28px;padding:34px 36px 30px;position:relative;overflow:hidden}'+
    '.hero:after{content:"";position:absolute;right:-40px;top:-40px;width:200px;height:200px;border-radius:50%;background:rgba(255,255,255,.08)}'+
    '.hero .kicker{font-size:.85rem;letter-spacing:.22em;text-transform:uppercase;color:#FFD84D;font-weight:800;margin:0 0 6px}'+
    '.hero h1{font-family:"Fredoka","Segoe UI",sans-serif;font-size:2.3rem;line-height:1.1;margin:0 0 6px;font-weight:600}'+
    '.hero .sub{font-size:1.1rem;opacity:.92;margin:0}'+
    '.hero .date{display:inline-block;margin-top:14px;background:rgba(255,255,255,.16);border-radius:999px;padding:4px 14px;font-size:.9rem}'+
    '.how{margin:26px 28px 8px;background:#FFF8E1;border:3px solid #FFD84D;border-radius:22px;padding:20px 24px}'+
    '.how h2{font-family:"Fredoka","Segoe UI",sans-serif;font-size:1.45rem;margin:0 0 14px;color:#2B1B5E}'+
    '.step{display:flex;gap:14px;align-items:flex-start;margin:0 0 14px}'+
    '.step .n{flex:none;width:34px;height:34px;border-radius:50%;background:#2B1B5E;color:#fff;font-weight:800;display:flex;align-items:center;justify-content:center;font-size:1.1rem}'+
    '.step p{margin:0;font-size:1.08rem;line-height:1.55}'+
    '.btns{display:flex;gap:14px;flex-wrap:wrap;margin:6px 0 6px 48px}'+
    '.bigbtn{display:inline-block;text-decoration:none;color:#fff!important;font-weight:800;font-size:1.2rem;padding:13px 26px;border-radius:999px;border:3px solid #2B1B5E;box-shadow:0 5px 0 #2B1B5E}'+
    '.bigbtn.lesson{background:#1F9D6B}.bigbtn.hw{background:#FF6B5E}'+
    '.link-note{margin:6px 0 0 48px;font-size:.88rem;color:#5b5b6b;word-break:break-all}'+
    '.tip{margin-top:12px;font-size:.95rem;color:#5b5b6b}'+
    '.notes-title{font-family:"Fredoka","Segoe UI",sans-serif;font-size:1.5rem;color:#2B1B5E;margin:26px 28px 12px}'+
    '.card{border:1px solid #DDD;border-radius:12px;margin:0 28px 16px;overflow:hidden}'+
    '.card-header{background:#2B1B5E;color:#fff;padding:8px 14px;font-weight:700;font-size:.92rem;break-after:avoid-page;page-break-after:avoid}'+
    '.card-body{padding:12px 16px;font-size:1rem;line-height:1.7;orphans:3;widows:3}'+
    'mark{background:#FFE066;color:#1a1a1a;padding:0 2px}'+
    '[style*="background-color"]{color:#1a1a1a!important}'+
    '.card-body,.card-body *{color:#1a1a1a!important}'+
    '*{print-color-adjust:exact;-webkit-print-color-adjust:exact}'+
    '@media print{@page{margin:1.2cm}body{padding:0}.hero,.how{break-inside:avoid}}';
  var today = new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
  var html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Notes – '+document.title+'</title>'+
    '<link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600&family=DM+Sans:wght@400;700;800&display=swap" rel="stylesheet">'+
    '<style>'+css+'</style></head><body>'+
    '<div class="hero"><p class="kicker">Conversational English with teacher Nanda</p>'+
      '<h1>'+document.title.replace(' — ',' · ')+'</h1>'+
      '<p class="sub">📝 Your notes from class</p><span class="date">'+today+'</span></div>'+
    '<div class="how"><h2>👋 How to use this PDF</h2>'+
      '<div class="step"><div class="n">1</div><p><b>Read your notes</b> below. These are the notes we made together in class.</p></div>'+
      '<div class="step"><div class="n">2</div><p><b>Click the green button</b> to open the lesson on your computer, tablet or phone. You can practice our lesson content again or go to the Homework to review.</p></div>'+
      '<div class="btns"><a class="bigbtn lesson" href="'+LESSON+'" target="_blank">▶ Open the lesson</a></div>'+
      '<p class="link-note">If the button does not open, copy this link: '+LESSON+'</p></div>'+
    '<h2 class="notes-title">📝 Notes from class</h2>'+cards+'</body></html>';
  win.document.write(html);
  win.document.close();
  setTimeout(function(){ win.print(); }, 700);
}
/* open the Homework directly from the PDF button */
if (location.hash === '#homework' && document.getElementById('hw-cover')) { goToId('hw-cover'); }
