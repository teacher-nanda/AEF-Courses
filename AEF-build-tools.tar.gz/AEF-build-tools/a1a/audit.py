import asyncio, re
from playwright.async_api import async_playwright
JS=r'''
()=>{
 const res=[];
 document.querySelectorAll('.slide').forEach(s=>{
  const w=document.createTreeWalker(s,NodeFilter.SHOW_TEXT);
  let n; while(n=w.nextNode()){
    const t=n.textContent.trim(); if(!t) continue;
    const el=n.parentElement;
    if(el.closest('.circ-num,.example-badge,.ex-tag,.cover-bubble,.title-label,.title-sub,.title-main,.hw-badge,.title-inner,.banner,.photo-num,script,style')) continue;
    const fs=parseFloat(getComputedStyle(el).fontSize);
    if(fs<16.7) res.push([s.id,fs,t.slice(0,40)]);
  }
 });
 return res;
}'''
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':1366,'height':820})
        await pg.goto('file:///tmp/aef/a1a/index.html'); await pg.wait_for_timeout(500)
        # make all slides measurable
        await pg.add_style_tag(content='.slide{opacity:1!important}')
        r=await pg.evaluate(JS)
        print(len(r)); [print(x) for x in r[:25]]
        await b.close()
asyncio.run(main())
