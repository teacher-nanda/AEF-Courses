# -*- coding: utf-8 -*-
from s_a import S, slide, audio, green

# ------------------------------------------------------------------ PRON 1: say the letters (1.6)
groups = ["ABCD", "EFGH", "IJKL", "MNOP", "QRST", "UVW", "XYZ"]
grp = ''.join('<div class="alpha-group">%s</div>' % g for g in groups)
sounds = [("🚂", "/eɪ/", "train", "AHJ"), ("🌳", "/i/", "tree", "BCDPTVZ"), ("🥚", "/ɛ/", "egg", "FLNS"), ("🚲", "/aɪ/", "bike", "I"),
          ("☎️", "/oʊ/", "phone", ""), ("🥾", "/u/", "boot", "UW"), ("🚗", "/ɑr/", "car", "")]
BLANKS = {"train":1, "tree":2, "egg":2, "bike":1, "phone":1, "boot":1, "car":1}
cells = ''
for i, (pic, ipa, w, giv) in enumerate(sounds, 1):
    if i == 1:
        inner = '<span class="eg-word">%s</span>' % w
    else:
        inner = '<input class="ans-input" data-ans="%s" aria-label="word %d" onclick="event.stopPropagation()">' % (w, i)
    gl = ''.join('<span class="given%s"%s>%s</span>' % (' eg' if (i == 1 and l == 'J') else '', ' data-ans="train"' if (i == 1 and l == 'J') else '', l) for l in giv)
    gl += '<span class="slot-blank"></span>' * BLANKS[w]
    cells += ('<div class="classify-col sound-cell" data-target="%s" onclick="classifyTarget(this)">'
              '<div class="bk-top"><span class="bk-pic">%s</span><span class="bk-ipa">%s</span></div>'
              '<div class="bk-word"><span class="sc-num">%d</span>%s</div>'
              '<div class="sc-letters">%s</div></div>') % (w, pic, ipa, i, inner, gl)
LMAP = {"train":"K","tree":"","egg":"MX","bike":"Y","phone":"O","boot":"Q","car":"R","tree2":"EG"}
_ans = {"E":"tree","G":"tree","K":"train","M":"egg","O":"phone","Q":"boot","R":"car","X":"egg","Y":"bike"}
chips = ''.join('<button class="classify-chip" data-ans="%s" onclick="classifyPick(this)">%s</button>' % (_ans[l], l) for l in sorted(_ans))
grp = ''.join('<div class="alpha-group">%s</div>' % g for g in ["ABCD", "EFGH", "IJKL", "MNOP", "QRST", "UVW", "XYZ"])
slide('s-pron1', 'Pronunciation – The Alphabet', '''<div class="slide" id="s-pron1">
  <div class="banner banner-pron">🔊 Pronunciation</div>
  <div class="slide-main"><div class="content">
    <h2>The alphabet</h2>
    <p class="instruction">Read the letters out loud.</p>
    <!-- SB 1.6 -->
    <div class="alpha-row">%s</div>
    <div class="gram-box">
      <h3>The alphabet</h3>
      <p>The letters of the alphabet are pronounced with <span class="hl">different vowel sounds</span>, e.g., <b>S</b> = /ɛs/, like <i>egg</i>, but <b>C</b> = /si/, like <i>tree</i>.</p>
    </div>
    <div class="gram-note">💡 In American English the last letter is <b>zee</b>. In British English it's <b>zed</b> — the only letter that is different.</div>
    <h3 style="margin-top:22px;">Sound pictures</h3>
    <p class="instruction">Look at the sound pictures. Try to complete with the missing words. Then click a letter and click the column with the same vowel sound.</p>
    <div id="pron2"><div class="classify-cols seven book" id="pcl-cols">%s</div></div>
    <div class="classify-bank" id="pcl-bank" style="align-items:center;justify-content:center;margin-top:14px;">%s</div>
    <div class="btn-row" style="margin-top:26px;margin-bottom:32px;">
      <button class="btn-check" onclick="checkSlide('pron2');checkClassifySlide('pcl')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('pron2');resetClassifySlide('pcl')">Reset</button>
    </div>
    <div class="gram-note" style="margin-top:0;margin-bottom:34px;">👂 Which letters are difficult for you? Watch out for pairs that are often confused: <b>A / E / I</b>, <b>G / J</b>, <b>K / Q</b>.</div>
    %s
  </div></div>
</div>'''  % (grp, cells, chips, audio('1.8')))

# ------------------------------------------------------------------ PRON 4: alphabet quiz A/B
qa = [
 ("Which country's security service is called the FBI?", "the US"),
 ("What do you use a USB cable for?", "connecting something to a computer"),
 ("What can you do at a B&amp;B?", "stay the night and have breakfast"),
 ("Which famous writer has the initials JK?", "J.K. Rowling"),
 ("What kind of person is a VIP?", "a very important person"),
 ("What can you get from an ATM?", "money / cash"),
 ("Which country's national radio and TV is called the BBC?", "the UK / Britain"),
]
qb = [
 ("What kind of machine is a BMW?", "a car"),
 ("What does a DJ do?", "plays music at a club"),
 ("Which country's national airline is called KLM?", "Holland / the Netherlands"),
 ("What's the difference between a.m. and p.m.?", "morning and afternoon"),
 ("What do people who work in IT do?", "They work with computers, software, etc."),
 ("How many states are there in the USA?", "50"),
 ("In the US do people have ID cards, passports, or both?", "only passports"),
]
def quiz(items):
    return ''.join('<div class="quiz-q"><b>%d</b> %s<br><button class="ccq-reveal-btn" onclick="this.nextElementSibling.classList.toggle(\'show\')">Answer</button><span class="ccq-answer">%s</span></div>' % (i+1, q, a) for i, (q, a) in enumerate(items))
slide('s-pron4', 'Pronunciation – Alphabet Quiz', '''<div class="slide" id="s-pron4">
  <div class="banner banner-pron">🔊 Pronunciation</div>
  <div class="slide-main"><div class="content">
    <h2>Alphabet quiz</h2>
    <p class="instruction">Take turns asking and answering the questions. You ask your question 1, then answer my question 1, and so on. The answers are under each question.</p>
    <!-- SB Communication: Alphabet quiz, A p.102 / B p.108 -->
    <div class="quiz-two">
      <div class="quiz-card"><h4>You</h4>%s</div>
      <div class="quiz-card b"><h4>Teacher</h4>%s</div>
    </div>
  </div></div>
</div>''' % (quiz(qa), quiz(qb)))

# ------------------------------------------------------------------ LISTEN 1: write letters and numbers (1.9)
def lrow(n, label, ans, alt=None, w=240):
    alttxt = (' data-alt="%s"' % alt) if alt else ''
    return '<div class="ex-row"><span class="circ-num">%d</span>%s <input class="ans-input" style="width:%dpx" data-ans="%s"%s aria-label="%s"></div>' % (n, label, w, ans, alttxt, label)
script19 = '''<div class="small-script">
<p><b>1</b><br><b>A:</b> How do you spell your first name?<br><b>B:</b> W-A-Y-N-E.</p>
<p><b>2</b><br><b>A:</b> What's the zip code?<br><b>B:</b> It's eight zero two two two.</p>
<p><b>3</b><br><b>B:</b> Nine one four, five five five, seven seven eight two.</p>
<p><b>4</b><br><b>A:</b> It's J-V-I-N-E-six-four at mail dot net.<br><b>B:</b> Can you repeat that, please?<br><b>A:</b> Yes, J-V-I-N-E-six-four at mail dot net.</p>
<p><b>5</b><br><b>B:</b> Ann Rathbone. R-A-T-H-B-O-N-E.</p>
<p><b>6</b><br><b>A:</b> It's sixteen Russell Street. That's R-U-S-S-E-L-L. Let me show you on the map.</p>
</div>'''
slide('s-listen1', 'Listening – Letters and Numbers', '''<div class="slide" id="s-listen1">
  <div class="banner banner-listening">🎧 Listening</div>
  <div class="slide-main"><div class="content">
    <h2>Understanding personal information</h2>
    <p class="instruction">Listen to extracts from six conversations. Write the letters and numbers you hear.</p>
    <!-- SB 1.9. Book numbers the example 1 (first name: Wayne). -->
    %s
    <div id="listen1" class="two-col-ex">
      <div class="ex-row"><span class="example-badge">1</span>first name: %s</div>
      %s%s%s%s%s
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('listen1')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('listen1')">Reset</button>
      <button class="btn-akey" onclick="toggleSuggested('l1-script')">📜 Script</button>
    </div>
    <div class="akey-box" id="l1-script">%s</div>
    <div class="gram-note" style="margin-top:18px;">🗣️ How do we say them? <b>@</b> = <i>at</i> · <b>.</b> = <i>dot</i> · <b>0</b> = <i>oh</i> or <i>zero</i> · we say phone numbers digit by digit.</div>
  </div></div>
</div>''' % (audio('1.9'), green('Wayne'),
             lrow(2, 'zip code:', '80222', None, 200),
             lrow(3, 'phone number:', '914-555-7782', '9145557782|914 555 7782', 220),
             lrow(4, 'email:', 'jvine64@mail.net', None, 280),
             lrow(5, 'last name:', 'Rathbone', None, 200),
             lrow(6, 'address:', '16 Russell Street', '16 Russell St|sixteen Russell Street', 280),
             script19))

# ------------------------------------------------------------------ LISTEN 2: match conversations (1.10)
script110 = '''<div class="small-script">
<p><b>1</b><br><b>A:</b> Good afternoon. How can I help you?<br><b>B:</b> I have a reservation for five nights.<br><b>A:</b> What's your name?<br><b>B:</b> Wayne Roberts.<br><b>A:</b> How do you spell your first name?<br><b>B:</b> W-A-Y-N-E.<br><b>A:</b> Just a moment.</p>
<p><b>2</b><br><b>A:</b> So, the sofa is $899.99 in total. What's the address for delivery? Is it a Denver address?<br><b>B:</b> Yes, it's in south Denver.<br><b>A:</b> What's the zip code?<br><b>B:</b> It's eight zero two two two.<br><b>A:</b> And the address is…?<br><b>B:</b> Two six zero two Leyden Street. That's near the Athletic Club.</p>
<p><b>3</b><br><b>A:</b> Welcome to our cell phone helpline. Please say the number of the cell phone you have a problem with.<br><b>B:</b> Nine one four, five five five, seven seven eight two.</p>
<p><b>4</b><br><b>A:</b> Now, every Friday I'm going to give you some writing to do for homework on the weekend. You can either give it to me in class on the following Monday, or you can send it to me by email. I'm going to give you my email address and I'd like you to write it down. OK? It's J-V-I-N-E-six-four at mail dot net.<br><b>B:</b> Can you repeat that, please?<br><b>A:</b> Yes, J-V-I-N-E-six-four at mail dot net. OK, now I'm going to write it on the board for you. Did you get it right?… Good job. Remember, this symbol is called at in English, and this one is dot.</p>
<p><b>5</b><br><b>A:</b> Good evening.<br><b>B:</b> Hi. We have a table booked for seven thirty.<br><b>A:</b> Yes, madam. What name, please?<br><b>B:</b> Ann Rathbone. R-A-T-H-B-O-N-E.<br><b>A:</b> Ah, yes, here we are. Can you come this way, please?</p>
<p><b>6</b><br><b>A:</b> OK Dan, that's great. Here's your student card. Your classes start on Monday at nine a.m. Now, the classes are not here in the main school but in a different building.<br><b>B:</b> Oh?<br><b>A:</b> But it's very near – just five minutes' walk from here, on Russell Street.<br><b>B:</b> Sorry, what's the address?<br><b>A:</b> It's sixteen Russell Street. That's R-U-S-S-E-L-L. Let me show you on the map.<br><b>B:</b> Thank you.</p>
</div>'''
sits = [("a", "buying something", 2), ("b", "checking into a hotel", 1), ("c", "trying to get help", 3),
        ("d", "giving a student directions", 6), ("e", "giving a class some information", 4), ("f", "arriving at a restaurant", 5)]
rows = ''
for l, t, p in sits:
    if p == 1:
        rows += '<div class="ex-row"><span class="circ-num">%s</span>%s <span class="example-badge">1</span></div>' % (l, t)
    else:
        rows += '<div class="ex-row"><span class="circ-num">%s</span>%s <input class="ans-input" style="width:70px;text-align:center" data-ans="%d" aria-label="conversation number for %s"></div>' % (l, t, p, t)
slide('s-listen2', 'Listening – Match the Situations', '''<div class="slide" id="s-listen2">
  <div class="banner banner-listening">🎧 Listening</div>
  <div class="slide-main"><div class="content">
    <h2>Six conversations</h2>
    <p class="instruction">Now listen to the conversations. Write the conversation number (1–6) for each situation.</p>
    <!-- SB 1.10. Book: 1 b is the example. -->
    %s
    <div id="listen2" class="two-col-ex">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('listen2')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('listen2')">Reset</button>
      <button class="btn-akey" onclick="toggleSuggested('l2-script')">📜 Script</button>
    </div>
    <div class="akey-box" id="l2-script">%s</div>
  </div></div>
</div>''' % (audio('1.10'), rows, script110))

# ------------------------------------------------------------------ LISTEN 3: student information form
slide('s-listen3', 'Speaking – Student Information', '''<div class="slide" id="s-listen3">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Interview and fill in the form</h2>
    <p class="instruction">Interview me and complete the form. If you don't want to give your real address and phone number, invent one.</p>
    <!-- SB p.7 ex 4c. Model question: What's your first name? -->
    <div class="chat" style="max-width:640px;">
      <div class="bub a"><span class="who">A</span>What's your first name?</div>
      <div class="bub b"><span class="who">B</span>It's … <i>(spell it!)</i></div>
    </div>
    <div class="form-badge">
      <div class="fb-head">STUDENT INFORMATION</div>
      <div class="fb-body">
        <div><label>First name</label><input type="text" aria-label="first name"></div>
        <div><label>Last name</label><input type="text" aria-label="last name"></div>
        <div class="wide"><label>Address</label><input type="text" aria-label="address"></div>
        <div><label>Zip code</label><input type="text" aria-label="zip code"></div>
        <div><label>Phone number</label><input type="text" aria-label="phone number"></div>
        <div class="wide"><label>Email address</label><input type="text" aria-label="email address"></div>
      </div>
    </div>
    <div class="gram-note" style="margin-top:18px;">✅ When you finish, show me your form to check the information. Is the spelling right?</div>
  </div></div>
</div>''')

# ------------------------------------------------------------------ REVIEW: lock puzzle
slide('s-review', 'Wrap-Up – Unlock the Party', '''<div class="slide" id="s-review">
  <div class="banner banner-review">🔓 Wrap-Up</div>
  <div class="slide-main"><div class="content">
    <h2>Unlock the party</h2>
    <p class="instruction">Type the answer in each box to open all four locks.</p>
    <div class="lock-row">
      <div class="lock" data-code="where do you live">
        <span class="lock-icon">🔒</span>
        <div class="lock-body"><p class="lock-q">Put the words in order: <i>live / where / do / you</i></p><input class="lock-input" type="text" oninput="checkLock(this.closest('.lock'))" aria-label="answer 1"></div>
      </div>
      <div class="lock" data-code="g">
        <span class="lock-icon">🔒</span>
        <div class="lock-body"><p class="lock-q">Which letter has the same vowel sound as <i>tree</i>: G, N, or Q?</p><input class="lock-input" type="text" oninput="checkLock(this.closest('.lock'))" aria-label="answer 2"></div>
      </div>
      <div class="lock" data-code="were">
        <span class="lock-icon">🔒</span>
        <div class="lock-body"><p class="lock-q">Where ___ you born? (one word)</p><input class="lock-input" type="text" oninput="checkLock(this.closest('.lock'))" aria-label="answer 3"></div>
      </div>
      <div class="lock" data-code="at">
        <span class="lock-icon">🔒</span>
        <div class="lock-body"><p class="lock-q">How do we say <b>@</b> in an email address?</p><input class="lock-input" type="text" oninput="checkLock(this.closest('.lock'))" aria-label="answer 4"></div>
      </div>
    </div>
    <div id="lock-win">🎉 You're in! Welcome to the party!</div>
    <p class="discuss-label" style="margin-top:20px;">💬 Now ask <i>me</i> three questions you've never asked before — one with <b>be</b>, one with <b>do / does</b>, and one with <b>did</b>.</p>
  </div></div>
</div>''')

# ================================================================== HOMEWORK
slide('hw-cover', 'Homework Cover', '''<div class="slide" id="hw-cover">
  <div class="title-inner">
    <div class="hw-badge">📝 Homework</div>
    <div class="title-main">Are you? Can you?<br>Do you? <span class="title-accent">Did you?</span></div>
  </div>
</div>''')

def ex_block(inner):
    return '<div class="ex-row ex-given">%s</div>' % inner
def badge1():
    return '<span class="example-badge">1</span>'

# ---- HW1: match verbs
hv = [("be born", 1), ("do", 2), ("listen to", 3), ("read", 4), ("speak", 5), ("live", 6), ("watch", 7), ("go", 8), ("have", 9)]
hn = [("a", "a movie, a TV series", 7), ("b", "in a house, with friends", 6), ("c", "an email, a book", 4), ("d", "two sisters, a pet", 9),
      ("e", "to the movies, on vacation", 8), ("f", "sports, your homework, exercise", 2), ("g", "a foreign language, English", 5), ("h", "electronic music, a presentation", 3), ("i", "in Toronto, Canada, in 1997", 1)]
L = ''.join(('<div class="match-item example-pair"><span class="circ-num">%d</span>%s</div>' % (n, v)) if n == 1 else
            ('<div class="match-item" data-side="left" data-pair="%d" onclick="matchPick(this)"><span class="circ-num">%d</span>%s</div>' % (n, n, v)) for v, n in hv)
R = ''.join(('<div class="match-item example-pair"><span class="circ-num">%s</span>%s</div>' % (l, t)) if p == 1 else
            ('<div class="match-item" data-side="right" data-pair="%d" onclick="matchPick(this)"><span class="circ-num">%s</span>%s</div>' % (p, l, t)) for l, t, p in hn)
slide('hw-voc1-slide', 'HW1 – Match the Verb Phrases', '''<!-- WB 1A ex 1a -->
<div class="slide" id="hw-voc1-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW1 — Common verb phrases</h2>
    <p class="instruction">Match the verbs on the left to the nouns on the right.</p>
    <div class="match-wrap" id="hwv1-match">
      <div><div class="match-col-head mc-left">Verbs</div>%s</div>
      <div><div class="match-col-head mc-right">Nouns</div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkMatchSlide('hwv1-match')">Check Answers</button>
      <button class="btn-reset" onclick="resetMatchSlide('hwv1-match')">Reset</button>
    </div>
  </div></div>
</div>''' % (L, R))

# ---- HW2: conversations
def conv(n, a, b, w=120):
    return '<div class="ex-row" style="margin-bottom:16px;"><span class="circ-num">%d</span><b>A:</b> %s<br><span style="margin-left:32px;display:inline-block;"><b>B:</b> %s</span></div>' % (n, a, b)
def blank(ans, alt=None):
    alttxt = (' data-alt="%s"' % alt) if alt else ''
    return '<input class="ans-input" style="width:130px" data-ans="%s"%s aria-label="missing word">' % (ans, alttxt)
c2 = [
 (2, 'What did you %s last weekend?' % blank('do'), 'I went to the movies with some friends.'),
 (3, 'Do you play any %s?' % blank('sports'), 'Yes, I play tennis and basketball.'),
 (4, 'What kind of %s do you listen to?' % blank('music'), 'I love pop and rock.'),
 (5, 'What do you usually have for %s?' % blank('lunch'), 'Usually just a sandwich and some potato chips.'),
 (6, 'Do you have any %s?' % blank('pets'), 'Yes, we have two cats.'),
 (7, 'Where do you %s?' % blank('live'), 'In a small apartment near the train station.'),
 (8, 'Where did you %s English before?' % blank('learn', 'study'), 'At school.'),
 (9, 'What does your father %s?' % blank('do'), 'He\'s a teacher.'),
 (10, 'Where were you %s?' % blank('born'), 'In the US, in 1998. My mom is Mexican.'),
]
cl = ''.join(conv(*c) for c in c2[:5]); cr = ''.join(conv(*c) for c in c2[5:])
slide('hw-voc2-slide', 'HW2 – Complete the Conversations', '''<!-- WB 1A ex 1b -->
<div class="slide" id="hw-voc2-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW2 — Complete the conversations</h2>
    <p class="instruction">Complete the conversations with the missing word.</p>
    %s
    <div class="fixed-two-col" id="hw-voc2">
      <div>%s</div>
      <div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('hw-voc2')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('hw-voc2')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<b>1</b>&nbsp;&nbsp;<b>A:</b> What time do you usually go to %s?<br><span style="display:inline-block;margin-left:24px;"><b>B:</b> At about 10:30, and I get up at 7:00.</span>' % green('bed')).replace('<b>1</b>&nbsp;&nbsp;', '<span class="example-badge">1</span>'), cl, cr))

# ---- HW3: circle the correct form
def opt(g, text, correct):
    return '<button class="circ-opt" data-group="%s" data-correct="%s" onclick="circPick(this)">%s</button>' % (g, correct, text)
def circ_item(n, pre, o1, o2, correct, post):
    g = 'hg3-%d' % n
    return '<div class="ex-row"><span class="circ-num">%d</span>%s%s<span class="circ-sep">/</span>%s%s</div>' % (n, pre, opt(g, o1, correct), opt(g, o2, correct), post)
c3 = [
 (2, 'Hello, ', 'I can', 'can I', 'can I', ' help you?'),
 (3, 'Where ', 'were you', 'you were', 'were you', ' born?'),
 (4, '', 'Do the children want', 'Want the children', 'Do the children want', ' a drink?'),
 (5, '', 'Did you see', 'Saw you', 'Did you see', ' the soccer game on TV last night?'),
 (6, 'What ', 'does do your boyfriend', 'does your boyfriend do', 'does your boyfriend do', '?'),
 (7, 'Where ', 'she learned', 'did she learn', 'did she learn', ' to speak English?'),
 (8, 'What time ', 'do you get up', 'get you up', 'do you get up', ' in the morning?'),
]
c3l = ''.join(circ_item(*c) for c in c3[:4]); c3r = ''.join(circ_item(*c) for c in c3[4:])
slide('hw-gr1-slide', 'HW3 – Correct Form', '''<!-- WB 1A ex 2a -->
<div class="slide" id="hw-gr1-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW3 — Choose the correct form</h2>
    <p class="instruction">Click the correct form to complete each question.</p>
    %s
    <div class="fixed-two-col" id="hw-gr1">
      <div>%s</div>
      <div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkCircSlide('hw-gr1')">Check Answers</button>
      <button class="btn-reset" onclick="resetCircSlide('hw-gr1')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<span class="example-badge">1</span><span class="ok-chip">Does your sister have ✓</span> <span class="strike-opt">Your sister has</span> a job?'), c3l, c3r))

# ---- HW4: re-order
def ro(n, words, ans):
    return '<div class="ex-row"><span class="circ-num">%d</span>%s<br><input class="ans-input" style="width:min(430px,100%%);margin-left:32px;" data-ans="%s" aria-label="question %d"></div>' % (n, words, ans, n)
h4 = [
 (2, 'girlfriend / student / is / a / your', 'Is your girlfriend a student?'),
 (3, 'what / on / you / do / the / weekend / do', 'What do you do on the weekend?'),
 (4, 'out / how / you / go / often / do', 'How often do you go out?'),
 (5, 'did / go / last / where / you / Saturday', 'Where did you go last Saturday?'),
 (6, 'a / did / time / nice / you / have', 'Did you have a nice time?'),
]
h4l = ''.join(ro(*r) for r in h4[:3]); h4r = ''.join(ro(*r) for r in h4[3:])
slide('hw-gr2-slide', 'HW4 – Re-order the Words', '''<!-- WB 1A ex 2b -->
<div class="slide" id="hw-gr2-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW4 — Re-order the words</h2>
    <p class="instruction">Re-order the words to make questions.</p>
    %s
    <div class="fixed-two-col" id="hw-gr2">
      <div>%s</div>
      <div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('hw-gr2')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('hw-gr2')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<span class="example-badge">1</span>do / do / parents / what / your<br><span class="given-line">%s</span>' % green('What do your parents do?')), h4l, h4r))

# ---- HW5: write questions
def wq(n, pre, cue, ans, post='?', w=300):
    return '<div class="ex-row"><span class="circ-num">%d</span>%s <input class="ans-input" style="width:%dpx" data-ans="%s" aria-label="question %d"> %s<br><span class="cue-chip" style="margin-left:32px;">%s</span></div>' % (n, pre, w, ans, n, post, cue)
h5 = [
 (2, 'What', '(you / do last night)', 'did you do last night'),
 (3, 'What', '(TV shows / you / watch)', 'TV shows do you watch'),
 (4, 'When', '(your birthday)', 'is your birthday'),
 (5, 'Where', '(you / from)', 'are you from'),
 (6, 'Where', '(you / go / on vacation last year)', 'did you go on vacation last year'),
 (7, 'What kind of books', '(you / read)', 'do you read'),
]
h5l = ''.join(wq(*r, w=270) for r in h5[:3]); h5r = ''.join(wq(*r, w=270) for r in h5[3:])
slide('hw-gr3-slide', 'HW5 – Write Questions', '''<!-- WB 1A ex 2c -->
<div class="slide" id="hw-gr3-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW5 — Write questions</h2>
    <p class="instruction">Write questions in the simple present or past.</p>
    %s
    <div class="fixed-two-col" id="hw-gr3">
      <div>%s</div>
      <div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('hw-gr3')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('hw-gr3')">Reset</button>
    </div>
  </div></div>
</div>''' % (ex_block('<span class="example-badge">1</span>Where %s? <span class="cue-chip">(you / live)</span>' % green('do you live')), h5l, h5r))

# ---- HW6: answer about you
h6q = ["Where do you live?", "What did you do last night?", "What TV shows do you watch?", "When is your birthday?",
       "Where are you from?", "Where did you go on vacation last year?", "What kind of books do you read?"]
h6 = ''.join('<div class="ex-row">%d. %s <input class="ans-input wide" style="width:min(520px,100%%)" aria-label="answer %d"></div>' % (i+1, q, i+1) for i, q in enumerate(h6q))
slide('hw-gr4-slide', 'HW6 – About You: Answer the Questions', '''<!-- WB 1A ex 2d -->
<div class="slide" id="hw-gr4-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW6 — Answer the questions about you</h2>
    <p class="instruction">Answer the questions from HW5 about you. Write full sentences.</p>
    <div>%s</div>
  </div></div>
</div>''' % h6)

# ---- HW7: odd one out (vowel sounds)
rows7 = [("🌳", "tree", 2, ["G", "V", "R"], "R"), ("🥚", "egg", 3, ["N", "B", "F"], "B"), ("🚂", "train", 4, ["H", "P", "J"], "P"),
         ("🥚", "egg", 5, ["X", "S", "K"], "K"), ("🌳", "tree", 6, ["M", "C", "D"], "M"), ("🥾", "boot", 7, ["Q", "I", "U"], "I")]
def r7row(pic, w, numhtml, btns):
    return '<div class="ex-row" style="display:flex;align-items:center;gap:12px;border-bottom:1px solid #E4E2FA;padding-bottom:4px;margin-bottom:6px;"><span class="circ-num-wrap" style="display:flex;align-items:center;min-width:118px;">%s<span style="font-size:1.5rem;margin-right:6px;">%s</span> <b>%s</b></span>%s</div>' % (numhtml, pic, w, btns)
r7items = [r7row("🚂", "train", '<span class="example-badge">1</span>',
    '<span class="circ-opt" style="min-width:48px;opacity:.55;cursor:default;pointer-events:none;">A</span><span class="circ-opt" style="min-width:48px;opacity:.55;cursor:default;pointer-events:none;">K</span><span class="circ-opt" style="min-width:48px;background:#E3F5EA;border-color:#1A7A4A;color:#1A7A4A;font-weight:800;cursor:default;pointer-events:none;">E ✓</span>')]
for pic, w, n, letters, corr in rows7:
    g = 'hp-%d' % n
    btns = ''.join('<button class="circ-opt" data-group="%s" data-correct="%s" onclick="circPick(this)" style="min-width:48px;">%s</button>' % (g, corr, l) for l in letters)
    r7items.append(r7row(pic, w, '<span class="circ-num">%d</span>' % n, btns))
r7 = '<div class="fixed-two-col" id="hw-pron" style="gap:0 36px;"><div>%s</div><div>%s</div></div>' % (''.join(r7items[:4]), ''.join(r7items[4:]))
slide('hw-pron-slide', 'HW7 – Different Vowel Sound', '''<!-- WB 1A ex 3a + 3b (WB audio 1.1) -->
<div class="slide" id="hw-pron-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW7 — The odd one out</h2>
    <p class="instruction">In each line, click the letter with a different vowel sound from the picture word. Then listen and check.</p>
    %s
    <div class="btn-row">
      <button class="btn-check" onclick="checkCircSlide('hw-pron')">Check Answers</button>
      <button class="btn-reset" onclick="resetCircSlide('hw-pron')">Reset</button>
    </div>
    <div style="margin-top:26px;">%s</div>
  </div></div>
</div>''' % (r7, audio('WB1.1')))

# ---- HW8: alphabet quiz (tiles)
qz = [(2, "play", "A"), (3, "you", "U"), (4, "see", "P"), (5, "go", "O"), (6, "why", "Y")]
tiles = ('<span class="wb-tile example-used" data-val="I">I</span>' +
         ''.join('<span class="wb-tile" data-val="%s" onclick="wbPick(this)">%s</span>' % (l, l) for l in ["A", "O", "P", "U", "Y"]))
# keep the book's order of letters: A I O P U Y
tiles = ''.join(('<span class="wb-tile example-used" data-val="I">I</span>' if l == 'I' else '<span class="wb-tile" data-val="%s" onclick="wbPick(this)">%s</span>' % (l, l)) for l in ["A", "I", "O", "P", "U", "Y"])
q8rows = ['<div class="ex-row" style="font-size:1.3rem;"><span class="example-badge">1</span>my <span class="given-line" style="display:inline-block;width:auto;margin:0;min-width:90px;text-align:center;">I</span></div>']
q8rows += ['<div class="ex-row" style="font-size:1.3rem;"><span class="circ-num">%d</span>%s <span class="wb-blank" data-ans="%s" onclick="wbPlace(this)">______</span></div>' % (n, w, a) for n, w, a in qz]
q8 = '<div class="fixed-two-col" id="hw-voc4" style="gap:0 40px;"><div>%s</div><div>%s</div></div>' % (''.join(q8rows[:3]), ''.join(q8rows[3:]))
slide('hw-voc4-slide', 'HW8 – Alphabet Quiz', '''<!-- WB 1A ex 3c -->
<div class="slide" id="hw-voc4-slide">
  <div class="banner banner-hw">📝 Homework</div>
  <div class="slide-main"><div class="content">
    <h2>HW8 — Alphabet quiz</h2>
    <p class="instruction">Which letter of the alphabet sounds like…? Click a letter in the bank, then click the blank where it belongs.</p>
    <div class="wb-bank book-style" id="hw-voc4-bank" style="font-size:1.3rem;">%s</div>
    %s
    <div class="btn-row">
      <button class="btn-check" onclick="checkWbSlide('hw-voc4')">Check Answers</button>
      <button class="btn-reset" onclick="resetWbSlide('hw-voc4')">Reset</button>
    </div>
  </div></div>
</div>''' % (tiles, q8))
