import asyncio
from playwright.async_api import async_playwright
JS = r'''
(sid)=>{
  const s=document.getElementById(sid); const out={};
  // typed
  s.querySelectorAll('input.ans-input[data-ans]').forEach(i=>{ i.value=i.dataset.ans; });
  // notice rows
  s.querySelectorAll('.notice-row').forEach(r=>{ const ok=r.dataset.ok; r.querySelectorAll('.circ-opt').forEach(b=>{ if(b.textContent.trim()===ok) b.click(); }); });
  // circle groups
  const seen={}; s.querySelectorAll('.circ-opt[data-correct]').forEach(b=>{ if(b.closest('.notice-row')) return; if(b.textContent.trim()===b.dataset.correct) b.click(); });
  // match
  s.querySelectorAll('.match-item[data-side="left"]').forEach(l=>{ const r=s.querySelector('.match-item[data-side="right"][data-pair="'+l.dataset.pair+'"]'); l.click(); if(r) r.click(); });
  // wb
  s.querySelectorAll('.wb-blank').forEach(b=>{ const t=[...s.querySelectorAll('.wb-tile')].find(x=>!x.classList.contains('used') && !x.classList.contains('example-used') && x.dataset.val===b.dataset.ans); if(t){ t.click(); b.click(); } });
  // classify
  s.querySelectorAll('.classify-chip[data-ans]').forEach(c=>{ c.click(); const col=[...s.querySelectorAll('.classify-col')].find(x=>x.dataset.target===c.dataset.ans); if(col) col.click(); });
  s.querySelectorAll('.btn-check').forEach(b=>b.click());
  const wrong=[...s.querySelectorAll('.wrong,.wrongpair,.empty-warn')].map(e=>e.outerHTML.slice(0,80));
  const ok=s.querySelectorAll('.correct,.correctpair').length;
  return {wrong, ok};
}
'''
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':1366,'height':820})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file:///tmp/aef/a1a/index.html'); await pg.wait_for_timeout(500)
        ids=await pg.evaluate('slideIds')
        for sid in ids:
            await pg.evaluate("goToId('%s')"%sid)
            r=await pg.evaluate(JS,sid)
            if r['wrong'] or r['ok']: print(sid,'ok=',r['ok'],'wrong=',r['wrong'][:3])
        # wrong answer test
        await pg.evaluate("goToId('s-vocab1')")
        await pg.evaluate("document.querySelector('#vocab1 input').value='zzz'; checkSlide('vocab1')")
        print('wrong flagged:', await pg.evaluate("document.querySelector('#vocab1 input').classList.contains('wrong')"))
        # roulette + locks
        await pg.evaluate("goToId('s-vocab4')"); await pg.evaluate("roulDraw()"); await pg.wait_for_timeout(900)
        print('roulette:', await pg.evaluate("document.getElementById('roul-q').textContent"))
        await pg.evaluate("goToId('s-review')")
        await pg.evaluate("document.querySelectorAll('#s-review .lock').forEach(l=>{l.querySelector('input').value=l.dataset.code; checkLock(l);})")
        print('win shown:', await pg.evaluate("document.getElementById('lock-win').classList.contains('show')"))
        # notes persistence
        await pg.evaluate("goToId('s-bridge'); document.getElementById('notesTA').innerHTML='hello'; saveNotes();")
        print('ls:', await pg.evaluate("localStorage.getItem(notesStoreKey)"))
        print('errors',errs)
        await b.close()
asyncio.run(main())
