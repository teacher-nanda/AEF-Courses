# -*- coding: utf-8 -*-
# Slides: cover -> grammar practice
S = []   # list of (id, label, html)

def slide(sid, label, html):
    S.append((sid, label, html))

def audio(track):
    # native audio element in styled pill; src is filled in from the AUDIO map (see script)
    return '<div class="audio-box pending"><audio controls data-track="%s"></audio></div>' % track

def green(txt):
    return '<span style="color:#1A7A4A;font-weight:800;background:#E3F5EA;padding:1px 7px;border-radius:5px;">%s</span>' % txt

# ------------------------------------------------------------------ COVER
slide('s1', 'Cover', '''<div class="slide active" id="s1">
  <div class="cover-bubble cb1" aria-hidden="true">Hello!</div>
  <div class="cover-bubble cb2" aria-hidden="true">What do you do?</div>
  <div class="cover-bubble cb3" aria-hidden="true">Nice to meet you!</div>
  <div class="cover-bubble cb4" aria-hidden="true">I'm in college.</div>
  <div class="title-inner">
    <div class="title-label">Conversational English</div>
    <div class="title-sub">with teacher Nanda</div>
    <div class="title-main">Are you? Can you?<br>Do you? <span class="title-accent">Did you?</span></div>
    <a href="../index.html" title="All AEF Courses" style="position:absolute;bottom:70px;left:32px;font-size:1.7rem;line-height:1;text-decoration:none;filter:drop-shadow(0 1px 3px rgba(0,0,0,.3));z-index:5;">🏠</a>
    <div style="position:absolute;bottom:70px;right:32px;z-index:5;">
      <button onclick="goToId('hw-cover')" style="background:#1C2B3A;color:#fff;border:none;border-radius:10px;padding:11px 24px;font-size:.95rem;font-weight:700;cursor:pointer;letter-spacing:.03em;">📝 Homework</button>
    </div>
  </div>
</div>''')

# ------------------------------------------------------------------ BRIDGE
slide('s-bridge', 'Bridge – Party Mingle', '''<div class="slide" id="s-bridge">
  <div class="banner banner-bridge">🌉 Bridge</div>
  <div class="slide-main"><div class="content">
    <h2>Party mingle</h2>
    <p class="instruction">Imagine you're at a party where you don't know anybody. Read each card, then say your answer out loud. You can jot down your words in the boxes.</p>
    <div class="nametag">
      <div class="nt-top">HELLO</div>
      <div class="nt-mid">my name is</div>
      <div class="nt-name"><input type="text" aria-label="your name"></div>
    </div>
    <div class="party-grid">
      <div class="party-card">
        <div class="pc-icon">👋</div>
        <h4>Say hello</h4>
        <p>A stranger comes up to you with a big smile. Introduce yourself!</p>
        <input class="ans-input" type="text" aria-label="introduce yourself">
      </div>
      <div class="party-card">
        <div class="pc-icon">🤝</div>
        <h4>Answer back</h4>
        <p>The stranger says: <i>"Hi, I'm Nanda. Nice to meet you."</i> What do you say?</p>
        <input class="ans-input" type="text" aria-label="answer back">
      </div>
      <div class="party-card">
        <div class="pc-icon">💬</div>
        <h4>One more thing</h4>
        <p>Keep the conversation going: tell me one thing about yourself.</p>
        <input class="ans-input" type="text" aria-label="one thing about you">
      </div>
    </div>
    <div class="gram-note">🎈 Now it's your turn to ask! What would you like to know about <i>me</i>? Think of one question.</div>
  </div></div>
</div>''')

# ------------------------------------------------------------------ WARM-UP
cards = [
 ("I'm from Rome.", "Where are you from?"),
 ("Yes, I do. I have two cats.", "Do you have any pets?"),
 ("At about seven o'clock.", "What time do you get up?"),
 ("I went to the movies with some friends.", "What did you do last weekend?"),
 ("I'm a nurse.", "What do you do?"),
 ("W-A-Y-N-E.", "How do you spell your first name?"),
]
wu = ''
for i, (a, q) in enumerate(cards, 1):
    wu += '''      <div class="wu-card">
        <div class="wu-ans">%s</div>
        <button class="ccq-reveal-btn" onclick="this.nextElementSibling.classList.toggle('show')">💡 A question that fits</button>
        <div class="wu-q">%s</div>
      </div>
''' % (a, q)
slide('s-warm', 'Warm-Up – What\'s the Question?', '''<div class="slide" id="s-warm">
  <div class="banner banner-leadin">🎯 Warm-Up</div>
  <div class="slide-main"><div class="content">
    <h2>What's the question?</h2>
    <p class="instruction">Each bubble is an <i>answer</i>. Ask the question that could get this answer — then click the button to compare with one possible question.</p>
    <div class="wu-grid">
%s    </div>
    <div class="quote-card">
      <p class="q-text">"Sometimes questions are more important than answers."</p>
      <p class="q-by">— Nancy Willard, American writer</p>
    </div>
    <ul class="discuss-list" style="margin-top:14px;">
      <li>Do you agree with her? Why (not)?</li>
      <li>Which questions were easy to ask? Which ones were tricky?</li>
    </ul>
  </div></div>
</div>''' % wu)

# ------------------------------------------------------------------ VOCAB 1: getting to know you
qs = [  # (before, answer, alt, after)
 ("Where do you ", "live", "", "?"),                                    # 3
 ("Do you ", "live", "", " in a house or an apartment?"),               # 4
 ("Do you ", "have", "", " any brothers and sisters?"),                 # 5
 ("Do you ", "have", "", " any pets?"),                                 # 6
 ("What do you ", "do", "", "?"),                                       # 7
 ("What time do you ", "get", "", " up during the week?"),             # 8
 ("Where do you usually ", "have", "", " lunch?"),                      # 9
 ("What time do you usually ", "go", "", " to bed?"),                   # 10
 ("Where did you ", "study", "learn", " English before?"),              # 11
 ("Can you ", "speak", "", " any other languages? Which?"),             # 12
 ("What kind of music do you ", "listen", "", " to?"),                  # 13
 ("What TV shows or series do you ", "watch", "like", "?"),             # 14
 ("Do you exercise or ", "play", "", " any sports? What?"),             # 15
 ("What kinds of books or magazines do you ", "read", "", "?"),         # 16
 ("How often do you ", "go", "", " to the movies?"),                    # 17
 ("What did you ", "do", "", " last weekend?"),                         # 18
]
def vrow(n, b, a, alt, af):
    altattr = (' data-alt="%s"' % alt) if alt else ''
    return '<div class="ex-row"><span class="circ-num">%d</span>%s<input class="ans-input" style="width:130px" data-ans="%s"%s aria-label="question %d">%s</div>' % (n, b, a, altattr, n, af)
left = ''.join(vrow(i+3, *qs[i]) for i in range(0, 8))
right = ''.join(vrow(i+3, *qs[i]) for i in range(8, 16))
slide('s-vocab1', 'Vocabulary – Getting to Know You', '''<div class="slide" id="s-vocab1">
  <div class="banner banner-vocab">📚 Vocabulary &amp; Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Getting to know you</h2>
    <p class="instruction">Complete the questions with a verb.</p>
    <!-- SB p.6 ex 1a. The book numbers the two done questions 1 and 2, and refers to "questions 1-6" later, so the numbering is kept as in the book. -->
    <div class="ex-row" style="display:flex;gap:30px;flex-wrap:wrap;margin-bottom:14px;">
      <span><span class="example-badge">1</span>Where %s you from?</span>
      <span><span class="example-badge">2</span>Where %s you born?</span>
    </div>
    <div class="fixed-two-col" id="vocab1">
      <div>%s</div>
      <div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('vocab1')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('vocab1')">Reset</button>
    </div>
    <!-- SB 1.2: listen and check -->
    <p class="discuss-label" style="margin-top:14px;">🎧 Now listen and check your answers.</p>
    %s
  </div></div>
</div>''' % (green('are'), green('were'), left, right, audio('1.2')))

allq = [
 "Where are you from?", "Where were you born?", "Where do you live?", "Do you live in a house or an apartment?",
 "Do you have any brothers and sisters?", "Do you have any pets?", "What do you do?", "What time do you get up during the week?",
 "Where do you usually have lunch?", "What time do you usually go to bed?", "Where did you study English before?",
 "Can you speak any other languages? Which?", "What kind of music do you listen to?", "What TV shows or series do you watch?",
 "Do you exercise or play any sports? What?", "What kinds of books or magazines do you read?", "How often do you go to the movies?",
 "What did you do last weekend?"]
# ------------------------------------------------------------------ VOCAB MAP (verb phrases)
vp = [("be born", "in Toronto, Canada, in 1997"), ("do", "sports, your homework, exercise"), ("listen to", "electronic music, a presentation"),
      ("read", "an email, a book"), ("speak", "a foreign language, English"), ("live", "in a house, with friends"),
      ("watch", "a movie, a TV series"), ("go", "to the movies, on vacation"), ("have", "two sisters, a pet")]
vcards = ''.join('<button class="verb-card" onclick="this.classList.toggle(\'open\')"><span class="vc-verb">%s</span><span class="vc-hint">click to check</span><span class="vc-partner">%s</span></button>' % (v, p) for v, p in vp)
slide('s-vocab-map', 'Vocabulary – Verb Phrases', '''<div class="slide" id="s-vocab-map">
  <div class="banner banner-vocab">📚 Vocabulary &amp; Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Common verb phrases</h2>
    <p class="instruction">Look at the common verb phrases. Try to guess what words and phrases usually go with each verb.<br>Click to check, and then make your own sentences.</p>
    <!-- Verb-phrase partners come from the Workbook (Vocabulary exercise), so the homework target language is taught in class. -->
    <div class="verb-grid">%s</div>
  </div></div>
</div>''' % vcards)

# ------------------------------------------------------------------ SPEAKING: returning a question
slide('s-vocab4', 'Speaking – Returning a Question', '''<div class="slide" id="s-vocab4">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>"Returning" a question</h2>
    <p class="instruction">Draw a question from the questionnaire and answer it. After you answer, "return" it to me – then I answer too.</p>
    <div class="gram-box">
      <h3>When you're having a conversation…</h3>
      <p>You often "return" questions, which means: ask somebody the same question that they asked you. You can do this by:</p>
      <ul>
        <li>saying <span class="hl">And you?</span> or <span class="hl">What about you?</span></li>
        <li>repeating the question, but stressing <span class="hl">you</span></li>
      </ul>
      <div class="chat">
        <div class="bub a"><span class="who">A</span>Where are you from?</div>
        <div class="bub b"><span class="who">B</span>I'm from Rome. Where are <b class="you">you</b> from?</div>
      </div>
    </div>
    <div class="roul-layout">
      <div class="roul-ball empty" id="roul-ball">?</div>
      <div class="roul-prompt card" style="margin:0;">
        <p class="roul-q" id="roul-q">Press the button to draw a question.</p>
        <p class="roul-sub" id="roul-sub"></p>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-roul" onclick="roulDraw()">🎲 Draw a question</button>
      <button class="btn-suggest" onclick="toggleSuggested('v4-sugg')">💡 Follow-up questions</button>
      <button class="btn-reset" onclick="roulReset()">Reset</button>
    </div>
    <div class="suggest-box" id="v4-sugg">
      <div class="chat" style="margin-top:0;">
        <div class="bub a"><span class="who">A</span>Do you have any brothers and sisters?</div>
        <div class="bub b"><span class="who">B</span>I have one brother.</div>
        <div class="bub a"><span class="who">A</span>How old is he? / What's his name? / What does he do?</div>
      </div>
      <p style="margin:0 0 6px;">Not at school or working? You can answer <i>What do you do?</i> with: <i>I'm unemployed. / I'm looking for a job. / I'm taking care of my children.</i></p>
      <p style="margin:0;">Found something in common? Use <b>both</b>: <i>We both live downtown. We're both doctors. We can both speak Spanish.</i></p>
    </div>
  </div></div>
</div>''')

# ------------------------------------------------------------------ GRAMMAR 1: spot the mistakes
def notice_row(n, html, ok, ans=None, alt=None):
    c = ok
    alttxt = (' data-alt="%s"' % alt) if alt else ''
    ansattr = (' data-ans="%s"' % ans) if ans else ''
    return ('<div class="ex-row notice-row" data-ok="%s" style="display:grid;grid-template-columns:minmax(0,1.05fr) auto minmax(0,1fr);gap:14px;align-items:center;">'
            '<span><span class="circ-num">%d</span>%s</span>'
            '<span><button class="circ-opt" data-group="nt-%d" data-correct="%s" onclick="circPick(this)">✓</button><button class="circ-opt" data-group="nt-%d" data-correct="%s" onclick="circPick(this)">✗</button></span>'
            '<input class="ans-input notice-in" style="width:100%%" aria-label="rewrite question %d"%s%s></div>') % (ok, n, html, n, c, n, c, n, ansattr, alttxt)
rows = ''.join([
 notice_row(2, '<span class="hl">Where works your</span> father?', '✗', 'Where does your father work?'),
 notice_row(3, '<span class="hl">Were you at this school</span> last year?', '✓'),
 notice_row(4, '<span class="hl">Is there a supermarket</span> near here?', '✓'),
 notice_row(5, '<span class="hl">Have you cereal</span> for breakfast?', '✗', 'Do you have cereal for breakfast?'),
 notice_row(6, '<span class="hl">Where went you</span> for your last vacation?', '✗', 'Where did you go for your last vacation?'),
])
slide('s-gram-notice', 'Grammar – Spot the Mistakes', '''<div class="slide" id="s-gram-notice">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Word order in questions</h2>
    <p class="instruction">Look at the highlighted phrases in questions 1–6. There are three correct questions in total. Mark the correct questions (✓) and rewrite the incorrect ones.</p>
    <!-- SB p.7 ex 2a. Book numbers the worked example 1. -->
    <div class="ex-row"><span class="example-badge">1</span><span class="gram-box" style="display:inline-block;padding:2px 12px;border-left-width:3px;box-shadow:none;margin:0 8px 0 0;"><span class="hl">Can you play</span> a musical instrument?</span> %s</div>
    <div id="notice">%s</div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkNotice('notice')">Check Answers</button>
      <button class="btn-reset" onclick="resetNotice('notice')">Reset</button>
    </div>
    <div class="gram-note" style="margin-top:20px;">💭 What's the problem with the incorrect questions? Which words are missing, or in the wrong place?</div>
  </div></div>
</div>''' % (green('✓'), rows))

# ------------------------------------------------------------------ GRAMMAR 2: form be / can
def ccq(q, a):
    return '<li>%s <button class="ccq-reveal-btn" onclick="this.nextElementSibling.classList.toggle(\'show\')">Show answer</button><span class="ccq-answer">%s</span></li>' % (q, a)
slide('s-gram-form1', 'Grammar – Questions with be and can', '''<div class="slide" id="s-gram-form1">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Questions with <i>be</i> and <i>can</i></h2>
    <p class="inst-light">Study how questions with <i>be</i> and <i>can</i> are formed.</p>
    <!-- Grammar Bank 1A -->
    <div class="qa-table-wrap">
      <table class="qa">
        <tr><th>Question word</th><th>Verb</th><th>Subject</th><th></th></tr>
        <tr><td></td><td class="aux">Are</td><td>you</td><td>hungry?</td></tr>
        <tr><td></td><td class="aux">Is</td><td>there</td><td>a bank near here?</td></tr>
        <tr><td></td><td class="aux">Can</td><td>I</td><td>sit here?</td></tr>
        <tr><td>What</td><td class="aux">was</td><td>that</td><td>noise?</td></tr>
        <tr><td>Where</td><td class="aux">were</td><td>you</td><td>born?</td></tr>
      </table>
    </div>
    <div class="gram-box">
      <p>We make questions with the verb <i>be</i> and <i>can</i> by <span class="hl">inverting the verb and the subject</span>.</p>
      <p><i>She is a teacher. → <b>Is she</b> a teacher?</i></p>
      <p><i>He can drive. → <b>Can he</b> drive?</i></p>
    </div>
    <div class="ccq-box">
      <p class="ccq-label">💭 Check your understanding</p>
      <ul class="ccq-list">
        %s
        %s
      </ul>
    </div>
    <div class="gram-mistake">
      <b>⚠️ Typical mistakes</b> — students sometimes forget to invert the subject and verb.
      <p style="margin:8px 0 0;"><s>Ana is a student?</s> → <b>Is Ana</b> a student?</p>
      <p style="margin:4px 0 0;">Where <s>I can</s> sit? → Where <b>can I</b> sit?</p>
    </div>
  </div></div>
</div>''' % (ccq('"She is a teacher." → "…she a teacher?" Which word moves, and where does it go?', 'The verb <i>is</i> moves in front of the subject: <i>Is she a teacher?</i>'),
              ccq('Do we need <i>do / does / did</i> in questions with <i>be</i> and <i>can</i>?', 'No — we just invert the verb and the subject.')))

# ------------------------------------------------------------------ GRAMMAR 3: form do/does/did
slide('s-gram-form2', 'Grammar – Questions with do / does / did', '''<div class="slide" id="s-gram-form2">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Questions with <i>do / does / did</i></h2>
    <p class="inst-light">Study how questions are formed in the simple present and simple past.</p>
    <div class="qa-table-wrap">
      <table class="qa">
        <tr><th>Question word</th><th>Auxiliary</th><th>Subject</th><th>Base form</th></tr>
        <tr><td></td><td class="aux">Do</td><td>you</td><td><span class="base">live</span> with your parents?</td></tr>
        <tr><td></td><td class="aux">Did</td><td>you</td><td><span class="base">take</span> a vacation last year?</td></tr>
        <tr><td>Where</td><td class="aux">does</td><td>your sister</td><td><span class="base">work</span>?</td></tr>
        <tr><td>When</td><td class="aux">did</td><td>you</td><td><span class="base">start</span> studying English?</td></tr>
        <tr><td>What</td><td class="aux">did</td><td>they</td><td><span class="base">talk</span> about?</td></tr>
      </table>
    </div>
    <div class="gram-box">
      <h3>Use this word order</h3>
      <p><span class="hl">auxiliary + subject + base form</span>, e.g., <i>Did you go out last night?</i></p>
      <p>or <span class="hl">question word + auxiliary + subject + base form</span>, e.g., <i>Where did you go?</i></p>
    </div>
    <div class="ccq-box">
      <p class="ccq-label">💭 Check your understanding</p>
      <ul class="ccq-list">
        %s
        %s
      </ul>
    </div>
    <div class="gram-mistake">
      <b>⚠️ Typical mistakes</b> — students might leave out the auxiliary or get the word order wrong.
      <p style="margin:8px 0 0;"><s>You live with your parents?</s> → <b>Do you</b> live with your parents?</p>
      <p style="margin:4px 0 0;">Why <s>she didn't</s> like the movie? → Why <b>didn't she</b> like the movie?</p>
    </div>
    <div class="gram-note" style="margin-top:14px;">📌 If a verb is followed by a preposition (<i>talk about, listen to</i>), the preposition goes at the <b>end</b> of the question: <i>What did you talk <b>about</b>?</i></div>
  </div></div>
</div>''' % (ccq('"Where does your sister work?" Does the main verb change to <i>works</i>?', 'No — after <i>do / does / did</i> we use the <b>base form</b>: <i>work</i>.'),
              ccq('In a question with <i>did</i>, what is the order of the words?', '(question word) + <i>did</i> + subject + base form.')))

# ------------------------------------------------------------------ PRONUNCIATION OF QUESTIONS (1.4 / 1.5)
def sent_list(items):
    return '<div class="card" style="margin:0;">' + ''.join('<div class="ex-row" style="margin-bottom:6px;">%s</div>' % s for s in items) + '</div>'
slide('s-gram-pron', 'Grammar – Say It with Rhythm', '''<div class="slide" id="s-gram-pron">
  <div class="banner banner-pron">🔊 Pronunciation</div>
  <div class="slide-main"><div class="content">
    <h2>Say it with rhythm</h2>
    <p class="instruction">Listen and repeat the example sentences from the grammar boxes. Copy the rhythm.</p>
    <!-- SB Grammar Bank 1.4 and 1.5 -->
    <div class="fixed-two-col" style="gap:0 30px;">
      <div>
        <p class="discuss-label">Questions with <i>be</i> and <i>can</i></p>
        %s
        %s
      </div>
      <div>
        <p class="discuss-label">Questions with <i>do / does / did</i></p>
        %s
        %s
      </div>
    </div>
  </div></div>
</div>''' % (audio('1.4'), sent_list(["Are you hungry?", "Is there a bank near here?", "Can I sit here?", "What was that noise?", "Where were you born?"]),
              audio('1.5'), sent_list(["Do you live with your parents?", "Did you take a vacation last year?", "Where does your sister work?", "When did you start studying English?", "What did they talk about?"])))

# ------------------------------------------------------------------ GRAMMAR BANK EX a
def put_row(n, pre, cue, ans, alt=None):
    alttxt = (' data-alt="%s"' % alt) if alt else ''
    return ('<div class="ex-row"><span class="circ-num">%d</span>%s <span class="cue-chip">%s</span><br>'
            '<input class="ans-input" style="width:min(520px,100%%);margin-left:32px;" data-ans="%s"%s aria-label="question %d"></div>') % (n, pre, cue, ans, alttxt, n)
ga = [
 ("Where we park?", "can", "Where can we park?"),
 ("How are you?", "old", "How old are you?"),
 ("Does finish at 8:00?", "the class", "Does the class finish at 8:00?"),
 ("Where do your friends?", "live", "Where do your friends live?"),
 ("Why you answer my email?", "didn't", "Why didn't you answer my email?", "Why did not you answer my email?"),
 ("Do you often to the movies?", "go", "Do you often go to the movies?"),
 ("What this word mean?", "does", "What does this word mean?"),
 ("What time did arrive?", "your friends", "What time did your friends arrive?"),
 ("Who are you talking?", "to", "Who are you talking to?"),
 ("Where were last night?", "you", "Where were you last night?"),
]
colA = ''.join(put_row(i+1, *ga[i]) for i in range(0, 5))
colB = ''.join(put_row(i+1, *ga[i]) for i in range(5, 10))
slide('s-gram-ex1', 'Grammar – Put the Word in Place', '''<div class="slide" id="s-gram-ex1">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Put the word in the correct place</h2>
    <p class="instruction">Put the word or phrase in brackets in the correct place in the question, and write the whole question.</p>
    <!-- SB p.127 Grammar Bank 1A ex a -->
    <div class="ex-row ex-given"><span class="example-badge">✓</span>Where %s you from? <span class="cue-chip">are</span></div>
    <div class="fixed-two-col" id="gram-ex1">
      <div>%s</div>
      <div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('gram-ex1')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('gram-ex1')">Reset</button>
    </div>
  </div></div>
</div>''' % (green('are'), colA, colB))

# ------------------------------------------------------------------ GRAMMAR BANK EX b
def order_row(n, words, ans):
    return ('<div class="ex-row"><span class="circ-num">%d</span><span style="letter-spacing:.02em;">%s</span><br>'
            '<input class="ans-input" style="width:min(520px,100%%);margin-left:32px;" data-ans="%s" aria-label="question %d"></div>') % (n, words, ans, n)
gb = [
 ("you / a / do / have / car ?", "Do you have a car?"),
 ("was / brother / your / where / born ?", "Where was your brother born?"),
 ("often / he / how / call / does / you ?", "How often does he call you?"),
 ("their / time / arrive / does / flight / what ?", "What time does their flight arrive?"),
 ("Brazil / from / is / girlfriend / your ?", "Is your girlfriend from Brazil?"),
 ("languages / how / you / many / can / speak ?", "How many languages can you speak?"),
 ("party / the / how / was ?", "How was the party?"),
 ("last / go / where / you / summer / did ?", "Where did you go last summer?"),
 ("there / doctor / here / is / a ?", "Is there a doctor here?"),
 ("come / bus / to / you / by / school / did ?", "Did you come to school by bus?"),
]
colA = ''.join(order_row(i+1, *gb[i]) for i in range(0, 5))
colB = ''.join(order_row(i+1, *gb[i]) for i in range(5, 10))
slide('s-gram-ex2', 'Grammar – Put the Words in Order', '''<div class="slide" id="s-gram-ex2">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Put the words in order</h2>
    <p class="instruction">Put the words in the correct order to make questions.</p>
    <!-- SB p.127 Grammar Bank 1A ex b -->
    <div class="ex-row ex-given"><span class="example-badge">✓</span>you / live / where / do ?<br><span class="given-line">%s</span></div>
    <div class="fixed-two-col" id="gram-ex2">
      <div>%s</div>
      <div>%s</div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('gram-ex2')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('gram-ex2')">Reset</button>
    </div>
  </div></div>
</div>''' % (green('Where do you live?'), colA, colB))

# ------------------------------------------------------------------ CONVERSATION: Chat with Alex (uses everything so far)
slide('s-chat', 'Conversation – Chat with Alex', '''<div class="slide" id="s-chat">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Chat with Alex</h2>
    <p class="instruction">You're meeting Alex, a new friend. Choose the correct question to keep the conversation going. Then answer Alex's question about <i>you</i> — out loud!</p>
    <!-- Uses: word order in questions (be, can, do / does / did), verb phrases, returning a question. -->
    <div class="chat-phone">
      <div class="chat-top"><span class="chat-av">🧑</span><b>Alex</b><span class="chat-on">● online</span></div>
      <div class="chat-thread" id="cc-thread"></div>
      <div class="chat-controls" id="cc-controls"></div>
    </div>
  </div></div>
</div>''')

# ------------------------------------------------------------------ 2c: missing words in the second questions
def mw(first, before, ans, after, alt=None):
    alttxt = (' data-alt="%s"' % alt) if alt else ''
    return ('<div class="ex-row" style="margin-bottom:14px;">– %s<br><span style="color:#2F6FB0;font-weight:700;">%s</span> <input class="ans-input" style="width:190px" data-ans="%s"%s aria-label="missing words"> <span style="color:#2F6FB0;font-weight:700;">%s</span></div>') % (first, before, ans, alttxt, after)
present = ''.join([
 mw("go to a gym?", "What gym", "do you go", "to?"),
 mw("sleep well?", "How many hours", "do you sleep", "?"),
 mw("play games on your phone?", "What games", "do you play", "?"),
 mw("like watching sport on TV?", "What sports", "do you like watching", "?"),
])
past = ''.join([
 mw("go to bed late last night?", "What time", "did you go", "to bed?"),
 mw("cook lunch or dinner yesterday?", "What", "did you cook", "?"),
 mw("go for a walk at the weekend?", "Where", "did you go", "?"),
 mw("see a good film last week?", "What film", "did you see", "?"),
 mw("buy any clothes last month?", "What", "did you buy", "?"),
])
slide('s-gram-ex3', 'Grammar – Missing Words', '''<div class="slide" id="s-gram-ex3">
  <div class="banner banner-grammar">📐 Grammar</div>
  <div class="slide-main"><div class="content">
    <h2>Follow-up questions</h2>
    <p class="instruction">Look at the two groups of questions. What are the missing words in the second questions?</p>
    <!-- SB p.7 ex 2c. The book shows the example unnumbered with dash bullets. -->
    <div class="fixed-two-col" id="gram-ex3" style="gap:0 30px;">
      <div class="card" style="background:#E4F6FE;">
        <h3 class="section-subhead" style="margin-top:0;">PRESENT</h3>
        <p class="discuss-label" style="margin-bottom:8px;">Do you…</p>
        <div class="ex-row" style="margin-bottom:14px;">– drink a lot of tea or coffee?<br><span style="color:#2F6FB0;font-weight:700;">How many cups</span> %s <span style="color:#2F6FB0;font-weight:700;">a day?</span></div>
        %s
      </div>
      <div class="card" style="background:#E4FAF3;">
        <h3 class="section-subhead" style="margin-top:0;color:#0C8A5E;">PAST</h3>
        <p class="discuss-label" style="margin-bottom:8px;">Did you…</p>
        %s
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-check" onclick="checkSlide('gram-ex3')">Check Answers</button>
      <button class="btn-reset" onclick="resetSlide('gram-ex3')">Reset</button>
    </div>
  </div></div>
</div>''' % (green('do you drink'), present, past))

# ------------------------------------------------------------------ 2d freer: stand up and ask
pairs = [
 ("Do you drink a lot of tea or coffee?", "How many cups do you drink a day?", "pres"),
 ("Do you go to a gym?", "What gym do you go to?", "pres"),
 ("Do you sleep well?", "How many hours do you sleep?", "pres"),
 ("Do you play games on your phone?", "What games do you play?", "pres"),
 ("Do you like watching sport on TV?", "What sports do you like watching?", "pres"),
 ("Did you go to bed late last night?", "What time did you go to bed?", "past"),
 ("Did you cook lunch or dinner yesterday?", "What did you cook?", "past"),
 ("Did you go for a walk at the weekend?", "Where did you go?", "past"),
 ("Did you see a good film last week?", "What film did you see?", "past"),
 ("Did you buy any clothes last month?", "What did you buy?", "past"),
]
pc = ''
for q1, q2, t in pairs:
    pc += '''      <div class="pair-card%s">
        <p class="pc-q1"><span class="tag">%s</span>%s</p>
        <button class="ccq-reveal-btn" onclick="this.nextElementSibling.classList.toggle('show')">Yes! → follow-up</button>
        <div class="pc-q2">%s</div>
      </div>
''' % (' past' if t == 'past' else '', 'Q1', q1, q2)
slide('s-gram-ex4', 'Grammar – Ask and Follow Up', '''<div class="slide" id="s-gram-ex4">
  <div class="banner banner-speaking">🗣️ Speaking</div>
  <div class="slide-main"><div class="content">
    <h2>Ask and follow up</h2>
    <p class="instruction">Ask the first question until I say <i>Yes</i>. Then ask the follow-up question. Continue with the other questions.</p>
    <!-- SB p.7 ex 2d (stand up and ask different students) adapted for one-on-one -->
    <div class="chat" style="max-width:760px;">
      <div class="bub a"><span class="who">A</span>Do you drink a lot of tea or coffee?</div>
      <div class="bub b"><span class="who">B</span>Yes, I drink a lot of coffee.</div>
      <div class="bub a"><span class="who">A</span>How many cups do you drink a day?</div>
      <div class="bub b"><span class="who">B</span>Three or four.</div>
    </div>
    <div class="pair-grid">
%s    </div>
  </div></div>
</div>''' % pc)
