import asyncio, json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width':1366,'height':820})
        errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: errs.append(m.text) if m.type in ('error','warning') else None)
        await pg.goto('file:///tmp/aef/a1a/index.html')
        await pg.wait_for_timeout(800)
        n = await pg.evaluate('slides.length')
        for i in range(n):
            await pg.evaluate('goTo(%d)'%i)
            await pg.wait_for_timeout(750)
            await pg.screenshot(path='shots/s%02d.png'%i)
        print('slides',n,'errors',errs)
        await b.close()
asyncio.run(main())
