# AEF lesson build tools
- a1a/ = AEF2-1A source, a1b/ = AEF2-1B source (newer; start new lessons from a1b).
- Each lesson: s_*.py (slides), js_new.js (lesson JS + AUDIO map + notes-PDF cover), theme*.css, build.py -> writes index.html.
- balance.py (shared, keep next to the lesson folders): puts worked examples in column 1 and splits exercises top-to-bottom/left-to-right.
- sweep.py / audit.py: Playwright checks (fills correct answers, font-size audit). audit_cols.py / audit2.py: column audits.
- Run: python3 build.py inside the lesson folder (needs python3, beautifulsoup4, playwright).
